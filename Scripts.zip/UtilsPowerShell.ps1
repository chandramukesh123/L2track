param([string]$SetupConfigurationFile,[string]$Value="NormalUpgrade",[string]$Upgrade="True")


function Write-HostWithLog{param([string]$Statement)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
		{ New-Item $LogFile  -type file | Out-Null }
	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement

}

#This function will Write to console with foreground color and in log file
function Write-HostWithLogandColor{param([string]$Statement,[string]$Color)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
		{ New-Item $LogFile -type file | Out-Null }

	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement -ForegroundColor $Color

}

function TestPath{param([string]$FolderPath,[string]$Message)
	if(Test-Path ($FolderPath))
	{
	Write-HostWithLogandColor $Temp Gray
	Write-HostWithLogandColor "$FolderPath $Message folder Path is valid" Gray
	Write-HostWithLogandColor $TempNewLine Gray
	}
	else
	{
	Write-HostWithLogandColor $TempNewLine Red
	Write-HostWithLogandColor "$FolderPath $Message folder path is invalid" Red
	Write-HostWithLogandColor $Temp Red
	throw "Please enter correct folder path"
	exit 1;
	}
}

$Temp= "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"

[xml]$xmlConfigFile = new-object XML
 
$config_file=$SetupConfigurationFile
$xmlConfigFile.Load($config_file)

# Common Configuraion
	$LogFile_FolderPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/LogFile_FolderPath").getAttribute("Log_FolderPath_M")
	$LogFile=$LogFile_FolderPath + "\Log.txt"
	Write-HostWithLogandColor "Log Path $LogFile" Green
	$Build_Folder=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Build_FolderPath").getAttribute("Build_FolderPath_M")
	write-host "$Build_Folder path for build"
	$Build_FolderPath=$Build_Folder +"\Framework"
	TestPath $Build_FolderPath "Framework Build"
	#Write-HostWithLogandColor "$Build_FolderPath" Green

Write-HostWithLog "#################################################################################"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "## This Powershell is property of Citiustech"
Write-HostWithLog "## Do not make any changes without product team confirmation"
Write-HostWithLog "## Created by : Amit More"
Write-HostWithLog "## "
Write-HostWithLog "## Running UtilsPowerShell.ps1"
Write-HostWithLog "##Deploying Framework application components on EAP/Wildfly server"
Write-HostWithLog "##"
Write-HostWithLog "##DO not close this window until deployment is successful"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "#################################################################################"
	#Source for SQLJDBC & Microsoft jar
	$MicrosoftFolder=$Build_FolderPath + "\JAVASolutions" + "\SQLDataDriver"
	$SQLJDBC=$Build_FolderPath+"\ReleaseManagement"+"\PowerShellScript"+"\JenkinsConfig"
	

	#SQL Server Details
	$Clinical_DB_Server=$xmlConfigFile.selectSingleNode("Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("A_Clinical_DB_Server_M")
	$Clinical_DB_Server=$Clinical_DB_Server.replace('\','\\')
	Write-HostWithLogandColor "SQL Server Name: $Clinical_DB_Server" Gray
	$Clinical_DB_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("D_Clinical_DB_Name_M")
	Write-HostWithLogandColor "Database Name: $Clinical_DB_Name" Gray
	$Clinical_DB_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("C_Clinical_DB_Port_M")
	Write-HostWithLogandColor "SQL Server Port: $Clinical_DB_Port" Gray
	$Clinical_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("B_Clinical_App_SQL_User")
	$Clinical_App_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("C_Clinical_App_SQL_Password")
	$NetezzaServer_Required=$xmlConfigFile.selectSingleNode("Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("NetezzaServer_Required")
	Write-HostWithLogandColor "Netezza Server Name: $NetezzaServer" Gray
	
	#UI/Web server details
	$Framework_Web_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").getAttribute("A_Framework_Web_Server_Name")
	$Framework_Web_Port=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").getAttribute("B_Framework_Web_Port")
	$Framework_Web_Server_Path=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").getAttribute("C_Framework_Web_Server_Path")
	#Service/App server details
	$Framework_APP_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").getAttribute("A_Framework_APP_Server_Name_M")
	$Framework_APP_Port=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").getAttribute("B_Framework_APP_Port_M")
	$Framework_APP_Server_Path=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").getAttribute("C_Framework_APP_Server_Path_M")
	
	TestPath $Framework_APP_Server_Path "Framework App Server EAP"
	$Framework_APP_Server_Standalone=$Framework_APP_Server_Path+"\standalone" + "\deployments"
	TestPath $Framework_APP_Server_Standalone 
	
	if($Framework_Web_Server_Path -eq $null -or $Framework_Web_Server_Path -eq "")
	{
	}
	else
	{
	TestPath $Framework_Web_Server_Path "Framework Web Server EAP"
	$Framework_Web_Server_Standalone=$Framework_Web_Server_Path+"\standalone" + "\deployments"
	TestPath $Framework_Web_Server_Standalone 
	}
	
	
	#Is Https required
	$IsHTTPS_Required=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Web_String").getAttribute("IsHttps_Required")
	
	#Components Required
	$HEDIS_Submission_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("HEDIS_Submission_Required")
	$PMS_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("PMS_Required")
	$QPP_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("QPP_Required")
	$QPPDS_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("QPPDS_Required")
	$QRDAI_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("QRDAI_Required")
	$QRDAIII_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("QRDAIII_Required")
	$State_Level_Submission_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("State_Level_Submission_Required")
	$Wrapper_Services_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("Wrapper_Services_Required")
	$GPRO_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("GPRO_Required")
	$CohortQR_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("CohortQR_Required")
	
	#Components Year
	$QPPDS_Year=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("QPPDS_Year")
	$QPP_Year=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("QPP_Year")
	$QRDAIII_Year=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("QRDAIII_Year")
	$QRDAI_Year=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("QRDAI_Year")
	$State_Level_Submission_Year=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("State_Level_Submission_Year")
	$GPRO_Year=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("GPRO_Year")
	$CohortQR_Year=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("CohortQR_Year")
	
	#QRDAI components
	$IsPatAccNo_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/QRDAI").getAttribute("IsPatAccNo_Required")
	if([string]$IsPatAccNo_Required -eq "True")
	{
	$IsPatAccNo_Required ="1"
		Write-HostWithLogandColor "IsPatAccNo : $IsPatAccNo_Required" Gray
	}
	else
	{
	$IsPatAccNo_Required ="0"
		Write-HostWithLogandColor "IsPatAccNo : $IsPatAccNo_Required" Gray
	}
	
	#Destination for SQLJDBC & Microsoft jar
	$UploadMicrosoftFolder=$Framework_APP_Server_Path + "\modules" + "\system" + "\layers" + "\base" + "\com" + "\microsoft" +"\sqlserver" +"\main"
	$DestinationForSQLJDBC=$Framework_APP_Server_Path+"\bin"
	
	#UAM User Access Management in Common paramaeters
	$UAMApp_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMApp_Server_Name")
	$UAMApp_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMApp_Server_Port")
	$UAMWeb_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMWeb_Server_Name")
	$UAMWeb_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMWeb_Server_Port")
	$Auth_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("Auth_Server_Name")
	$Auth_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("Auth_Server_Port")
	$Auth_Web_ClientId=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UAM_Auth").getAttribute("Web_Client_ID")
	$Auth_App_Client_ID=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UAM_Auth").getAttribute("App_Client_ID")
	$Auth_App_client_Secret=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UAM_Auth").getAttribute("App_client_Secret")
	
	
	#Authentication
	if($Clinical_App_SQL_User -eq $null -or $Clinical_App_SQL_User -eq "")
	{
		$Clinical_App_SQL_User = ""
		$Clinical_App_SQL_Password = ""
		$WindowsAuth = "True"
	}
	else
	{
	$Clinical_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("B_Clinical_App_SQL_User")
	$Clinical_App_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("C_Clinical_App_SQL_Password")
	$WindowsAuth = "False"
	}

	#JRE Server Deatils
	$JREServerName=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/JREServer").getAttribute("JRE_Server_Name")
	$JRE_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/JREServer").getAttribute("JRE_Server_Port")
	
	#QPP 2020
	$SourceForQPPFiles_20=$Build_FolderPath+ "\JAVASolutions"+"\QppGeneration"+"\MIPSQPP2020"+"\Properties"
	$SourceForQPPWarFiles_20=$Build_FolderPath+ "\JAVASolutions"+"\QppGeneration"+"\MIPSQPP2020"+"\Build"
	$DestinattionPathForQPPWarFiles_20= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForQPPPropertiesFiles_20= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\mipsqpp2020"+"\configuration"+"\main"
		
	#QPP Submission 2020
	$SourceForQPPPropertiesDS_20=$Build_FolderPath+ "\JAVASolutions"+"\QPPSubmission"+"\QPPSUBMISSION2020"+"\Properties"
	$SourceForQPPWarFilesDS_20=$Build_FolderPath+ "\JAVASolutions"+"\QPPSubmission"+"\QPPSUBMISSION2020"+"\Build"
	$DestinattionPathForQPPWarFilesDS_20= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForQPPPropertiesFilesDS_20= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\qpp2020"+"\configuration"+"\main"
	
    #QPP Submission
	$SourceForQPPPropertiesDS=$Build_FolderPath+ "\JAVASolutions"+"\QPPSubmission"+"\$QPPDS_Year"+"\Properties"
	$SourceForQPPWarFilesDS=$Build_FolderPath+ "\JAVASolutions"+"\QPPSubmission"+"\$QPPDS_Year"+"\Build"
	$DestinattionPathForQPPWarFilesDS= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForQPPPropertiesFilesDS= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\qpp$QPPDS_Year"+"\configuration"+"\main"
	
	#QPPGeneration
	$SourceForQPPFiles=$Build_FolderPath+ "\JAVASolutions"+"\QppGeneration"+"\$QPP_Year"+"\Properties"
	$SourceForQPPWarFiles=$Build_FolderPath+ "\JAVASolutions"+"\QppGeneration"+"\$QPP_Year"+"\Build"
	$DestinattionPathForQPPWarFiles= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForQPPPropertiesFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\mipsqpp$QPP_Year"+"\configuration"+"\main"	
	
	#QRDAI 	
	#FolderPath QRDAI
	$SourceForQRDAProperties=$Build_FolderPath+ "\JAVASolutions"+"\QRDA"+"\QRDAI"+"\$QRDAI_Year"+"\Properties"
	$SourceForQRDAWarFiles=$Build_FolderPath+ "\JAVASolutions"+"\QRDA"+"\QRDAI"+"\$QRDAI_Year"+"\Build"
	$DestinattionPathForQRDAWarFiles= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForQRDAPropertiesFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\qrdac1xml$QRDAI_Year"+"\configuration"+"\main"	


	#QRDAIII
	#FolderPath QRDAIII
	$SourceForQRDAIIIProperties=$Build_FolderPath+"\JAVASolutions"+"\QRDA"+"\QRDAIII"+"\$QRDAIII_Year"+"\Properties"
	$SourceForQRDAIIIWarFiles=$Build_FolderPath+"\JAVASolutions"+"\QRDA"+"\QRDAIII"+"\$QRDAIII_Year"+"\Build"
	$DestinationPathForQRDAIIIWarFiles= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForQRDAIIIPropertiesFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\qrdaIII$QRDAIII_Year"+"\configuration"+"\main"	
	
	
	#HEDIS_Sub_Reporting
	#FolderPath HEDIS_Submission
	$SourceForHEDISSubReportProperties=$Build_FolderPath+ "\JAVASolutions"+"\HedisSubmission"+"\Properties"
	$SourceForHEDISSubReportWarFiles=$Build_FolderPath+ "\JAVASolutions"+"\HedisSubmission"+"\Build"
	$HEDISSubReportingWelcomeDirSource= $Build_FolderPath+ "\JAVASolutions"+"\HedisSubmission"+"\welcome-content"
	$DestinattionPathForHEDISSSubReportServiceWarFiles= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForHEDISSubReportPropertiesServiceFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\hedissubmission"+"\configuration"+"\main"
	$DestinattionPathForHEDISSSubReportUIWarFiles= $Framework_Web_Server_Path +"\standalone" + "\deployments"
	$DestinationForHEDISSubReportPropertiesUIFiles= $Framework_Web_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\hedissubmission"+"\configuration"+"\main"
	$HEDISSubReportingWelcomeDir= $Framework_Web_Server_Path+"\welcome-content"
	
	if($IsHTTPS_Required -eq "True")
	{
		$UIServerURL="https://"+$Framework_Web_Server_Name+":"+$Framework_Web_Port
		$ServiceServerURL="https://"+$Framework_APP_Server_Name+":"+$Framework_APP_Port
		$HEDISAuthServerURL="https://"+$Auth_Server_Name+":"+$Auth_Server_Port
		$HEDISUAMServerURL="https://"+$UAMApp_Server_Name+":"+$UAMApp_Server_Port
		$HEDISUAMWebServerURL="https://"+$UAMWeb_Server_Name+":"+$UAMWeb_Server_Port
		$HTTPSEnabled="True"
		$JREServerURL ="https://"+$JreServerName
		$UAMServerURL= "https://"+$UAMApp_Server_Name
		$KeycloakServerURL= "https://"+$Auth_Server_Name
	}
	else{
		$UIServerURL="http://"+$Framework_Web_Server_Name+":"+$Framework_Web_Port
		$ServiceServerURL="http://"+$Framework_APP_Server_Name+":"+$Framework_APP_Port
		$HEDISAuthServerURL="http://"+$Auth_Server_Name+":"+$Auth_Server_Port
		$HEDISUAMServerURL="http://"+$UAMApp_Server_Name+":"+$UAMApp_Server_Port
		$HEDISUAMWebServerURL="http://"+$UAMWeb_Server_Name+":"+$UAMWeb_Server_Port
		$HTTPSEnabled="False"
		$JREServerURL ="http://"+$JreServerName
		$UAMServerURL= "http://"+$UAMApp_Server_Name
		$KeycloakServerURL= "http://"+$Auth_Server_Name
	}

	#ACO_GPRO 
	#FolderPath ACO_GPRO 2020
	$SourceForGPRO20Properties=$Build_FolderPath+ "\JAVASolutions"+"\ACOGPRO2020"+"\Properties"
	$SourceForGPRO20WarFiles=$Build_FolderPath+ "\JAVASolutions"+"\ACOGPRO2020"+"\Build"
	$DestinattionPathForGPRO20WarFiles= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForGPRO20PropertiesFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\acogpro20"+"\configuration"+"\main"
	$WildFlyFolderTemplate20=$Framework_APP_Server_Path.replace('\','\\')
	$TEMPLATE_PATHGPRO20=$WildFlyFolderTemplate20 +"\\modules"+"\\system"+"\\layers"+"\\base"+"\\com"+"\\biclinical"+"\\acogpro20"+"\\configuration"+"\\main"+"\\CMS-Web-Interface-Excel-template.xlsx"
	
	#FolderPath ACO_GPRO 2021
	$SourceForGPRO21Properties=$Build_FolderPath+ "\JAVASolutions"+"\ACOGPRO"+"\2021"+"\Properties"
	$SourceForGPRO21WarFiles=$Build_FolderPath+ "\JAVASolutions"+"\ACOGPRO"+"\2021"+"\Build"
	$DestinattionPathForGPRO21WarFiles= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForGPRO21PropertiesFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\acogpro21"+"\configuration"+"\main"
	$WildFlyFolderTemplate21=$Framework_APP_Server_Path.replace('\','\\')
	$TEMPLATE_PATHGPRO21=$WildFlyFolderTemplate21 +"\\modules"+"\\system"+"\\layers"+"\\base"+"\\com"+"\\biclinical"+"\\acogpro21"+"\\configuration"+"\\main"+"\\CMS-Web-Interface-Excel-template.xlsx"
	
	#Connection string
	$DeiverClassNameNetezzaGPRO="org.netezza.Driver"
	$DriverClassNameSQLGPRO="com.microsoft.sqlserver.jdbc.SQLServerDriver"
	$DatabaseTypeNZGPRO="Netezza"
	$DatabaseTypeSQLGPRO="SQL"
	if(($NetezzaServer_Required -eq "True") -and ([string]$GPRO_Required) -eq "True")
	{
	$GPROConnectionString="jdbc:netezza://" +$Clinical_DB_Server+":"+$Clinical_DB_Port+"/"+$Clinical_DB_Name+";"
	$FinalDriverClassNameACO="$DeiverClassNameNetezzaGPRO"
	$FDatabaseTypeACO="$DatabaseTypeNZGPRO"
	}
	else
	{
	$GPROConnectionString="jdbc:sqlserver://"+$Clinical_DB_Server+":"+$Clinical_DB_Port+";"+"databaseName"+"="+$Clinical_DB_Name+";"
	$FinalDriverClassNameACO="$DriverClassNameSQLGPRO"
	$FDatabaseTypeACO="$DatabaseTypeSQLGPRO"
	}
	#WraperService
	$OutputFilePathWraperService=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Wrapper_Service").getAttribute("Output_Folder_Path")
	$WrapperServiceURL=$Framework_APP_Server_Name+":"+$Framework_APP_Port
	
	#FolderPath WraperService
	
	$SourceForWraperServiceProperties=$Build_FolderPath+ "\JAVASolutions"+"\WraperService"+"\Properties"
	$SourceForWraperServiceWarFiles=$Build_FolderPath+ "\JAVASolutions"+"\WraperService"+"\build"
	$DestinattionPathForWraperServiceWarFiles= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForWraperServicePropertiesFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\wraperservices"+"\configuration"+"\main"
	
	$DriverClassNameNetezza="org.netezza.Driver"
	$DriverClassNameSQL="com.microsoft.sqlserver.jdbc.SQLServerDriver"
	$DatabaseTypeNZ="Netezza"
	$DatabaseTypeSQL="SQL"
	if($NetezzaServer_Required -eq "True")
	{
	$WSConnectionString="jdbc:netezza://" +$Clinical_DB_Server+":"+$Clinical_DB_Port+"/"+$Clinical_DB_Name+";"
	$FinalDriverClassName="$DriverClassNameNetezza"
	$DatabaseType="$DatabaseTypeNZ"
	$databasejndiname=""
	}
	else
	{
	$WSConnectionString="jdbc:sqlserver://"+$Clinical_DB_Server+":"+$Clinical_DB_Port+";"+"databaseName"+"="+$Clinical_DB_Name+";"+"integratedsecurity"+"="+$WindowsAuth
	$FinalDriverClassName="$DriverClassNameSQL"
	$DatabaseType="$DatabaseTypeSQL"
	$databasejndiname="java:/SQLDS"
	}
	
	
	#State Level Submission
	#FolderPath State Level Submission $State_Level_Submission_Year
	$SourceForSLSProperties=$Build_FolderPath + "\JAVASolutions" + "\SLS"+"\$State_Level_Submission_Year" + "\Properties"
	$SourceForSLSWarFiles=$Build_FolderPath + "\JAVASolutions" + "\SLS"+"\$State_Level_Submission_Year" + "\Build"
	$DestinattionPathForSLSWarFiles= $Framework_APP_Server_Path + "\standalone" + "\deployments"
	$DestinationForSLSPropertiesFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\mlf$State_Level_Submission_Year"+"\configuration"+"\main"
	
	#PMS Deployment
	#FolderPath PMS
	$SourceForPMSProperties=$Build_FolderPath+ "\JAVASolutions"+"\PMS"+"\properties"
	$SourceForPMSWarFiles=$Build_FolderPath+ "\JAVASolutions"+"\PMS"+"\Build"
	$DestinattionPathForPMSWarFile= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForPMSPropertiesFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\pms-api2020"+"\configuration"+"\main"
	#PMS Server URL
	
	#CohortQR FolderPath
	$SourceForCohortQRProperties=$Build_FolderPath+ "\JAVASolutions"+"\CohortQR"+"\2021"+"\properties"
	$SourceForCohortQRWarFiles=$Build_FolderPath+ "\JAVASolutions"+"\CohortQR"+"\2021"+"\Build"
	$DestinattionPathForCohortQRWarFile= $Framework_APP_Server_Path +"\standalone" + "\deployments"
	$DestinationForCohortQRPropertiesFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\cohortqr"+"\configuration"+"\main"
	
#Deployment
Write-HostWithLogandColor $dashline Gray 
Write-HostWithLogandColor "Copying of files started  `n " Blue

Function CopyFiles {
#MIPS QPP 2020
if (([string] $QPP_Required -eq "True") -and  [string] $QPP_Year -eq "2020")
{
Write-HostWithLogandColor "QPP2020 Server Name: $Clinical_DB_Server `n" White
Write-HostWithLogandColor "QPP2020 Database Name: $Clinical_DB_Name `n" White
Write-HostWithLogandColor "Started Deployment of MIPS QPP 2020 `n " Yellow
if (Test-Path ($DestinationForQPPPropertiesFiles_20))
{}
else
{New-Item ($DestinationForQPPPropertiesFiles_20) -type directory -force | out-null}
if (Test-Path "$SourceForQPPFiles_20\database.properties")
{Get-Content "$SourceForQPPFiles_20\database.properties" | ForEach-Object { $_ -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port" -replace "<IntegratedSecurity>","$WindowsAuth"} | Set-Content "$DestinationForQPPPropertiesFiles_20\database.properties"}
if (Test-Path "$SourceForQPPFiles_20\qppqueries.properties")
{get-childitem -path "$SourceForQPPFiles_20\qppqueries.properties"| Copy-Item -destination "$DestinationForQPPPropertiesFiles_20\qppqueries.properties"}

get-childitem -path $SourceForQPPFiles_20 -recurse -include *.xml | Copy-Item -destination "$DestinationForQPPPropertiesFiles_20"

if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"
#QPP War Deployment
if((Test-Path $DestinattionPathForQPPWarFiles_20) -eq $False)
{
	New-Item ($DestinattionPathForQPPWarFiles_20) -type directory -force | out-null
}
if ((Test-Path "$SourceForQPPWarFiles_20" ) -and [string]$QPP_Required -eq "true" )
{
get-childitem -path $SourceForQPPWarFiles_20 -recurse -include *.war | Copy-Item -destination "$DestinattionPathForQPPWarFiles_20"
}
Write-HostWithLogandColor "Deployed MIPS QPP 2020 WAR and Properties File `n" Yellow
}
#QPP Submission 2020
if (([string]$QPPDS_Required -eq "True") -and $QPPDS_Year -eq "2020" )
{
Write-HostWithLogandColor "QPP DataSubmission Server Name: $Clinical_DB_Server" White
Write-HostWithLogandColor "QPP DataSubmission Database Name: $Clinical_DB_Name `n" White
Write-HostWithLogandColor "Started QPP DataSubmission 2020 Deployment `n" Yellow
if (Test-Path ($DestinationForQPPPropertiesFilesDS_20))
{}
else{New-Item ($DestinationForQPPPropertiesFilesDS_20)-type directory -force | out-null}
if (Test-Path "$SourceForQPPPropertiesDS_20\database.properties")
{Get-Content "$SourceForQPPPropertiesDS_20\database.properties" | ForEach-Object { $_ -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port" -replace "<IntegratedSecurity>","$WindowsAuth"} | Set-Content "$DestinationForQPPPropertiesFilesDS_20\database.properties"}
if (Test-Path "$SourceForQPPPropertiesDS_20\qpp.properties")
{Get-Content "$SourceForQPPPropertiesDS_20\qpp.properties" | ForEach-Object { $_ -replace "<QPPDSFolder>","$QPPDSFolderPath1"} | Set-Content "$DestinationForQPPPropertiesFilesDS_20\qpp.properties"}
if (Test-Path "$SourceForQPPPropertiesDS_20\qppqueries.properties")
{get-childitem -path "$SourceForQPPPropertiesDS_20\qppqueries.properties"| Copy-Item -destination "$DestinationForQPPPropertiesFilesDS_20\qppqueries.properties"}
if (Test-Path "$SourceForQPPPropertiesDS_20\qppurldetails.properties")
{get-childitem -path "$SourceForQPPPropertiesDS_20\qppurldetails.properties"| Copy-Item -destination "$DestinationForQPPPropertiesFilesDS_20\qppurldetails.properties"}
if (Test-Path "$SourceForQPPPropertiesDS_20\serviceUrlProperties.properties")
{get-childitem -path "$SourceForQPPPropertiesDS_20\serviceUrlProperties.properties"| Copy-Item -destination "$DestinationForQPPPropertiesFilesDS_20\serviceUrlProperties.properties"}

get-childitem -path $SourceForQPPPropertiesDS_20 -recurse -include *.xml | Copy-Item -destination "$DestinationForQPPPropertiesFilesDS_20"

if((Test-Path $DestinattionPathForQPPWarFilesDS_20) -eq $False)
{
	New-Item ($DestinattionPathForQPPWarFilesDS_20) -type directory -force | out-null
}
if ((Test-Path "$SourceForQPPWarFilesDS_20" ) -and [string]$QPPDS_Required -eq "true" )
{
get-childitem -path $SourceForQPPWarFilesDS_20 -recurse -include *.war | Copy-Item -destination "$DestinattionPathForQPPWarFilesDS_20"
}

if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder

get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"

Write-HostWithLogandColor "Deployed QPP DataSubmission 2020 WAR and Properties File `n" Yellow
}

#QPPGeneration 
if ([string] $QPP_Required -eq "True")
{
Write-HostWithLogandColor "QPP$QPP_Year Server Name: $Clinical_DB_Server `n" White
Write-HostWithLogandColor "QPP$QPP_Year Database Name: $Clinical_DB_Name `n" White
Write-HostWithLogandColor "Started Deployment of QPPGeneration $QPP_Year `n " Yellow
if (Test-Path ($DestinationForQPPPropertiesFiles))
{}
else
{New-Item ($DestinationForQPPPropertiesFiles) -type directory -force | out-null}
if (Test-Path "$SourceForQPPFiles\database.properties")
{Get-Content "$SourceForQPPFiles\database.properties" | ForEach-Object { $_ -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port" -replace "<IntegratedSecurity>","$WindowsAuth"} | Set-Content "$DestinationForQPPPropertiesFiles\database.properties"}
if (Test-Path "$SourceForQPPFiles\qppqueries.properties")
{get-childitem -path "$SourceForQPPFiles\qppqueries.properties"| Copy-Item -destination "$DestinationForQPPPropertiesFiles\qppqueries.properties"}

get-childitem -path $SourceForQPPFiles -recurse -include *.xml | Copy-Item -destination "$DestinationForQPPPropertiesFiles"

if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"
#QPPGeneration War Deployment
if((Test-Path $DestinattionPathForQPPWarFiles) -eq $False)
{
	New-Item ($DestinattionPathForQPPWarFiles) -type directory -force | out-null
}
if ((Test-Path "$SourceForQPPWarFiles" ) -and [string]$QPP_Required -eq "true" )
{
get-childitem -path $SourceForQPPWarFiles -recurse -include *.war | Copy-Item -destination "$DestinattionPathForQPPWarFiles"
}
Write-HostWithLogandColor "Deployed QPPGeneration $QPP_Year WAR and Properties File `n" Yellow
}

#QPP Submission
if ([string]$QPPDS_Required -eq "True")
{
Write-HostWithLogandColor "QPP DataSubmission Server Name: $Clinical_DB_Server" White
Write-HostWithLogandColor "QPP DataSubmission Database Name: $Clinical_DB_Name `n" White
Write-HostWithLogandColor "Started QPP DataSubmission $QPPDS_Year Deployment `n" Yellow
if (Test-Path ($DestinationForQPPPropertiesFilesDS))
{}
else{New-Item ($DestinationForQPPPropertiesFilesDS)-type directory -force | out-null}
if (Test-Path "$SourceForQPPPropertiesDS\database.properties")
{Get-Content "$SourceForQPPPropertiesDS\database.properties" | ForEach-Object { $_ -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port" -replace "<IntegratedSecurity>","$WindowsAuth"} | Set-Content "$DestinationForQPPPropertiesFilesDS\database.properties"}
if (Test-Path "$SourceForQPPPropertiesDS\qpp.properties")
{Get-Content "$SourceForQPPPropertiesDS\qpp.properties" | ForEach-Object { $_ -replace "<QPPDSFolder>","$QPPDSFolderPath1"} | Set-Content "$DestinationForQPPPropertiesFilesDS\qpp.properties"}
if (Test-Path "$SourceForQPPPropertiesDS\qppqueries.properties")
{get-childitem -path "$SourceForQPPPropertiesDS\qppqueries.properties"| Copy-Item -destination "$DestinationForQPPPropertiesFilesDS\qppqueries.properties"}
if (Test-Path "$SourceForQPPPropertiesDS\qppurldetails.properties")
{get-childitem -path "$SourceForQPPPropertiesDS\qppurldetails.properties"| Copy-Item -destination "$DestinationForQPPPropertiesFilesDS\qppurldetails.properties"}
if (Test-Path "$SourceForQPPPropertiesDS\serviceUrlProperties.properties")
{Get-Content "$SourceForQPPPropertiesDS\serviceUrlProperties.properties" | ForEach-Object { $_ -replace "<QPPSubmissionServiceURL>","$ServiceServerURL"} | Set-Content "$DestinationForQPPPropertiesFilesDS\serviceUrlProperties.properties"}

get-childitem -path $SourceForQPPPropertiesDS -recurse -include *.xml | Copy-Item -destination "$DestinationForQPPPropertiesFilesDS"

if((Test-Path $DestinattionPathForQPPWarFilesDS) -eq $False)
{
	New-Item ($DestinattionPathForQPPWarFilesDS) -type directory -force | out-null
}
if ((Test-Path "$SourceForQPPWarFilesDS" ) -and [string]$QPPDS_Required -eq "true" )
{
get-childitem -path $SourceForQPPWarFilesDS -recurse -include *.war | Copy-Item -destination "$DestinattionPathForQPPWarFilesDS"
}

if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder

get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"

Write-HostWithLogandColor "Deployed QPP DataSubmission $QPPDS_Year WAR and Properties File `n" Yellow
}


#QRDADeployment
# QRDAI Deployment
if([string]$QRDAI_Required -eq "True")
{
Write-HostWithLogandColor "QRDAI $QRDAI_Year BIC Server Name: $Clinical_DB_Server `n" White
Write-HostWithLogandColor "QRDAI $QRDAI_Year BIC Database Name : $Clinical_DB_Name `n " White
Write-HostWithLogandColor "Started QRDAI $QRDAI_Year Deployment `n" Yellow
if (Test-Path ($DestinationForQRDAPropertiesFiles))
{}
else{New-Item ($DestinationForQRDAPropertiesFiles)-type directory -force | out-null}
if (Test-Path "$SourceForQRDAProperties\database.properties")
{Get-Content "$SourceForQRDAProperties\database.properties" | ForEach-Object { $_-replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port" -replace "<IntegratedSecurity>","$WindowsAuth"} | Set-Content "$DestinationForQRDAPropertiesFiles\database.properties"}
if (Test-Path "$SourceForQRDAProperties\qrdaic1xml.properties")
{Get-Content "$SourceForQRDAProperties\qrdaic1xml.properties" | ForEach-Object { $_ -replace "<DatabaseType>","$FDatabaseType" -replace "<IsPatAccNo>","$IsPatAccNo_Required"} | Set-Content "$DestinationForQRDAPropertiesFiles\qrdaic1xml.properties"}
if (Test-Path "$SourceForQRDAProperties\qrdaic1xmlqueries.properties")
{get-childitem -path "$SourceForQRDAProperties\qrdaic1xmlqueries.properties"| Copy-Item -destination "$DestinationForQRDAPropertiesFiles\qrdaic1xmlqueries.properties"}
if (Test-Path "$SourceForQRDAProperties\epopxmlqueries.properties")
{get-childitem -path "$SourceForQRDAProperties\epopxmlqueries.properties"| Copy-Item -destination "$DestinationForQRDAPropertiesFiles\epopxmlqueries.properties"}
if (Test-Path "$SourceForQRDAProperties\errormessages.properties")
{get-childitem -path "$SourceForQRDAProperties\errormessages.properties"| Copy-Item -destination "$DestinationForQRDAPropertiesFiles\errormessages.properties"}
get-childitem -path $SourceForQRDAProperties -recurse -include *.xml | Copy-Item -destination "$DestinationForQRDAPropertiesFiles"


if((Test-Path $DestinattionPathForQRDAWarFiles) -eq $False)
{
	New-Item ($DestinattionPathForQRDAWarFiles) -type directory -force | out-null
}
if ((Test-Path "$SourceForQRDAWarFiles" ) -and [string]$QRDAI_Required -eq "true" )
{
get-childitem -path $SourceForQRDAWarFiles -recurse -include *.war | Copy-Item -destination "$DestinattionPathForQRDAWarFiles"
}
if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}
get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"

Write-HostWithLogandColor "Deployed QRDA I $QRDAI_Year WAR and Properties file" Yellow
Write-HostWithLogandColor $dashline Gray 
}


#QRDAIII deployment
if ([string]$QRDAIII_Required -eq "True")
{
Write-HostWithLogandColor "QRDAIII $QRDAIII_Year Server Name: $Clinical_DB_Server `n" White
Write-HostWithLogandColor "QRDAIII $QRDAIII_Year Database Name : $Clinical_DB_Name `n" White
Write-HostWithLogandColor "Started QRDAIII $QRDAIII_Year Deployment `n" Yellow
if (Test-Path ($DestinationForQRDAIIIPropertiesFiles))
{}
else{New-Item ($DestinationForQRDAIIIPropertiesFiles)-type directory -force | out-null}
if (Test-Path "$SourceForQRDAIIIProperties\database.properties")
{Get-Content "$SourceForQRDAIIIProperties\database.properties" | ForEach-Object { $_  -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<IntegratedSecurity>","$WindowsAuth" -replace "<DBPort>","$Clinical_DB_Port"} | Set-Content "$DestinationForQRDAIIIPropertiesFiles\database.properties"}
if (Test-Path "$SourceForQRDAIIIProperties\qrdaIIIxmlqueries.properties")
{get-childitem -path "$SourceForQRDAIIIProperties\qrdaIIIxmlqueries.properties"| Copy-Item -destination "$DestinationForQRDAIIIPropertiesFiles\qrdaIIIxmlqueries.properties"}

get-childitem -path $SourceForQRDAIIIProperties -recurse -include *.xml | Copy-Item -destination "$DestinationForQRDAIIIPropertiesFiles"

if((Test-Path $DestinationPathForQRDAIIIWarFiles) -eq $False)
{
	New-Item ($DestinationPathForQRDAIIIWarFiles) -type directory -force | out-null
}
if ((Test-Path "$SourceForQRDAIIIWarFiles" ) -and [string]$QRDAIII_Required -eq "true" )
{
get-childitem -path $SourceForQRDAIIIWarFiles -recurse -include *.war | Copy-Item -destination "$DestinationPathForQRDAIIIWarFiles"
}
if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"
Write-HostWithLogandColor "Deployed QRDA III $QRDAIII_Year WAR and Properties file" Yellow

Write-HostWithLogandColor $dashline Gray 
}
#HEDIS_Sub_Reporting
if ([string]$HEDIS_Submission_Required -eq "True")
{
Write-HostWithLogandColor "HEDIS_Sub_Reporting Server Name: $Clinical_DB_Server" White
Write-HostWithLogandColor "HEDIS_Sub_Reporting Database Name: $Clinical_DB_Name `n" White
Write-HostWithLogandColor "Deployment started for HEDIS Submission Reporting `n" Yellow
if (Test-Path ($DestinationForHEDISSubReportPropertiesServiceFiles))
{}
else{New-Item ($DestinationForHEDISSubReportPropertiesServiceFiles)-type directory -force | out-null}
if (Test-Path ($DestinationForHEDISSubReportPropertiesUIFiles))
{}
else{New-Item ($DestinationForHEDISSubReportPropertiesUIFiles)-type directory -force | out-null}
if (Test-Path ($SourceForHEDISSubReportProperties))
{}
else{New-Item ($SourceForHEDISSubReportProperties)-type directory -force | out-null}
Write-HostWithLogandColor "copy Properties file" Green
if (Test-Path "$SourceForHEDISSubReportProperties\database.properties")
{Get-Content "$SourceForHEDISSubReportProperties\database.properties" | ForEach-Object { $_ -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port" -replace "<IntegratedSecurity>","$WindowsAuth"} | Set-Content "$DestinationForHEDISSubReportPropertiesServiceFiles\database.properties"}
if (Test-Path "$SourceForHEDISSubReportProperties\idssregistryqueries.properties")
{get-childitem -path "$SourceForHEDISSubReportProperties\idssregistryqueries.properties"| Copy-Item -destination "$DestinationForHEDISSubReportPropertiesServiceFiles\idssregistryqueries.properties"}
if (Test-Path "$SourceForHEDISSubReportProperties\reportsidsspldregistryqueries.properties")
{get-content -path "$SourceForHEDISSubReportProperties\reportsidsspldregistryqueries.properties"| ForEach-Object {$_ -replace "<HEDISUAMServerURL>","$HEDISUAMServerURL" -replace "<UAMPort>","$UAMApp_Server_Port"} | Set-Content "$DestinationForHEDISSubReportPropertiesServiceFiles\reportsidsspldregistryqueries.properties"}
if (Test-Path "$SourceForHEDISSubReportProperties\hedispldqueries.properties")
{get-childitem -path "$SourceForHEDISSubReportProperties\hedispldqueries.properties"| Copy-Item -destination "$DestinationForHEDISSubReportPropertiesServiceFiles\hedispldqueries.properties"}
if (Test-Path "$SourceForHEDISSubReportProperties\ecdsxmlqueries.properties")
{get-childitem -path "$SourceForHEDISSubReportProperties\ecdsxmlqueries.properties"| Copy-Item -destination "$DestinationForHEDISSubReportPropertiesServiceFiles\ecdsxmlqueries.properties"}
if (Test-Path "$SourceForHEDISSubReportProperties\hedisconfig.properties")
{Get-Content "$SourceForHEDISSubReportProperties\hedisconfig.properties" | ForEach-Object { $_  -replace "<HEDISUIURL>","$UIServerURL" -replace "<HEDISServiceURL>","$ServiceServerURL" -replace "<HEDISUAMServerURL>","$HEDISUAMServerURL" -replace "<HEDISUAMWebAppServerURL>","$HEDISUAMWebServerURL" -replace "<HEDISAuthServerURL>","$HEDISAuthServerURL" -replace "<ServiceServer-Name>","$Framework_APP_Server_Name" -replace "<ServiceServerPort>","$Framework_APP_Port" -replace "<UIServer-Name>","$Framework_Web_Server_Name" -replace "<UIPort>","$Framework_Web_Port" -replace "<HTTPSEnabled>","$HTTPSEnabled" -replace "<AuthWebClientId>","$Auth_Web_ClientId"} | Set-Content "$DestinationForHEDISSubReportPropertiesUIFiles\hedisconfig.properties"}
if (Test-Path "$SourceForHEDISSubReportProperties\hedisconfig.properties")
{Get-Content "$SourceForHEDISSubReportProperties\hedisconfig.properties" | ForEach-Object { $_ -replace "<HEDISUIURL>","$UIServerURL" -replace "<HEDISServiceURL>","$ServiceServerURL" -replace "<HEDISUAMServerURL>","$HEDISUAMServerURL" -replace "<HEDISUAMWebAppServerURL>","$HEDISUAMWebServerURL" -replace "<HEDISAuthServerURL>","$HEDISAuthServerURL" -replace "<ServiceServer-Name>","$Framework_APP_Server_Name" -replace "<ServiceServerPort>","$Framework_APP_Port" -replace "<UIServer-Name>","$Framework_Web_Server_Name" -replace "<UIPort>","$Framework_Web_Port" -replace "<HTTPSEnabled>","$HTTPSEnabled" -replace "<AuthWebClientId>","$Auth_Web_ClientId" } | Set-Content "$DestinationForHEDISSubReportPropertiesServiceFiles\hedisconfig.properties"}

get-childitem -path $SourceForHEDISSubReportProperties -recurse -include *.xml | Copy-Item -destination "$DestinationForHEDISSubReportPropertiesServiceFiles"
get-childitem -path $SourceForHEDISSubReportProperties -recurse -include *.xml | Copy-Item -destination "$DestinationForHEDISSubReportPropertiesUIFiles"

if (Test-Path ($HEDISSubReportingWelcomeDir))
{}
else{New-Item ($HEDISSubReportingWelcomeDir)-type directory -force | out-null}

get-childitem -path $HEDISSubReportingWelcomeDirSource -recurse -include *.ico | Copy-Item -destination "$HEDISSubReportingWelcomeDir"

Write-HostWithLogandColor "Copy War file" Green
if((Test-Path $DestinattionPathForHEDISSSubReportUIWarFiles) -eq $False)
{
	New-Item ($DestinattionPathForHEDISSSubReportUIWarFiles) -type directory -force | out-null
}
if ((Test-Path "$SourceForHEDISSubReportWarFiles" ) -and [string]$HEDIS_Submission_Required -eq "True" )
{
get-childitem -path $SourceForHEDISSubReportWarFiles -recurse -include "HedisApp.war" | Copy-Item -destination "$DestinattionPathForHEDISSSubReportUIWarFiles"
}
if((Test-Path $DestinattionPathForHEDISSSubReportServiceWarFiles) -eq $False)
{
	New-Item ($DestinattionPathForHEDISSSubReportServiceWarFiles) -type directory -force | out-null
}
if ((Test-Path "$SourceForHEDISSubReportWarFiles" ) -and [string]$HEDIS_Submission_Required -eq "True" )
{
get-childitem -path $SourceForHEDISSubReportWarFiles -recurse -include "HedisWebservice.war" | Copy-Item -destination "$DestinattionPathForHEDISSSubReportServiceWarFiles"
}
if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"
Write-HostWithLogandColor "Deployed HedisSub Reporting WAR and Properties Files" Yellow
Write-HostWithLogandColor $dashline Gray
}

#GPRO
if (([string]$GPRO_Required -eq "True")-and [string]$GPRO_Year -eq "2020")
{
Write-HostWithLogandColor "ACO GPRO 2020 SQL Server Name: $Clinical_DB_Server" White
Write-HostWithLogandColor "ACO GPRO 2020 Netezza Server Name: $NetezzaServer" White
Write-HostWithLogandColor "ACO GPRO 2020 Database Name: $Clinical_DB_Name `n" White
Write-HostWithLogandColor "Started ACO-GPRO 2020 Deployment `n" Yellow
if (Test-Path ($DestinationForGPRO20PropertiesFiles))
{}
else{New-Item ($DestinationForGPRO20PropertiesFiles)-type directory -force | out-null}
if (Test-Path "$SourceForGPRO20Properties\database.properties")
{Get-Content "$SourceForGPRO20Properties\database.properties" | ForEach-Object { $_ -replace "<DriverClassName>","$FinalDriverClassNameACO" -replace "<GPROConnectionString>","$GPROConnectionString" -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port"} | Set-Content "$DestinationForGPRO20PropertiesFiles\database.properties"}
if (Test-Path "$SourceForGPRO20Properties\acogpro.properties")
{Get-Content "$SourceForGPRO20Properties\acogpro.properties" | ForEach-Object { $_ -replace "<DatabaseType>","$FDatabaseTypeACO" -replace "<TEMPLATE_PATHGPRO>","$TEMPLATE_PATHGPRO20"} | Set-Content "$DestinationForGPRO20PropertiesFiles\acogpro.properties"}

get-childitem -path $SourceForGPRO20Properties -recurse -include *.xml | Copy-Item -destination "$DestinationForGPRO20PropertiesFiles"
get-childitem -path $SourceForGPRO20Properties -recurse -include *.xlsx | Copy-Item -destination "$DestinationForGPRO20PropertiesFiles"

if((Test-Path $DestinattionPathForGPRO20WarFiles) -eq $False)
{
	New-Item ($DestinattionPathForGPRO20WarFiles) -type directory -force | out-null
}
if ((Test-Path "$SourceForGPRO20WarFiles" ) -and [string]$GPRO_Required -eq "true" )
{
get-childitem -path $SourceForGPRO20WarFiles -recurse -include *.war | Copy-Item -destination "$DestinattionPathForGPRO20WarFiles"
}
if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"

Write-HostWithLogandColor "Deployed ACOGPRO2020 WAR and Properties files" Yellow 
Write-HostWithLogandColor $dashline Gray 
}

#GPRO 2021
if (([string]$GPRO_Required -eq "True")-and [string]$GPRO_Year -eq "2021")
{
Write-HostWithLogandColor "ACO GPRO 2021 SQL Server Name: $Clinical_DB_Server" White
Write-HostWithLogandColor "ACO GPRO 2021 Netezza Server Name: $NetezzaServer" White
Write-HostWithLogandColor "ACO GPRO 2021 Database Name: $Clinical_DB_Name `n" White
Write-HostWithLogandColor "Started ACO-GPRO 2021 Deployment `n" Yellow
if (Test-Path ($DestinationForGPRO21PropertiesFiles))
{}
else{New-Item ($DestinationForGPRO21PropertiesFiles)-type directory -force | out-null}
if (Test-Path "$SourceForGPRO21Properties\database.properties")
{Get-Content "$SourceForGPRO21Properties\database.properties" | ForEach-Object { $_ -replace "<DriverClassName>","$FinalDriverClassNameACO" -replace "<GPROConnectionString>","$GPROConnectionString" -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port"} | Set-Content "$DestinationForGPRO21PropertiesFiles\database.properties"}
if (Test-Path "$SourceForGPRO21Properties\acogpro.properties")
{Get-Content "$SourceForGPRO21Properties\acogpro.properties" | ForEach-Object { $_ -replace "<DatabaseType>","$FDatabaseTypeACO" -replace "<TEMPLATE_PATHGPRO>","$TEMPLATE_PATHGPRO21"} | Set-Content "$DestinationForGPRO21PropertiesFiles\acogpro.properties"}

get-childitem -path $SourceForGPRO21Properties -recurse -include *.xml | Copy-Item -destination "$DestinationForGPRO21PropertiesFiles"
get-childitem -path $SourceForGPRO21Properties -recurse -include *.xlsx | Copy-Item -destination "$DestinationForGPRO21PropertiesFiles"

if((Test-Path $DestinattionPathForGPRO21WarFiles) -eq $False)
{
	New-Item ($DestinattionPathForGPRO21WarFiles) -type directory -force | out-null
}
if ((Test-Path "$SourceForGPRO21WarFiles" ) -and [string]$GPRO_Required -eq "true" )
{
get-childitem -path $SourceForGPRO21WarFiles -recurse -include *.war | Copy-Item -destination "$DestinattionPathForGPRO21WarFiles"
}
if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"

Write-HostWithLogandColor "Deployed ACOGPRO2021 WAR and Properties files" Yellow 
Write-HostWithLogandColor $dashline Gray 
}

#WraperService
if ([string]$Wrapper_Services_Required -eq "True")
{
Write-HostWithLogandColor "WraperService Server Name : $Clinical_DB_Server" White
Write-HostWithLogandColor "WraperService Database Name : $Clinical_DB_Name `n" White
Write-HostWithLogandColor "Deployment started for WraperService `n" Yellow
if (Test-Path ($DestinationForWraperServicePropertiesFiles))
{}
else{New-Item ($DestinationForWraperServicePropertiesFiles)-type directory -force | out-null}
if (Test-Path "$SourceForWraperServiceProperties\database.properties")
{Get-Content "$SourceForWraperServiceProperties\database.properties" | ForEach-Object { $_ -replace "<DriverClassName>","$FinalDriverClassName" -replace "<ConnectionString>","$WSConnectionString" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<databasejndiname>","$databasejndiname" } | Set-Content "$DestinationForWraperServicePropertiesFiles\database.properties"}
if (Test-Path "$SourceForWraperServiceProperties\services.properties")
{Get-Content "$SourceForWraperServiceProperties\services.properties" | ForEach-Object { $_ -replace "<OutputFilePathWraperService>","$OutputFilePathWraperService" -replace "<DatabaseType>","$DatabaseType" } | Set-Content "$DestinationForWraperServicePropertiesFiles\services.properties"}
if (Test-Path "$SourceForWraperServiceProperties\serviceUrlProperties.properties")
{Get-Content "$SourceForWraperServiceProperties\serviceUrlProperties.properties" | ForEach-Object { $_ -replace "<WrapperServiceURL>","$WrapperServiceURL" } | Set-Content "$DestinationForWraperServicePropertiesFiles\serviceUrlProperties.properties"}

get-childitem -path $SourceForWraperServiceProperties -recurse -include *.xml | Copy-Item -destination "$DestinationForWraperServicePropertiesFiles"

if((Test-Path $DestinattionPathForWraperServiceWarFiles) -eq $False)
{
	New-Item ($DestinattionPathForWraperServiceWarFiles) -type directory -force | out-null
}
if ((Test-Path "$SourceForWraperServiceWarFiles" ) -and [string]$Wrapper_Services_Required -eq "true" )
{
get-childitem -path $SourceForWraperServiceWarFiles -recurse -include *.war | Copy-Item -destination "$DestinattionPathForWraperServiceWarFiles"
}
if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"
Write-HostWithLogandColor "Deployed WraperService WAR and Properties File" Yellow 

Write-HostWithLogandColor $dashline Gray 

}

#State Level Submission $State_Level_Submission_Year
if ([string]$State_Level_Submission_Required -eq "True")
{
Write-HostWithLogandColor "StateLevelSubmission $State_Level_Submission_Year Server Name: $Clinical_DB_Server" White
Write-HostWithLogandColor "StateLevelSubmission $State_Level_Submission_Year Database Name: $Clinical_DB_Name `n" White
Write-HostWithLogandColor "Deployment started for State Level Submission $State_Level_Submission_Year `n" Yellow
Write-HostWithLogandColor "Deploying State Level Submission Properties `n" Yellow
if (Test-Path ($DestinationForSLSPropertiesFiles))
{}
else{New-Item ($DestinationForSLSPropertiesFiles)-type directory -force | out-null}
if (Test-Path "$SourceForSLSProperties\database.properties")
{Get-Content "$SourceForSLSProperties\database.properties" | ForEach-Object { $_ -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port" -replace "<IntegratedSecurity>","$WindowsAuth" -replace "<databasejndiname>","$SLSJNDIName"} | Set-Content "$DestinationForSLSPropertiesFiles\database.properties"}
if (Test-Path "$SourceForSLSProperties\sqlmlfqueries.properties")
{get-childitem "$SourceForSLSProperties\sqlmlfqueries.properties" | Copy-Item -destination "$DestinationForSLSPropertiesFiles\sqlmlfqueries.properties"}
if (Test-Path "$SourceForSLSProperties\sqlscfqueries.properties")
{get-childitem "$SourceForSLSProperties\sqlscfqueries.properties" | Copy-Item -destination "$DestinationForSLSPropertiesFiles\sqlscfqueries.properties"}
if (Test-Path "$SourceForSLSProperties\pldsqlqueries.properties")
{get-childitem "$SourceForSLSProperties\pldsqlqueries.properties" | Copy-Item -destination "$DestinationForSLSPropertiesFiles\pldsqlqueries.properties"}
Write-HostWithLogandColor "Deployed State Level Submission Properties `n" Yellow

get-childitem -path $SourceForSLSProperties -recurse -include *.xml | Copy-Item -destination "$DestinationForSLSPropertiesFiles"

if((Test-Path $DestinattionPathForSLSWarFiles) -eq $False)
{
	New-Item ($DestinattionPathForSLSWarFiles) -type directory -force | out-null
}
if ((Test-Path "$SourceForSLSWarFiles" ) -and [string]$State_Level_Submission_Required -eq "True" )
{
Write-HostWithLogandColor "Deploying State Level Submission war `n" Yellow 
get-childitem -path $SourceForSLSWarFiles -recurse -include *.war | Copy-Item -destination "$DestinattionPathForSLSWarFiles"
Write-HostWithLogandColor "Deployed State Level Submission war `n" Green 
}
if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"
Write-HostWithLogandColor "Completed State Level Submission Deployment $State_Level_Submission_Year `n" Yellow 
Write-HostWithLogandColor $dashline Gray 
}

#PMS
if ([string]$PMS_Required -eq "True") 
{
Write-HostWithLogandColor "PMS Server Name : $Clinical_DB_Server" White
Write-HostWithLogandColor "PMS Database Name : $Clinical_DB_Name `n" White
Write-HostWithLogandColor "started PMS Deployment `n" Yellow
Write-HostWithLogandColor "Copying PMS Properties files `n" Yellow
if (Test-Path ($DestinationForPMSPropertiesFiles))
{}
else{New-Item ($DestinationForPMSPropertiesFiles)-type directory -force | out-null}
if (Test-Path "$SourceForPMSProperties\database.properties")
{Get-Content "$SourceForPMSProperties\database.properties" | ForEach-Object { $_ -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port" -replace "<IntegratedSecurity>","$WindowsAuth"} | Set-Content "$DestinationForPMSPropertiesFiles\database.properties"}
if (Test-Path "$SourceForPMSProperties\uiconfig.properties")
{Get-Content "$SourceForPMSProperties\uiconfig.properties" | ForEach-Object { $_ -replace "<ServiceServer-URL>","$ServiceServerURL" } | Set-Content "$DestinationForPMSPropertiesFiles\uiconfig.properties"}

get-childitem -path $SourceForPMSProperties -recurse -include *.xml | Copy-Item -destination "$DestinationForPMSPropertiesFiles"
Write-HostWithLogandColor "Copied PMS Properties files `n" Green
Write-HostWithLogandColor "Deploying PMS WAR File `n" Yellow
if((Test-Path $DestinattionPathForPMSWarFile) -eq $False)
{
	New-Item ($DestinattionPathForPMSWarFile) -type directory -force | out-null
}
if ((Test-Path "$SourceForPMSWarFiles" ) -and [string]$PMS -eq "true" )
{
}
get-childitem -path $SourceForPMSWarFiles -recurse -include *.war | Copy-Item -destination "$DestinattionPathForPMSWarFile"
if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"
Write-HostWithLogandColor "Deployed PMS WAR File `n" Green 
Write-HostWithLogandColor $dashline Gray
}

#CohortQR
if (([string]$CohortQR_Required -eq "True")-and [string]$CohortQR_Year -eq "2021") 
{
Write-HostWithLogandColor "CohortQR Server Name : $Clinical_DB_Server" White
Write-HostWithLogandColor "CohortQR Database Name : $Clinical_DB_Name `n" White
Write-HostWithLogandColor "started CohortQR Deployment `n" Yellow
Write-HostWithLogandColor "Copying CohortQR Properties files `n" Yellow
if (Test-Path ($DestinationForCohortQRPropertiesFiles))
{}
else{New-Item ($DestinationForCohortQRPropertiesFiles)-type directory -force | out-null}
if (Test-Path "$SourceForCohortQRProperties\database.properties")
{Get-Content "$SourceForCohortQRProperties\database.properties" | ForEach-Object { $_ -replace "<Server-Name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Password>","$Clinical_App_SQL_Password" -replace "<DBPort>","$Clinical_DB_Port" -replace "<IntegratedSecurity>","$WindowsAuth"} | Set-Content "$DestinationForCohortQRPropertiesFiles\database.properties"}
if (Test-Path "$SourceForCohortQRProperties\cohortqrconfig.properties")
{Get-Content "$SourceForCohortQRProperties\cohortqrconfig.properties" | ForEach-Object { $_ -replace "<AuthAppClientId>","$Auth_App_Client_ID" -replace "<AuthAppClientSecret>","$Auth_App_client_Secret" -replace "<UAMServer-URL>","$UAMServerURL" -replace "<UAMPort>","$UAMApp_Server_Port" -replace "<JREServer-URL>","$JREServerURL" -replace "<JREPort>","$JRE_Server_Port"} | Set-Content "$DestinationForCohortQRPropertiesFiles\cohortqrconfig.properties"}
if (Test-Path "$SourceForCohortQRProperties\cohortqrqueries.properties")
{get-childitem -path "$SourceForCohortQRProperties\cohortqrqueries.properties"| Copy-Item -destination "$DestinationForCohortQRPropertiesFiles\cohortqrqueries.properties"}

get-childitem -path $SourceForCohortQRProperties -recurse -include *.xml | Copy-Item -destination "$DestinationForCohortQRPropertiesFiles"
Write-HostWithLogandColor "Copied CohortQR Properties files `n" Green
Write-HostWithLogandColor "Deploying CohortQR WAR File `n" Yellow
if((Test-Path $DestinattionPathForCohortQRWarFile) -eq $False)
{
	New-Item ($DestinattionPathForCohortQRWarFile) -type directory -force | out-null
}
if ((Test-Path "$SourceForCohortQRWarFiles" ) -and [string]$PMS -eq "true" )
{
}
get-childitem -path $SourceForCohortQRWarFiles -recurse -include *.war | Copy-Item -destination "$DestinattionPathForCohortQRWarFile"
if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}

get-childitem -path $MicrosoftFolder -recurse -include *.xml,*.jar | Copy-Item -destination $UploadMicrosoftFolder
get-childitem -path $SQLJDBC -recurse -include *.dll | Copy-Item -destination "$DestinationForSQLJDBC"
Write-HostWithLogandColor "Deployed CohortQR WAR File `n" Green 
Write-HostWithLogandColor $dashline Gray
}
}
if([string]$Upgrade -eq "True")
{
try
{
CopyFiles
Write-HostWithLogandColor "Deployment has been done successfully kindly restart WildFly Service " Green
}
catch
{
Write-HostWithLogandColor "Rollback due to Errors......" Gray
Write-HostWithLogandColor $Error Red
}
}