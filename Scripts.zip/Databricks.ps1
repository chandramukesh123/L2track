param([string]$SetupConfigurationFile)

$dashline = "==================================================================================="


function Write-HostWithLog{param([string]$Statement)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
	{ New-Item $LogFile  -type file | Out-Null }
	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement

}

#This function will Write to console with foreground color and in log file
function Write-HostWithLogandColor{param([string]$Statement,[string]$Color)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
	{ New-Item $LogFile -type file | Out-Null }

	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement -ForegroundColor $Color
}


function TestPaths{param([string]$FolderPath,[string]$Message)
    if(Test-Path ($FolderPath))
    {
    Write-HostWithLogandColor $Temp Gray
    Write-HostWithLogandColor "$FolderPath $Message Folder Path is valid" Gray
    Write-HostWithLogandColor $TempNewLine Gray
    }
    else
    {
    Write-HostWithLogandColor $TempNewLine Red
    Write-HostWithLogandColor "$FolderPath $Message Folder path is invalid" Red
    Write-HostWithLogandColor $Temp Red
    throw "Please enter correct folder path"
    exit 1;
    }
}


function CopyJarToDBFS {param([string]$JarFolderPath,[string]$FileSystem)
	
	$Jars = Get-ChildItem -Path $JarFolderPath -Filter "*.jar"
	Write-HostWithLog "List of Jars: $Jars" 
	
	ForEach ($jar in $Jars) {
	 $jar_file = "$JarFolderPath"+"$jar"
	 dbfs cp --overwrite "$jar_file" "$FileSystem" --profile $Profile
	 
     $ErrorLevel = $LASTEXITCODE
			
	 if ($ErrorLevel -eq 0)

		{
			Write-HostWithLogandColor "$jar deployed on $FileSystem" Green
			Write-HostWithLogandColor $dashline Gray
		}
     else 
	    {
		   Write-HostWithLogandColor "Destination $FileSystem path not found" Red
		   exit 1
		   Break
  
	    } 
	}
}

function CopyJarToDBFS_Premium {param([string]$JarFolderPath,[string]$FileSystem)
	
	$Jars = Get-ChildItem -Path $JarFolderPath -Filter "*.jar"	
	Write-HostWithLog "List of Jars: $Jars" 
	
	ForEach ($jar in $Jars) {
	 $jar_file = "$JarFolderPath"+"$jar"
	 dbfs cp --overwrite "$jar_file" "$FileSystem" --profile $Profile_Premium
	 
     $ErrorLevel = $LASTEXITCODE
			
	 if ($ErrorLevel -eq 0)

		{
			Write-HostWithLogandColor "$jar deployed on $FileSystem" Green
			Write-HostWithLogandColor $dashline Gray
		}
     else 
	    {
		   Write-HostWithLogandColor "Destination $FileSystem path not found" Red
		   exit 1
		   Break
  
	    } 
	}
}

function CreateHedisFileSystem {
	
	$foldername = @($HFS1,$HFS2,$HFS3,$HFS4,$HFS5,$HFS6,$HFS7,$HFS8,$HFS9,$HFS10)
	ForEach ($folder in $foldername) {
	dbfs mkdirs $folder --profile $Profile
	Write-HostWithLog $folder
		
	$ErrorLevel = $LASTEXITCODE
	if ($ErrorLevel -eq 2)
    {
	Write-HostWithLogandColor "Databricks File System folder $folder not created" Red
	exit $LASTEXITCODE
	break
	}
	elseif ($ErrorLevel -eq 1)
	{
	Write-HostWithLogandColor "Authorization failed, Please review the databricks token configuration or check the token expiry date" Red
	exit $ErrorLevel
	Break	
	}
	else
	{
	 Write-HostWithLogandColor "Databricks File System folder $folder created successfully" Green
	 Write-HostWithLogandColor $dashline Gray
	}	
	}
}


function CreateHEDISFileSystem_Premium {
	
	$foldername = @($HFS1,$HFS4,$HFS9)
	ForEach ($folder in $foldername) {
	dbfs mkdirs $folder --profile $Profile_Premium
	Write-HostWithLog $folder
		
	$ErrorLevel = $LASTEXITCODE
	if ($ErrorLevel -eq 2)
    {
	Write-HostWithLogandColor "Databricks File System folder $folder not created" Red
	exit $LASTEXITCODE
	break
	}
	elseif ($ErrorLevel -eq 1)
	{
	Write-HostWithLogandColor "Authorization failed, Please review the databricks token configuration or check the token expiry date" Red
	exit $ErrorLevel
	Break	
	}
	else
	{
	 Write-HostWithLogandColor "Databricks File System folder $folder created successfully" Green
	 Write-HostWithLogandColor $dashline Gray
	}	
	}
}	


function CreateContractsFileSystem {
	
	$foldername = @($CFS1,$CFS2,$CFS3,$CFS4,$CFS5,$CFS6,$CFS7,$CFS8)
	ForEach ($folder in $foldername) {
	dbfs mkdirs $folder --profile $Profile
	Write-HostWithLog $folder
		
	$ErrorLevel = $LASTEXITCODE
	if ($ErrorLevel -eq 2)
    {
	Write-HostWithLogandColor "Databricks File System folder $folder not created" Red
	exit $ErrorLevel
	Break
	}
    elseif ($ErrorLevel -eq 1)
	{
	Write-HostWithLogandColor "Authorization failed, Please review the databricks token configuration or check the token expiry date" Red
	exit $ErrorLevel
	Break	
	}
	else
	{
	 Write-HostWithLogandColor "Databricks File System folder $folder created successfully" Green
	 Write-HostWithLogandColor $dashline Gray
	}  
	}
}


function CreateDataScaleFileSystem {
	
	$foldername = @($DFS1,$DFS2,$DFS3,$DFS5,$DFS6,$DFS7,$DFS9,$DFS10,$DFS11,$DFS12,$DFS13,$DFS14,$DFS15,$DFS16,$DFS17,$DFS2_C,$DFS3_C,$DFS5_C,$DFS6_C,$DFS7_C,$DFS9_C,$DFS11_C,$DFS13_C,$DFS14_C,$DFS15_C,$DFS16_C,$DFS17_C)
	ForEach ($folder in $foldername) {
	dbfs mkdirs $folder --profile $Profile
	Write-HostWithLog $folder
		
	$ErrorLevel = $LASTEXITCODE
	
	if ($ErrorLevel -eq 2)
    {
	Write-HostWithLogandColor "Databricks File System folder $folder not created" Red
	exit $ErrorLevel
	Break
	}
	elseif ($ErrorLevel -eq 1)
	{
	Write-HostWithLogandColor "Authorization failed, Please review the databricks token configuration or check the token expiry date" Red
	exit $ErrorLevel
	Break	
	}
	else
	{
	 Write-HostWithLogandColor "Databricks File System folder $folder created successfully" Green
	 Write-HostWithLogandColor $dashline Gray
	}  
	}
}

function CreateCILFileSystem {
	
	$foldername = @($CILFS1,$CILFS2)
	ForEach ($folder in $foldername) {
	dbfs mkdirs $folder --profile $Profile
	Write-HostWithLog $folder
		
	$ErrorLevel = $LASTEXITCODE
	if ($ErrorLevel -eq 2)
    {
	Write-HostWithLogandColor "Databricks File System folder $folder not created" Red
	exit $LASTEXITCODE
	break
	}
	elseif ($ErrorLevel -eq 1)
	{
	Write-HostWithLogandColor "Authorization failed, Please review the databricks token configuration or check the token expiry date" Red
	exit $ErrorLevel
	Break	
	}
	else
	{
	 Write-HostWithLogandColor "Databricks File System folder $folder created successfully" Green
	 Write-HostWithLogandColor $dashline Gray
	}	
	}
}

function CreateMRRFileSystem {
	
	$foldername = @($MFS1,$MFS2,$MFS3)
	ForEach ($folder in $foldername) {
	dbfs mkdirs $folder --profile $Profile
	Write-HostWithLog $folder
		
	$ErrorLevel = $LASTEXITCODE
	if ($ErrorLevel -eq 2)
    {
	Write-HostWithLogandColor "Databricks File System folder $folder not created" Red
	exit $LASTEXITCODE
	break
	}
	elseif ($ErrorLevel -eq 1)
	{
	Write-HostWithLogandColor "Authorization failed, Please review the databricks token configuration or check the token expiry date" Red
	exit $ErrorLevel
	Break	
	}
	else
	{
	 Write-HostWithLogandColor "Databricks File System folder $folder created successfully" Green
	 Write-HostWithLogandColor $dashline Gray
	}	
	}
}


function CreateFolder {param([string]$FolderPath)
	$FolderExist = Test-Path $FolderPath
	    If ($FolderExist -eq $False) 
		{ New-Item -Path $FolderPath -ItemType Directory 
		Write-HostWithLogandColor "$FolderPath created" Green
		}
		else
		{
		Write-HostWithLogandColor "$FolderPath already existed" Yellow
		}
		Write-HostWithLogandColor $dashline Gray
}

function DeleteFolder {param([string]$FolderPath)
	$FolderExist = Test-Path $FolderPath
	Try{
	    If ($FolderExist -eq $True) 
		{ Remove-Item -Path $FolderPath -Recurse -ErrorAction Stop
		Write-HostWithLogandColor "$FolderPath deleted" Green
		}
		else
		{
		Write-HostWithLogandColor "$FolderPath not exist" Yellow
		}
	}
	Catch{
		Write-HostWithLogandColor "Unable to delete folder $FolderPath" Red
		Write-HostWithLogandColor $_.Exception.Message Red
		Write-HostWithLogandColor "Deployment abort" Red
		Exit 1;
	}
		Write-HostWithLogandColor $dashline Gray
}


function UpdateConfigJar{
		Copy-Item -Path (Join-Path $CommonLib_Temp $HEDIS_CONTRACTS_ConfigJar) -Destination $tempfolder -Force
		$JarFile = $tempfolder+$HEDIS_CONTRACTS_ConfigJar
		Write-HostWithLogandColor "$JarFile" Green
		Write-HostWithLogandColor "copied configuration jar files $CommonLib_Temp into $tempfolder folder" Green
	    Write-HostWithLog "Jar file $JarFile"
		Add-Type -assembly  System.IO.Compression.FileSystem
		$zip =  [System.IO.Compression.ZipFile]::Open($JarFile,"Update")
		$envJSFiles = $zip.Entries.Where({$_.name -like "database.properties"})
				
		foreach ($envJSFile in $envJSFiles)
			{
				echo "Inside For each "
				Write-HostWithLog $envJSFile
				Write-HostWithLog "Updating data in properties file"
				Write-HostWithLog "==============================================="
				$envStream = $null
				$text = $null
				$result = $null
				$envStream = $envJSFile.Open()
				$reader = New-Object IO.StreamReader($envStream)
				$text = $reader.ReadToEnd()
				$result = $text.Replace("<Server-Name>", $Cinical_Server_Name).Replace("<Database-Name>", $Clinical_DBName).Replace("<User-Name>", $Clinical_DB_UserName).Replace("<Database-Password>", $Clinical_DB_Password).Replace("<RMMServer-Name>", $RMM_Server_Name).Replace("<RMMDatabase-Name>", $RMM_DB_Name).Replace("<RMMUser-Name>", $RMM_UserName).Replace("<RMMDatabase-Password>", $RMM_DB_Password).Replace("<Result-Database>", $Result_DB).Replace("<COMMON_URL>", $Common_URL).Replace("<COMMON_URI>", $Common_URI).Replace("<AZ_SASTOKEN_KEY>", $AZ_SASTOKEN_KEY).Replace("<NATIVE_AZURE_FILE_SYSTEM>", $Native_Azure_File_System).Replace("<PLT_GEN2_STORAGE>", $PLT_GEN2_STORAGE).Replace("<DECRYPT_SASTOKEN>", $Decrypt_SASTOKEN).Replace("<DECRYPT_KEY>", $Decrypt_Key).Replace("<ProgramManagementServiceURL>", $PerformPlusURL).Replace("<auth_client_id>", $Auth_Client_Id).Replace("<auth_client_secret>", $Auth_Client_Secret).Replace("<uambaseURL>", $uambaseURL).Replace("<hiveServerlessSchemaName>", $Databricks_Premium_Schema_Name).Replace("<Databricks_Premium_Jdbc_Connection_Url>", $Databricks_Premium_Jdbc_Connection_Url).Replace("<Encrypted_Databricks_Premium_Jdbc_Password>", $Encrypted_Databricks_Premium_Jdbc_Password).Replace("<datascaleServerlessSchemaName>", $Databricks_Premium_DI_Schema_Name)
				<# $result=$text.Update($environment) #>
				#write-host "File: $envJSFile is needed to be updated with content `n $result"
				$envStream.Flush()
				$envStream.Close()
				# Re-open the file this time with streamwriter
				$desiredFile = [System.IO.StreamWriter]($envJSFile).Open()
				$desiredFile.BaseStream.SetLength(0)
				# Insert the $text to the file and close
				$desiredFile.Write($result)
				$desiredFile.Flush()
				$desiredFile.Close()		
				# sleep 5				
			}
			$zip.Dispose()
			
			
			Copy-Item -Path $JarFile -Destination $CommonLib_Temp -Force
	        Write-HostWithLogandColor "Copied modified configuration jar $JarFile to $CommonLib_Temp Folder" Green	
}

#Update DataScale Configuration files
function UpdateDSConfigJar{
		$DSConfJars = @($BDTConfJar,$DIConfJar,$DQConfJar,$DRConfJar,$DTConfJar,$DMConfJar,$DQTPMRRConfJar,$DRTPMRRConfJar,$DITPMRRConfJar,$DTTPMRRConfJar,$TPMRRConfJar,$DQ_ReportingConfJar,$Data_InsightConfJar,$DQ_MPMConfJar,$HDCConfJar)
		$DSConfTempJars = @($BDTTempJar,$DITempJar,$DQTempJar,$DRTempJar,$DTTempJar,$DMTempJar,$DQTPMRRTempJar,$DRTPMRRTempJar,$DITPMRRTempJar,$DTTPMRRTempJar,$TPMRRConfTempJar,$DQ_ReportingTempJar,$Data_InsightTempJar,$DQ_MPMTempJar,$HDCTempJar)
        ForEach ($DSConfJar in $DSConfJars) {	
		Copy-Item -Path $DSConfJar -Destination $DataScaletempfolder -Force
		Write-HostWithLogandColor "Copied configuration jar $DSConfJar to $DataScaletempfolder Folder" Green
		}
        ForEach ($DSConfTempJar in $DSConfTempJars) {	
     
		
		Add-Type -assembly  System.IO.Compression.FileSystem
		$zip =  [System.IO.Compression.ZipFile]::Open($DSConfTempJar,"Update")
		$envJSFiles = $zip.Entries.Where({$_.name -like "*.properties"})
		
		foreach ($envJSFile in $envJSFiles)
			{
				echo "Inside For each "
				Write-HostWithLog $envJSFile
				Write-HostWithLog "Updating data in properties file"
				Write-HostWithLog "==============================================="
				$envStream = $null
				$text = $null
				$result = $null
				$envStream = $envJSFile.Open()
				$reader = New-Object IO.StreamReader($envStream)
				$text = $reader.ReadToEnd()
				if (($DSConfTempJar -eq $DQTPMRRTempJar) -or ($DSConfTempJar -eq $DRTPMRRTempJar) -or ($DSConfTempJar -eq $DITPMRRTempJar) -or ($DSConfTempJar -eq $DTTPMRRTempJar) -or ($DSConfTempJar -eq $TPMRRConfTempJar) )
			
{
			$result = $text.Replace("<Server-Name>", $Cinical_Server_Name).Replace("<Database-Name>", $Clinical_DBName).Replace("<isWindowsAuthentication>", $WindowsAuthentication).Replace("<User-Name>", $Clinical_DB_UserName).Replace("<Database-Password>", $Clinical_DB_Password).Replace("<RMMServer-Name>", $RMM_Server_Name).Replace("<RMMDatabase-Name>", $RMM_DB_Name).Replace("<isWindowsAuthenticationRMM>", $WindowsAuthenticationRMM).Replace("<RMMUser-Name>", $RMM_UserName).Replace("<RMMDatabase-Password>", $RMM_DB_Password).Replace("<Result-Database>", $Result_DB).Replace("<COMMON_URL>", $Common_URL).Replace("<COMMON_URI>", $Common_URI).Replace("<AZ_SASTOKEN_KEY>", $AZ_SASTOKEN_KEY).Replace("<NATIVE_AZURE_FILE_SYSTEM>", $Native_Azure_File_System).Replace("<PLT_GEN2_STORAGE>", $PLT_GEN2_STORAGE).Replace("<DECRYPT_SASTOKEN>", $Decrypt_SASTOKEN).Replace("<DECRYPT_KEY>", $Decrypt_Key).Replace("<Mysql-Sever-Name>", $MySQL_Server_Name).Replace("<Mysql-Database>", $MySQL_Database_Name).Replace("<Mysql-UserName>", $MySQL_User).Replace("<Mysql-Password>", $MySQL_App_Password).Replace("<dbfs-base-path>", $TPMRR_DBFS_Base_Path).Replace("<dm-sql-server-name>", $Cinical_Server_Name).Replace("<dm-database-name>", $Clinical_DBName).Replace("<dm-user-name>", $Clinical_DB_UserName).Replace("<dm-db-password>", $Clinical_DB_Password).Replace("<Mysql-Port>", $MySQL_Port).Replace("<dr-base-path>", $DR_Base_Path)
				}
			else{				
			$result = $text.Replace("<Server-Name>", $Cinical_Server_Name).Replace("<Database-Name>", $Clinical_DBName).Replace("<isWindowsAuthentication>", $WindowsAuthentication).Replace("<User-Name>", $Clinical_DB_UserName).Replace("<Database-Password>", $Clinical_DB_Password).Replace("<RMMServer-Name>", $RMM_Server_Name).Replace("<RMMDatabase-Name>", $RMM_DB_Name).Replace("<isWindowsAuthenticationRMM>", $WindowsAuthenticationRMM).Replace("<RMMUser-Name>", $RMM_UserName).Replace("<RMMDatabase-Password>", $RMM_DB_Password).Replace("<Result-Database>", $Result_DB).Replace("<COMMON_URL>", $Common_URL).Replace("<COMMON_URI>", $Common_URI).Replace("<AZ_SASTOKEN_KEY>", $AZ_SASTOKEN_KEY).Replace("<NATIVE_AZURE_FILE_SYSTEM>", $Native_Azure_File_System).Replace("<PLT_GEN2_STORAGE>", $PLT_GEN2_STORAGE).Replace("<DECRYPT_SASTOKEN>", $Decrypt_SASTOKEN).Replace("<DECRYPT_KEY>", $Decrypt_Key).Replace("<Mysql-Sever-Name>", $MySQL_Server_Name).Replace("<Mysql-Database>", $MySQL_Database_Name).Replace("<Mysql-UserName>", $MySQL_User).Replace("<Mysql-Password>", $MySQL_App_Password).Replace("<dbfs-base-path>", $DBFS_Base_Path).Replace("<dm-sql-server-name>", $Cinical_Server_Name).Replace("<dm-database-name>", $Clinical_DBName).Replace("<dm-user-name>", $Clinical_DB_UserName).Replace("<dm-db-password>", $Clinical_DB_Password).Replace("<Mysql-Port>", $MySQL_Port).Replace("<dr-base-path>", $DR_Base_Path).Replace("<reverse_dm-server-name>", $Reverse_Migration_DB_Server).Replace("<reverse_dm-database-name>", $Reverse_Migration_DB_Name).Replace("<reverse_dm-user-name>", $Reverse_Migration_SQL_User).Replace("<reverse_dm-db-password>", $Reverse_Migration_SQL_Password)
			}


            #Write-Host $result				
			<# $result=$text.Update($environment) #>
			#write-host "File: $envJSFile is needed to be updated with content `n $result"
			$envStream.Flush()
			$envStream.Close()
			# Re-open the file this time with streamwriter
			$desiredFile = [System.IO.StreamWriter]($envJSFile).Open()
			$desiredFile.BaseStream.SetLength(0)
			# Insert the $text to the fil<e and close
			$desiredFile.Write($result)
			$desiredFile.Flush()
			$desiredFile.Close()		
			# sleep 5				
			}
			$zip.Dispose()
		}			
				
#Copying modified Configuration Temp jars into Build folder			
		    Copy-Item -Path $BDTTempJar -Destination $BDTConfJar -Force
			Write-HostWithLogandColor "Copying modified configuration $BDTTempJar file to $BDTConfJar Build folder" Green
		    Copy-Item -Path $DITempJar -Destination $DIConfJar -Force
			Write-HostWithLogandColor "Copying modified configuration $DITempJar file to $DIConfJar Build folder" Green
            Copy-Item -Path $DQTempJar -Destination $DQConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $DQTempJar file to $DQConfJar Build folder" Green
            Copy-Item -Path $DRTempJar -Destination $DRConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $DRTempJar file to $DRConfJar Build folder" Green
            Copy-Item -Path $DTTempJar -Destination $DTConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $DTTempJar file to $DTConfJar Build folder" Green
            Copy-Item -Path $DMTempJar -Destination $DMConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $DMTempJar file to $DMConfJar Build folder" Green	
            Copy-Item -Path $DQTPMRRTempJar -Destination $DQTPMRRConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $DQTPMRRTempJar file to $DQTPMRRConfJar Build folder" Green
            Copy-Item -Path $DRTPMRRTempJar -Destination $DRTPMRRConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $DRTPMRRTempJar file to $DRTPMRRConfJar Build folder" Green
            Copy-Item -Path $DITPMRRTempJar -Destination $DITPMRRConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $DITPMRRConfJar file to $DITPMRRConfJar Build folder" Green	 
            Copy-Item -Path $DTTPMRRTempJar -Destination $DTTPMRRConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $DTTPMRRTempJar file to $DTTPMRRConfJar Build folder" Green	
            Copy-Item -Path $TPMRRConfTempJar -Destination $TPMRRConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $TPMRRConfTempJar file to $TPMRRConfJar Build folder" Green
			Copy-Item -Path $DQ_ReportingTempJar -Destination $DQ_ReportingConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $DQ_ReportingTempJar file to $DMConfJar Build folder" Green	
			Copy-Item -Path $Data_InsightTempJar -Destination $Data_InsightConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $Data_InsightTempJar file to $DMConfJar Build folder" Green
            Copy-Item -Path $DQ_MPMTempJar -Destination $DQ_MPMConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $DQ_MPMTempJar file to $DMConfJar Build folder" Green				
			Copy-Item -Path $HDCTempJar -Destination $HDCConfJar -Force	
			Write-HostWithLogandColor "Copying modified configuration $HDCTempJar file to $HDCConfJar Build folder" Green			
}

function UpdateMRRConfigJar{
	$jarFiles = Get-ChildItem -Path $MRR_Path_Temp -Recurse -Filter "*.jar" -File | Select-Object -ExpandProperty FullName
	
	foreach ($jarFile in $jarFiles) {
    
		Write-HostWithLogandColor "$JarFile" Green
		Write-HostWithLog "Jar file $JarFile"
		Add-Type -assembly  System.IO.Compression.FileSystem
		$zip =  [System.IO.Compression.ZipFile]::Open($JarFile,"Update")
		$envJSFiles = $zip.Entries.Where({$_.name -like "database.properties"})
		
		foreach ($envJSFile in $envJSFiles)
			{
				echo "Inside For each "
				Write-HostWithLog $envJSFile
				Write-HostWithLog "Updating data in properties file"
				Write-HostWithLog "==============================================="
				$envStream = $null
				$text = $null
				$result = $null
				$envStream = $envJSFile.Open()
				$reader = New-Object IO.StreamReader($envStream)
				$text = $reader.ReadToEnd()
				$result = $text.Replace("<MRRServer-Name>", $MRR_Server_Name).Replace("<MRRDatabase-Name>", $MRR_DB_Name).Replace("<MRRUser-Name>", $MRR_UserName).Replace("<MRRDatabase-Password>", $MRR_DB_Password)
				<# $result=$text.Update($environment) #>
				#write-host "File: $envJSFile is needed to be updated with content `n $result"
				$envStream.Flush()
				$envStream.Close()
				# Re-open the file this time with streamwriter
				$desiredFile = [System.IO.StreamWriter]($envJSFile).Open()
				$desiredFile.BaseStream.SetLength(0)
				# Insert the $text to the file and close
				$desiredFile.Write($result)
				$desiredFile.Flush()
				$desiredFile.Close()		
				# sleep 5				
			}
			$zip.Dispose()
	}
	
}
#region read environment details from DataRepresentation.config file
[xml]$xmlConfigFile = new-object XML
	$xmlConfigFile.Load($SetupConfigurationFile)
	
	$LogFolderPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/LogFile_FolderPath").getAttribute("Log_FolderPath_M")
	$LogFile =$LogFolderPath+ "\Log.txt"
	
	Write-HostWithLog "#################################################################################"
	Write-HostWithLog "#################################################################################"
	Write-HostWithLog "## This Powershell is property of Citiustech"
	Write-HostWithLog "## Do not make any changes without product team confirmation"
	Write-HostWithLog "## Created by : PLT DevOps"
	Write-HostWithLog "## "
	Write-HostWithLog "## Running Databricks.ps1"
	Write-HostWithLog "## Deploying jar libraries on dbfs workspace"
	Write-HostWithLog "##"
	Write-HostWithLog "## Do not close this window until deployment is successful"
	Write-HostWithLog "#################################################################################"
	Write-HostWithLog "#################################################################################"	
	Write-HostWithLogandColor "Started Databricks Installation" Gray 
	Write-HostWithLogandColor $dashline Gray
	
	Write-HostWithLogandColor "Loading $SetupConfigurationFile..." Yellow
	$BuildFolderPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Build_FolderPath").getAttribute("Build_FolderPath_M")
	TestPaths $BuildFolderPath
	Write-HostWithLog "Build Folder Path : $BuildFolderPath "
	Write-HostWithLog "Log Folder Path : $LogFolderPath "
	
	$DataBricksRequired=$xmlConfigFile.selectSingleNode("/Configuration/Component").getAttribute("DataBricks")
	$HEDIS_Required=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/DataBricks_Server_Details").getAttribute("A_HEDIS_Required")
	Write-HostWithLog "Hedis Required : $HEDIS_Required"
	$Contracts_Required=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/DataBricks_Server_Details").getAttribute("B_Contracts_Required")
	Write-HostWithLog "Contracts Required : $Contracts_Required"
	$DataScale_Required=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/DataBricks_Server_Details").getAttribute("C_DataScale_Required")
	Write-HostWithLog "DataScale Required : $DataScale_Required"
	$MRR_Required=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/DataBricks_Server_Details").getAttribute("D_MRR_Required")
	Write-HostWithLog "MRR Required : $MRR_Required"
	$DBFS_Base_Path=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/DataBricks_Server_Details").getAttribute("F_DBFS_Base_Path")
	$DR_Base_Path=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/DataBricks_Server_Details").getAttribute("G_DR_Base_Path")
	
	#Databricks Details
	$FileSystemPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/DataBricks_Service_Details").getAttribute("I_File_System_Path_M")
	Write-HostWithLog "File System Path : $FileSystemPath"
	$Databricks_Premium_Jdbc_Connection_Url=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/DataBricks_Service_Details").getAttribute("E_Databricks_Premium_Jdbc_Connection_Url_M")
	Write-HostWithLog "DataBricks Premium URL : $Databricks_Premium_Jdbc_Connection_Url"
	$Encrypted_Databricks_Premium_Jdbc_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/DataBricks_Service_Details").getAttribute("F_Encrypted_Databricks_Premium_Jdbc_Password_M")
	Write-HostWithLog "DataBricks Premium Secret : $Encrypted_Databricks_Premium_Jdbc_Password"
	$Profile=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/DataBricks_Server_Details").getAttribute("E_Profile_M")
	Write-HostWithLog "Environment : $Profile" 
	#Clinical DB Details
	$Cinical_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("A_Clinical_DB_Server_M")
	Write-HostWithLog "Environment value : $Cinical_Server_Name"
    $Clinical_DBName=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("D_Clinical_DB_Name_M")
	Write-HostWithLog "Clinical DB Name : $Clinical_DBName"
	$Clinical_DB_UserName=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("F_Clinical_SQL_User_M")
	Write-HostWithLog "Clinical db name : $Clinical_DB_UserName"
	$Clinical_DB_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("G_Clinical_SQL_Password_M")
	Write-HostWithLog "Clinical db password : $Clinical_DB_Password"
	#RMM DB Details	
	$RMM_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("A_RMM_DB_Server_M")
	Write-HostWithLog "RMM Server Name : $RMM_Server_Name"
	$RMM_DB_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("D_RMM_DB_Name_M")
	Write-HostWithLog "RMM DB Name : $RMM_DB_Name"
	$RMM_UserName=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("F_RMM_SQL_User_M")
	Write-HostWithLog "RMM Username : $RMM_UserName"
	$RMM_DB_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("G_RMM_SQL_Password_M")
	Write-HostWithLog "RMM DB Password : $RMM_DB_Password"	
	#MRR DB Details
	$MRR_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MRR_Server_Details").getAttribute("A_MRR_DB_Server")
	Write-HostWithLog "MRR Server Name : $MRR_Server_Name"
	$MRR_DB_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MRR_Server_Details").getAttribute("D_MRR_DB_Name")
	Write-HostWithLog "MRR DB Name : $MRR_DB_Name"
	$MRR_UserName=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MRR_Server_Details").getAttribute("F_MRR_SQL_User")
	Write-HostWithLog "MRR Username : $MRR_UserName"
	$MRR_DB_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MRR_Server_Details").getAttribute("G_MRR_SQL_Password")
	Write-HostWithLog "MRR DB Password : $MRR_DB_Password"	
	Write-HostWithLogandColor $dashline Gray
	#Azure parameters
	$Azure_Storage_Account_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Azure_Parameters").getAttribute("A_Azure_Storage_Account_Name_M")
	Write-HostWithLog "Azure Storage Account Name : $Azure_Storage_Account_Name"
	$Azure_Storage_Container_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Azure_Parameters").getAttribute("B_Azure_Storage_Container_Name_M")
	Write-HostWithLog "Azure Storage Container Name : $Azure_Storage_Container_Name"
	$Decrypt_SASTOKEN=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Azure_Parameters").getAttribute("C_Decrypt_SAS_Token_M")
	Write-HostWithLog "Decrypt SAS Token : $Decrypt_SASTOKEN"
	$Decrypt_Key=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Azure_Parameters").getAttribute("D_Decrypt_Key_M")
	Write-HostWithLog "Decrypt key : $Decrypt_Key"
	$Result_DB=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Azure_Parameters").getAttribute("E_Result_DB_Server_M")
	Write-HostWithLog "Result db server : $Result_DB"

#Programme Management URL Parameters	
	$PerformPlus_App_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/PerformPlus_Server_Details").getAttribute("PerformPlus_App_Server_Name")
	Write-HostWithLog "PerformPlus_App_Server_Name : $PerformPlus_App_Server_Name"
	$PerformPlus_App_port=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/PerformPlus_Server_Details").getAttribute("PerformPlus_App_port")
	Write-HostWithLog "PerformPlus_App_port : $PerformPlus_App_port"
	$IsHttps_Required=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Web_String").getAttribute("IsHttps_Required")
	Write-HostWithLog "IsHttps_Required : $IsHttps_Required"
	
	if($PerformPlus_App_port -eq "80" -or $PerformPlus_App_port -eq "443")
	{
	$PerformPlusURL = $PerformPlus_App_Server_Name
	}
	else
	{
	$PerformPlusURL= $PerformPlus_App_Server_Name+":"+$PerformPlus_App_port
	}
	
	if ($IsHttps_Required -eq "True")
	{
	$PerformPlusURL="https://"+$PerformPlusURL
	}
	else
	{
	$PerformPlusURL="http://"+$PerformPlusURL
	}
	
	Write-HostWithLog "ProgramManagementServiceURL : $PerformPlusURL"
	
#UAM Auth Parameters	
	$UAMApp_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Auth").getAttribute("A_UAMApp_Server_Name")
	Write-HostWithLog "UAMApp_Server_Name : $UAMApp_Server_Name"
	$UAMApp_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Auth").getAttribute("B_UAMApp_Server_Port")
	Write-HostWithLog "UAMApp_Server_Port : $UAMApp_Server_Port"
	$Auth_Client_Id=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Auth").getAttribute("C_Auth_Client_Id")
	Write-HostWithLog "SSO_client_id : $Auth_Client_Id"
	$Auth_Client_Secret=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Auth").getAttribute("D_Auth_Client_Secret")
	Write-HostWithLog "SSO_client_secret : $Auth_Client_Secret"

		
	if($UAMApp_Server_Port -eq "80" -or $UAMApp_Server_Port -eq "443")
		{
			$uambaseURL = $UAMApp_Server_Name
		}
		else
		{
		$uambaseURL= $UAMApp_Server_Name+":"+$UAMApp_Server_Port
		}
		
		if ($IsHttps_Required -eq "True")
		{
		
		$uambaseURL="https://"+$uambaseURL

		}
		else
		{
		$uambaseURL="http://"+$uambaseURL
		}
	
	
	
	$COMMON_URL="https://"+$Azure_Storage_Account_Name+".blob.core.windows.net/"+$Azure_Storage_Container_Name+"/patient_data_creation/?"
	Write-HostWithLog "Common URL : $Common_URL"	
	$COMMON_URI="wasbs://"+$Azure_Storage_Container_Name+"@"+$Azure_Storage_Account_Name+".blob.core.windows.net/"
    Write-HostWithLog "Common URI : $Common_URI"  	
	$AZ_SASTOKEN_KEY="fs.azure.sas."+$Azure_Storage_Container_Name+"."+$Azure_Storage_Account_Name+".blob.core.windows.net"
	Write-HostWithLog "AZ SAS Token Key : $AZ_SASTOKEN_KEY"
	$Native_Azure_File_System="org.apache.hadoop.fs.azure.NativeAzureFileSystem"
    Write-HostWithLog "Native Azure File System : $Native_Azure_File_System"	
	$PLT_GEN2_STORAGE="$Azure_Storage_Account_Name"
	Write-HostWithLog "PLT GEN2 Storage : $PLT_GEN2_STORAGE"

	
	Write-HostWithLogandColor $dashline Gray
	
	$MySQL_Server=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MySQL_Server_Details").getAttribute("A_MySQL_Server_Name_M")
	$MySQL_Server_Name="$MySQL_Server.mysql.database.azure.com"
	Write-HostWithLog "MySQL Server Name : $MySQL_Server_Name"
	$MySQL_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MySQL_Server_Details").getAttribute("B_MySQL_Port_M")
	Write-HostWithLog "MySQL Port : $MySQL_Port"	
	$MySQL_Database_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MySQL_Server_Details").getAttribute("C_MySQL_Database_Name_M")
	Write-HostWithLog "MySQL Database Name : $MySQL_Database_Name"	
	$MySQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MySQL_Server_Details").getAttribute("D_MySQL_User_M")
	Write-HostWithLog "MySQL User Name : $MySQL_User"	
    $MySQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MySQL_Server_Details").getAttribute("E_MySQL_Password_M")
	Write-HostWithLog "MySQL Password : $MySQL_Password"	
    $MySQL_App_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MySQL_Server_Details").getAttribute("F_MySQL_APP_Password_M")
    Write-HostWithLog "MySQL App Password : $MySQL_App_Password"
	Write-HostWithLogandColor $dashline Gray
	
	#Databricks Premium Hive Schema Name Details
	$Databricks_Premium_Schema_Name=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/DataBricks_Premium_Server_Details").getAttribute("A_Databricks_Premium_Schema_Name_M")
	Write-HostWithLog "Databricks_Premium_Schema_Name : $Databricks_Premium_Schema_Name"
	$Profile_Premium=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/DataBricks_Premium_Server_Details").getAttribute("B_Profile_Premium_M")
	Write-HostWithLog "Profile_Premium : $Profile_Premium"
	$Databricks_Premium_DI_Schema_Name=$xmlConfigFile.selectSingleNode("/Configuration/DataBricks/DataBricks_Premium_Server_Details").getAttribute("C_Databricks_Premium_DI_Schema_Name_M")
	Write-HostWithLog "Databricks_Premium_DI_Schema_Name : $Databricks_Premium_DI_Schema_Name"
	Write-HostWithLogandColor $dashline Gray
	
	#Reverse Migration server details
	$Reverse_Migration_DB_Server=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Reverse_Migration_Server_Details").getAttribute("A_Reverse_Migration_DB_Server")
	Write-HostWithLog "Reverse_Migration_DB_Server : $Reverse_Migration_DB_Server"
	$Reverse_Migration_DB_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Reverse_Migration_Server_Details").getAttribute("D_Reverse_Migration_DB_Name")
	Write-HostWithLog "Reverse_Migration_DB_Name : $Reverse_Migration_DB_Name"
	$Reverse_Migration_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Reverse_Migration_Server_Details").getAttribute("F_Reverse_Migration_SQL_User")
	Write-HostWithLog "Reverse_Migration_SQL_User : $Reverse_Migration_SQL_User"
	$Reverse_Migration_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Reverse_Migration_Server_Details").getAttribute("G_Reverse_Migration_SQL_Password")
	Write-HostWithLog "Reverse_Migration_SQL_Password : $Reverse_Migration_SQL_Password"
	
#endregion
	
#HEDIS Folder Paths	
if ([string]  $HEDIS_Required -eq "True") {

	#Define HEDIS jar folder path for the deployment of jar
	$JREJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Hedis" + "\Rule_Engine\"
	Write-HostWithLog "JRE Build Folder Path : $JREJarFolderPath"
	$PatientJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Hedis" + "\Patient_Data_Curation\"
	Write-HostWithLog "PatientDataCuration Build Folder Path : $PatientJarFolderPath"
	$PRMDJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Hedis" + "\PRMD_Intermediate\"
	Write-HostWithLog "Configuration Build Folder Path : $PRMDJarFolderPath"
	$ReportingDataJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Hedis" + "\Reporting_Data\"
	Write-HostWithLog "Reporting Data Build Folder Path : $ReportingDataJarFolderPath"
	$HEDISOutputJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Hedis" + "\Output_Files\"
	Write-HostWithLog "HEDIS Output files Build Folder Path : $HEDISOutputJarFolderPath"
	$IncrementalDataJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Hedis" + "\Incremental_Data\"
	Write-HostWithLog "Incremental Data Build Folder Path : $IncrementalDataJarFolderPath"
	$ServerlessDBJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Hedis" + "\Serverless_DB\"
	Write-HostWithLog "Serverless DB Build Folder Path : $ServerlessDBJarFolderPath"
    $UserSyncupJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Hedis" + "\User_Syncup\"
	Write-HostWithLog "User_Syncup Build Folder Path : $User_SyncupJarFolderPath"
	$CILJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\CIL\"
	Write-HostWithLog "CIL Build Folder Path : $CILJarFolderPath"	
	Write-HostWithLogandColor $dashline Gray
	
	$CommonLib_Path= $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Common_Lib\*"	
	$CommonLib_Temp= $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Common_Lib_temp\"

	Write-HostWithLog "Common Library Build Folder Path : $CommonLib_Temp"
	CreateFolder $CommonLib_Temp
	Write-HostWithLog "Copying CommonLib folder to $CommonLib_Temp "	
	Copy-Item -Path $CommonLib_Path -Destination $CommonLib_Temp -Force -Recurse
	Write-HostWithLog "Copied CommonLib folder to $CommonLib_Temp "
	
	
	#HEDIS-Contracts Jar temp file path
	$tempfolder="C:\Windows\Temp\ConfigJarsHEDIS_Contracts\"
	$HEDIS_CONTRACTS_ConfigJar = "config-reader-1.0-SNAPSHOT.jar"
	
	#HEDIS DBFS file system folders
	$HFS1 = "dbfs:"+ $FileSystemPath + "HEDIS/"
	Write-HostWithLog "HEDIS File System Folder Path : $HFS1"
	$HFS2 = $HFS1 + "Rule_Engine/"
	Write-HostWithLog "JRE File System Subfolder Path : $HFS2"
	$HFS3 = $HFS1 + "Patient_Data_Curation/"
	Write-HostWithLog "Patient Data Curation File System Subfolder Path : $HFS3"
	$HFS4 = $HFS1 + "Common_Lib/"
	Write-HostWithLog "Common Library File System Subfolder Path : $HFS4"
	$HFS5 = $HFS1 +"PRMD_Intermediate/"
	Write-HostWithLog "PRMD File System Subfolder Path : $HFS5"
	$HFS6 = $HFS1 +"Reporting_Data/"
	Write-HostWithLog "Reporting Data File System Subfolder Path : $HFS6"
	$HFS7 = $HFS1 +"Output_Files/"
	Write-HostWithLog "Output Files File System Subfolder Path : $HFS7"	
	$HFS8 = $HFS1 +"Incremental_Data/"
	Write-HostWithLog "Incremental Data File System Subfolder Path : $HFS8"
	$HFS9 = $HFS1 +"Serverless_DB/"
	Write-HostWithLog "Serverless DataBase File System Subfolder Path : $HFS9"
    $HFS10 = $HFS1 +"User_Syncup/"
	Write-HostWithLog "User_Syncup File System Subfolder Path : $HFS10"
	
	#HEDIS DBFS file system folders
	$CILFS1 = "dbfs:"+ $FileSystemPath + "CIL/"
	Write-HostWithLog "CIL File System Folder Path : $CILFS1"
	$CILFS2 = $CILFS1 + "Common_Lib/"
	Write-HostWithLog "Common Library File System Subfolder Path : $CILFS2"
		
}

if ([string] $HEDIS_Required -eq "True") {
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "Started HEDIS libraries deployment" Yellow
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
TestPaths $JREJarFolderPath
TestPaths $PatientJarFolderPath
TestPaths $CommonLib_Temp
TestPaths $PRMDJarFolderPath
TestPaths $ReportingDataJarFolderPath
TestPaths $HEDISOutputJarFolderPath
TestPaths $IncrementalDataJarFolderPath
TestPaths $ServerlessDBJarFolderPath
TestPaths $UserSyncupJarFolderPath
#CIL
TestPaths $CILJarFolderPath

CreateFolder $tempfolder
Write-HostWithLogandColor $dashline Gray
UpdateConfigJar
CreateHedisFileSystem
CreateHEDISFileSystem_Premium
CreateCILFileSystem

CopyJarToDBFS $JREJarFolderPath $HFS2
CopyJarToDBFS $PatientJarFolderPath $HFS3
CopyJarToDBFS $CommonLib_Temp $HFS4
CopyJarToDBFS $PRMDJarFolderPath $HFS5
CopyJarToDBFS $ReportingDataJarFolderPath $HFS6
CopyJarToDBFS $HEDISOutputJarFolderPath $HFS7
CopyJarToDBFS $IncrementalDataJarFolderPath $HFS8
CopyJarToDBFS $ServerlessDBJarFolderPath $HFS9
CopyJarToDBFS $UserSyncupJarFolderPath $HFS10

#Premium Serverless DB Jars
CopyJarToDBFS_Premium $ServerlessDBJarFolderPath $HFS9
CopyJarToDBFS_Premium $CommonLib_Temp $HFS4

#CIL Jars
$CommonLib_CIL_Temp= $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Common_Lib_CIL_temp\"
robocopy "$CommonLib_Temp" "$CommonLib_CIL_Temp" config-reader-1.0-SNAPSHOT.jar
robocopy "$CommonLib_Temp" "$CommonLib_CIL_Temp" jasypt-1.9.2.jar

CopyJarToDBFS $CILJarFolderPath $CILFS1
CopyJarToDBFS $CommonLib_CIL_Temp $CILFS2

DeleteFolder $tempfolder
DeleteFolder $CommonLib_Temp
DeleteFolder $CommonLib_CIL_Temp
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "HEDIS libraries deployment completed" Yellow
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
}
else{
Write-HostWithLogandColor "HEDIS deployment is skipped" yellow
}

#Contracts Folder Paths	
if ([string] $Contracts_Required -eq "True"){
	$CompensationJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Contracts" + "\Compensation\"
	Write-HostWithLog "Compensation Build Folder Path : $CompensationJarFolderPath"
	$OutputFilesJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Contracts" + "\Output_Files\"
	Write-HostWithLog "Output files Build Folder Path : $OutputFilesJarFolderPath"
	$ProcessingJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Contracts" + "\Post_Processing\"
	Write-HostWithLog "Post Processing Build Folder Path : $ProcessingJarFolderPath"
	$ReportingJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Contracts" + "\RDM\"
	Write-HostWithLog "Reporting Build Folder Path : $ReportingJarFolderPath"
	$PreProcessingJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Contracts" + "\Pre_Processing\"
	Write-HostWithLog "Pre Processing Build Folder Path : $PreProcessingJarFolderPath"
	$UserSyncupJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Contracts" + "\User_Syncup\"
	Write-HostWithLog "User_Syncup Build Folder Path : $User_SyncupJarFolderPath"

	$CommonLib_Path= $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Common_Lib\*"	
	$CommonLib_Temp= $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\Common_Lib_temp\"

	Write-HostWithLog "Common Library Build Folder Path : $CommonLib_Temp"
	CreateFolder $CommonLib_Temp
	Write-HostWithLog "Copying CommonLib folder to $CommonLib_Temp "	
	Copy-Item -Path $CommonLib_Path -Destination $CommonLib_Temp -Force -Recurse
	Write-HostWithLog "Copied CommonLib folder to $CommonLib_Temp "
		
	#HEDIS-Contracts Jar temp file path
	$tempfolder="C:\Windows\Temp\ConfigJarsHEDIS_Contracts\"
	$HEDIS_CONTRACTS_ConfigJar = "config-reader-1.0-SNAPSHOT.jar"
	
	#Contracts Filesystem folders
	$CFS1 = "dbfs:"+ $FileSystemPath + "Contracts/"
	Write-HostWithLog "Contracts File System Path Folder Path : $CFS1"
	$CFS2 = $CFS1 + "Compensation/"
	Write-HostWithLog "Compensation File System Subfolder Path : $CFS2"
	$CFS3 = $CFS1 + "Output_Files/"
	Write-HostWithLog "Output files File System Subfolder Path : $CFS3"
	$CFS4 = $CFS1 + "Post_Processing/"
	Write-HostWithLog "Post processing File System Subfolder Path : $CFS4"
	$CFS5 = $CFS1 + "RDM/"
	Write-HostWithLog "Reporting File System Subfolder Path : $CFS5"
	$CFS6 = $CFS1 + "Common_Lib/"
	Write-HostWithLog "Contracts Common Library File System Subfolder Path : $CFS6"
	$CFS7 = $CFS1 + "Pre_Processing"
	Write-HostWithLog "Contracts Pre processing File System Subfolder Path : $CFS7"
	$CFS8 = $CFS1 + "User_Syncup"
	Write-HostWithLog "Contracts User Syncup File System Subfolder Path : $CFS8"
}

if ([string] $Contracts_Required -eq "True") {
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "Started Contracts libraries deployment" Yellow
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
TestPaths $CompensationJarFolderPath
TestPaths $OutputFilesJarFolderPath
TestPaths $ProcessingJarFolderPath
TestPaths $ReportingJarFolderPath
TestPaths $UserSyncupJarFolderPath
TestPaths $CommonLib_Temp

CreateFolder $tempfolder
Write-HostWithLogandColor $dashline Gray
UpdateConfigJar
CreateContractsFileSystem
CopyJarToDBFS $CompensationJarFolderPath $CFS2
CopyJarToDBFS $OutputFilesJarFolderPath $CFS3
CopyJarToDBFS $ProcessingJarFolderPath $CFS4
CopyJarToDBFS $ReportingJarFolderPath $CFS5
CopyJarToDBFS $CommonLib_Temp $CFS6
CopyJarToDBFS $PreProcessingJarFolderPath $CFS7
CopyJarToDBFS $UserSyncupJarFolderPath $CFS8
DeleteFolder $tempfolder
DeleteFolder $CommonLib_Temp
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "Contracts libraries deployment completed" Yellow
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
}
else{
Write-HostWithLogandColor "Contracts deployment is skipped" yellow	
}	

#DataScale JAR Folder Paths
if ([string] $DataScale_Required -eq "True"){
	
	Write-HostWithLog "Defining Datascle_temp folder path"
	
#Copying HEDIS folder to $Hedis_Temp to update properties jar and deployment to dbfs workspace
	$DataScale_Temp= $BuildFolderPath + "\Spark-JAVA" + "\Build" + "\DataScale_Temp"
	$DataScale_Path= $BuildFolderPath + "\Spark-JAVA" + "\Build" + "\DataScale\*"
	CreateFolder $DataScale_Temp
	Write-HostWithLog "Copying Datascale folder to $DataScale_Temp "	
	Copy-Item -Path $DataScale_Path -Destination $DataScale_Temp -Force -Recurse
	Write-HostWithLog "Copied Datascale folder to DataScale_Temp "
	
#DataScale config Jar temp file path
	$DataScaletempfolder="C:\Windows\Temp\ConfigJarsDataScale\"
	
    $DataQualityJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Quality\" + "\lib\"
	Write-HostWithLog "DataQuality Build Folder Path : $DataQualityJarFolderPath"
	$DataMigrationJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Migration\" + "\lib\"
    Write-HostWithLog "Data Migration Build Folder Path : $DataMigrationJarFolderPath"
	$DRJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Reconciliation\" + "\lib\"
    Write-HostWithLog "Data Reconciliation Build Folder Path : $DRJarFolderPath"
	$DIJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Ingestion\" + "\lib\"
	Write-HostWithLog "Data Ingestion Build Folder Path : $DIJarFolderPath"
	$DTJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Transformation\" + "\lib\"
	Write-HostWithLog "Data Transformation Build Folder Path : $DTJarFolderPath"
	$BasicDTJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Basic_Data_Transformer\" + "\lib\" 
	Write-HostWithLog "Basic Data Transformer Build Folder Path : $BasicDTJarFolderPath"
	$DomainIdJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Domain_Id_Partition\" + "\lib\"	
	$TPMRRJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\TPMRR\"+ "\lib\"
	$MRRJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\MRR\"+ "\lib\"
	$DQ_ReportingJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\DQ_Reporting\" + "\lib\"
	Write-HostWithLog "DataScale DQ_Reporting Build Folder Path : $DQ_ReportingJarFolderPath"
	$Data_InsightJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Insight_Report\" + "\lib\"
	Write-HostWithLog "DataScale Data_Insight_Report_Reporting Build Folder Path : $Data_InsightJarFolderPath"
	$DQ_MPMJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\DQ_MPM\" + "\lib\"
	Write-HostWithLog "DataScale DQ_MPM Build Folder Path : $DQ_MPMJarFolderPath"
	$HDCJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Historical_Data_Cleaning\" + "\lib\"
	Write-HostWithLog "DataScale Historical_Data_Cleaning Build Folder Path : $HDCJarFolderPath"
	$Schema_changeJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Schema_Change_Utility\" + "\lib\"
	Write-HostWithLog "DataScale Schema_Change_Utility Build Folder Path : $Schema_changeJarFolderPath"
	
	
#DataScale Common Lib Folder Paths
	$DataQualityCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Quality\" + "\Common_Lib\"
	Write-HostWithLog "DataQuality Build Folder Path : $DataQualityCommonLibFolderPath"
	$DataMigrationCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Migration\" + "\Common_Lib\"
    Write-HostWithLog "Data Migration Build Folder Path : $DataMigrationCommonLibFolderPath"
	$DRCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Reconciliation\" + "\Common_Lib\"
    Write-HostWithLog "Data Reconciliation Build Folder Path : $DRCommonLibFolderPath"
	$DICommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Ingestion\" + "\Common_Lib\"
	Write-HostWithLog "Data Ingestion Build Folder Path : $DICommonLibFolderPath"
	$DTCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Transformation\" + "\Common_Lib\"
	Write-HostWithLog "Data Transformation Build Folder Path : $DTCommonLibFolderPath"
	$BasicDTCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Basic_Data_Transformer\" + "\Common_Lib\"
	Write-HostWithLog "Basic Data Transformer Build Folder Path : $BasicDTCommonLibFolderPath"
	$TPMRRCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\TPMRR\" + "\Common_Lib\"
	Write-HostWithLog "Basic Data Transformer Build Folder Path : $TPMRRCommonLibFolderPath"
    $DQ_ReportingCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\DQ_Reporting\" + "\Common_Lib\"
	Write-HostWithLog "DataScale Reporting Utility Build Folder Path : $DQ_ReportingCommonLibFolderPath"
    $Data_InsightCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Insight_Report\" + "\Common_Lib\"
	Write-HostWithLog "DataScale Data_Insight_Report Build Folder Path : $Data_InsightCommonLibFolderPath"
    $DQ_MPMCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\DQ_MPM\" + "\Common_Lib\"
	Write-HostWithLog "DataScale DQ_MPM Build Folder Path : $DQ_MPMCommonLibFolderPath"	
	$HDCCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Historical_Data_Cleaning\" + "\Common_Lib\"
	Write-HostWithLog "DataScale DQ_MPM Build Folder Path : $HDCCommonLibFolderPath"
	$Schema_changeCommonLibFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Schema_Change_Utility\" + "\Common_Lib\"
	Write-HostWithLog "DataScale Schema_Change_Utility Build Folder Path : $Schema_changeCommonLibFolderPath"
	
#DataScale Configuration Jar Paths
	$BDTConfJar = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Basic_Data_Transformer" + "\lib" + "\BDT_properties.jar"
	Write-HostWithLog "Basic Data Transformer Configuration jar file : $BDTConfJar"
    $DIConfJar = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Ingestion" + "\lib"  + "\DI_properties.jar"
	Write-HostWithLog "Data Ingestion Configuration jar file : $DIConfJar"
    $DQConfJar = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Quality" + "\lib"  + "\DQ_properties.jar"
	Write-HostWithLog "Data Quality Configuration jar file : $DQConfJar"		
    $DRConfJar = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Reconciliation" + "\lib"  + "\DR_properties.jar"
	Write-HostWithLog "Data Reconciliation Configuration jar file : $DRConfJar"	
    $DTConfJar = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Transformation" + "\lib"  + "\DT_properties.jar"
	Write-HostWithLog "Data Transformation Configuration jar file : $DTConfJar"
    $DMConfJar = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Migration" + "\lib"  + "\DM_properties.jar"
	Write-HostWithLog "Data Migration Configuration jar file : $DMConfJar"	
    $DQ_ReportingConfJar = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\DQ_Reporting" + "\lib"  + "\DQ_RU_properties.jar"
	Write-HostWithLog "DQ_Reporting Configuration jar file : $DQ_RU_properties.jar"
    $Data_InsightConfJar = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Data_Insight_Report" + "\lib"  + "\Data_Insight_Report_properties.jar"
	Write-HostWithLog "Data_Insight_Report Configuration jar file : $Data_Insight_Report_properties.jar"
    $DQ_MPMConfJar = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\DQ_MPM" + "\lib"  + "\DQ_MPM_properties.jar"
	Write-HostWithLog "DQ_MPM Configuration jar file : $DQ_MPM_properties.jar"	
	$HDCConfJar = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\Historical_Data_Cleaning" + "\lib"  + "\HDC_properties.jar"
	Write-HostWithLog "Historical_Data_Cleaning Configuration jar file : $HDC_properties.jar"
	
	$DQTempJar = $DataScaletempfolder+ "\DQ_properties.jar"
	Write-HostWithLog "Data Quality Configuration jar file : $DQTempJar"
	$DRTempJar = $DataScaletempfolder+ "\DR_properties.jar"	
    Write-HostWithLog "Data Reconciliation Configuration jar file : $DRTempJar"
	$DITempJar = $DataScaletempfolder+ "\DI_properties.jar"
	Write-HostWithLog "Data Ingestion Configuration jar file : $DITempJar"
	$DTTempJar = $DataScaletempfolder+ "\DT_properties.jar"
	Write-HostWithLog "Data Transformation Configuration jar file : $DTTempJar"
	$BDTTempJar = $DataScaletempfolder+ "\BDT_properties.jar"
	Write-HostWithLog "Basic Data Transformer Configuration jar file : $BDTTempJar"
	$DMTempJar = $DataScaletempfolder+ "\DM_properties.jar"
	Write-HostWithLog "Basic Data Transformer Configuration jar file : $DMTempJar" 
	$DQ_ReportingTempJar = $DataScaletempfolder+ "\DQ_RU_properties.jar"
	Write-HostWithLog "DQ_Reporting Configuration jar file : $DQ_ReportingTempJar" 
    $Data_InsightTempJar = $DataScaletempfolder+ "\Data_Insight_Report_properties.jar"
	Write-HostWithLog "Data_Insight_Report Configuration jar file : $Data_InsightTempJar"
    $DQ_MPMTempJar = $DataScaletempfolder+ "\DQ_MPM_properties.jar"
	Write-HostWithLog "DQ_MPM_properties Configuration jar file : $DQ_MPMTempJar"
	$HDCTempJar = $DataScaletempfolder+ "\HDC_properties.jar"
	Write-HostWithLog "Historical_Data_Cleaning Configuration jar file : $HDC_properties"	

#TPMRR configuration Jar Paths
    $TPMRRConfJarPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\DataScale_Temp" + "\TPMRR" + "\lib"
	
	$DQTPMRRConfJar = $TPMRRConfJarPath+ "\DQ_TPMRR_properties.jar"
    Write-HostWithLog "Data Quality TPMRR Configuration jar file : $DQTPMRRConfJar"
	$DRTPMRRConfJar = $TPMRRConfJarPath+ "\DR_TPMRR_properties.jar"
    Write-HostWithLog "Data Reconciliation TPMRR Configuration jar file : $DRTPMRRConfJar"		
	$DITPMRRConfJar = $TPMRRConfJarPath+ "\DI_TPMRR_properties.jar"
    Write-HostWithLog "Data Ingestion TPMRR Configuration jar file : $DITPMRRConfJar"
	$DTTPMRRConfJar = $TPMRRConfJarPath+ "\DT_TPMRR_properties.jar"
    Write-HostWithLog "Data Transformation TPMRR Configuration jar file : $DTTPMRRConfJar"
	$TPMRRConfJar = $TPMRRConfJarPath+ "\TPMRR_properties.jar"
    Write-HostWithLog "TPMRR Configuration jar file : $TPMRRConfJar"	
	
	$DQTPMRRTempJar = $DataScaletempfolder+ "\DQ_TPMRR_properties.jar"
	Write-HostWithLog "Data Quality TPMRR Configuration jar file : $DQTPMRRTempJar"
	$DRTPMRRTempJar = $DataScaletempfolder+ "\DR_TPMRR_properties.jar"
	Write-HostWithLog "Data Reconciliation TPMRR Configuration jar file : $DRTPMRRTempJar"
	$DITPMRRTempJar = $DataScaletempfolder+ "\DI_TPMRR_properties.jar"
	Write-HostWithLog "Data Ingestion TPMRR Configuration jar file : $DITPMRRTempJar"
	$DTTPMRRTempJar = $DataScaletempfolder+ "\DT_TPMRR_properties.jar"
	Write-HostWithLog "Data Transformation TPMRR Configuration jar file : $DTTPMRRTempJar"
	$TPMRRConfTempJar = $DataScaletempfolder+ "\TPMRR_properties.jar"
	Write-HostWithLog "TPMRR Configuration jar file : $TPMRRConfTempJar"	
	
    $TPMRR_DBFS_Base_Path = $DBFS_Base_Path+ "/tpmrr"
	Write-HostWithLog "TPMRR DBFS Base Path : $TPMRR_DBFS_Base_Path"	

#DataScale FileSystem folders

    $DFS1 = "dbfs:"+ $FileSystemPath + "DataScale/"
	Write-HostWithLog "DataScale File System Path Folder Path: $DFS1"
	$DFS2 = $DFS1 + "Data_Quality/"+ "Lib/"
	Write-HostWithLog "Data Quality File System Subfolder Path : $DFS2"
	$DFS3 = $DFS1 + "Data_Migration/"+ "Lib/"
	Write-HostWithLog "Data Migration File System Subfolder Path : $DFS3"
	$DFS5 = $DFS1 + "Data_Reconciliation/"+ "Lib/"
	Write-HostWithLog "Data Reconciliation File System Subfolder Path : $DFS5"
	$DFS6 = $DFS1 + "Data_Ingestion/"+ "Lib/"
	Write-HostWithLog "Data Ingestion File System Subfolder Path : $DFS6"
	$DFS7 = $DFS1 + "Data_Transformation/"+ "Lib/"
	Write-HostWithLog "Data Transformation File System Subfolder Path : $DFS7"	
	$DFS9 = $DFS1 + "Basic_Data_Transformer/"+ "Lib/"
	Write-HostWithLog "Basic Data Transformer File System Subfolder Path : $DFS9"
	$DFS10 = $DFS1 + "Domain_Id_Partition/"+ "Lib/"
	Write-HostWithLog "Domain Id Partition File System Subfolder Path : $DFS10"
	$DFS11 = $DFS1 + "TPMRR/"+ "Lib/"
	Write-HostWithLog "TPMRR File System Subfolder Path : $DFS11"
	$DFS12 = $DFS1 + "MRR/"+ "Lib/"
	Write-HostWithLog "TPMRR File System Subfolder Path : $DFS12"
	$DFS13 = $DFS1 + "DQ_Reporting/"+ "Lib/"
	Write-HostWithLog "DQ_Reporting File System Subfolder Path : $DFS13"
	$DFS14 = $DFS1 + "Data_Insight_Report/"+ "Lib/"
	Write-HostWithLog "Data_Insight_Report File System Subfolder Path : $DFS14"
	$DFS15 = $DFS1 + "DQ_MPM/"+ "Lib/"
	Write-HostWithLog "DQ_MPM File System Subfolder Path : $DFS15"
	$DFS16 = $DFS1 + "Historical_Data_Cleaning/"+ "Lib/"
	Write-HostWithLog "Historical_Data_Cleaning File System Subfolder Path : $DFS16"
	$DFS17 = $DFS1 + "Schema_Change_Utility/"+ "Lib/"
	Write-HostWithLog "Schema_Change_Utility File System Subfolder Path : $DFS17"

# Common_Lib folder
	$DFS2_C = $DFS1 + "Data_Quality/"+ "Common_Lib/"
	Write-HostWithLog "Data Quality File System  Common_Lib Subfolder Path : $DFS2_C"
	$DFS3_C = $DFS1 + "Data_Migration/"+ "Common_Lib/"
	Write-HostWithLog "Data Migration File System  Common_Lib Subfolder Path : $DFS3_C"
	$DFS5_C = $DFS1 + "Data_Reconciliation/"+ "Common_Lib/"
	Write-HostWithLog "Data Reconciliation File System  Common_Lib Subfolder Path : $DFS5_C"
	$DFS6_C = $DFS1 + "Data_Ingestion/"+ "Common_Lib/"
	Write-HostWithLog "Data Ingestion File System Common_Lib Subfolder Path : $DFS6_C"
	$DFS7_C = $DFS1 + "Data_Transformation/"+ "Common_Lib/"
	Write-HostWithLog "Data Transformation File System Common_Lib Subfolder Path : $DFS7_C"	
	$DFS9_C = $DFS1 + "Basic_Data_Transformer/"+ "Common_Lib/"
	Write-HostWithLog "Basic Data Transformer File System Common_Lib Subfolder Path : $DFS9_C"
	$DFS11_C = $DFS1 + "TPMRR/"+ "Common_Lib/"
	Write-HostWithLog "TPMRR File System Common_Lib Subfolder Path : $DFS11_C"
    $DFS13_C = $DFS1 + "DQ_Reporting/"+ "Common_Lib/"
	Write-HostWithLog "DQ_Reporting File System Common_Lib Subfolder Path : $DFS13_C"
    $DFS14_C = $DFS1 + "Data_Insight_Report/"+ "Common_Lib/"
	Write-HostWithLog "Data_Insight_Report File System Common_Lib Subfolder Path : $DFS14_C"
    $DFS15_C = $DFS1 + "DQ_MPM/"+ "Common_Lib/"
	Write-HostWithLog "DQ_MPM File System Common_Lib Subfolder Path : $DFS15_C"
	$DFS16_C = $DFS1 + "Historical_Data_Cleaning/"+ "Common_Lib/"
	Write-HostWithLog "Historical_Data_Cleaning File System Common_Lib Subfolder Path : $DFS16_C"
	$DFS17_C = $DFS1 + "Schema_Change_Utility/"+ "Common_Lib/"
	Write-HostWithLog "Schema_Change_Utility File System Common_Lib Subfolder Path : $DFS17_C"
}	
	
if ([string] $DataScale_Required -eq "True") {
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "Started DataScale libraries deployment" Yellow
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
TestPaths $DataQualityJarFolderPath
TestPaths $DataMigrationJarFolderPath
TestPaths $DRJarFolderPath
TestPaths $DIJarFolderPath
TestPaths $DTJarFolderPath
TestPaths $BasicDTJarFolderPath
TestPaths $MRRJarFolderPath
TestPaths $DQ_ReportingJarFolderPath
TestPaths $Data_InsightJarFolderPath
TestPaths $DQ_MPMJarFolderPath
TestPaths $HDCJarFolderPath
TestPaths $Schema_changeJarFolderPath

TestPaths $DataQualityCommonLibFolderPath
TestPaths $DataMigrationCommonLibFolderPath
TestPaths $DRCommonLibFolderPath
TestPaths $DICommonLibFolderPath
TestPaths $DTCommonLibFolderPath
TestPaths $BasicDTCommonLibFolderPath
TestPaths $DQ_ReportingCommonLibFolderPath
TestPaths $Data_InsightCommonLibFolderPath
TestPaths $DQ_MPMCommonLibFolderPath
TestPaths $HDCCommonLibFolderPath
TestPaths $Schema_changeCommonLibFolderPath

Write-HostWithLogandColor $dashline Gray
CreateFolder $DataScaletempfolder
UpdateDSConfigJar
CreateDataScaleFileSystem	

CopyJarToDBFS $DataQualityJarFolderPath $DFS2
CopyJarToDBFS $DataMigrationJarFolderPath $DFS3
CopyJarToDBFS $DRJarFolderPath $DFS5
CopyJarToDBFS $DIJarFolderPath $DFS6
CopyJarToDBFS $DTJarFolderPath $DFS7
CopyJarToDBFS $BasicDTJarFolderPath $DFS9
CopyJarToDBFS $DomainIdJarFolderPath $DFS10
CopyJarToDBFS $TPMRRJarFolderPath $DFS11
CopyJarToDBFS $MRRJarFolderPath $DFS12
CopyJarToDBFS $DQ_ReportingJarFolderPath $DFS13
CopyJarToDBFS $Data_InsightJarFolderPath $DFS14
CopyJarToDBFS $DQ_MPMJarFolderPath $DFS15
CopyJarToDBFS $HDCJarFolderPath $DFS16
CopyJarToDBFS $Schema_changeJarFolderPath $DFS17

CopyJarToDBFS $DataQualityCommonLibFolderPath $DFS2_C
CopyJarToDBFS $DataMigrationCommonLibFolderPath $DFS3_C
CopyJarToDBFS $DRCommonLibFolderPath $DFS5_C
CopyJarToDBFS $DICommonLibFolderPath $DFS6_C
CopyJarToDBFS $DTCommonLibFolderPath $DFS7_C
CopyJarToDBFS $BasicDTCommonLibFolderPath $DFS9_C
CopyJarToDBFS $TPMRRCommonLibFolderPath $DFS11_C
CopyJarToDBFS $DQ_ReportingCommonLibFolderPath $DFS13_C
CopyJarToDBFS $Data_InsightCommonLibFolderPath $DFS14_C
CopyJarToDBFS $DQ_MPMCommonLibFolderPath $DFS15_C
CopyJarToDBFS $HDCCommonLibFolderPath $DFS16_C
CopyJarToDBFS $Schema_changeCommonLibFolderPath $DFS17_C

DeleteFolder $DataScaletempfolder
DeleteFolder $DataScale_Temp
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "DataScale libraries deployment completed" Yellow
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
}
else{
Write-HostWithLogandColor "DataScale deployment is skipped" yellow	
}
	
#MRR Folder Paths	
if ([string]  $MRR_Required -eq "True") {

	#Define MRR jar folder path for the deployment of jar
	$OutboundJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\MRR_Temp" + "\Outbound\"
	Write-HostWithLog "Outbound Build Folder Path : $OutboundJarFolderPath"
	$UserSyncupJarFolderPath = $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\MRR_Temp" + "\User_Syncup\"
	Write-HostWithLog "UserSyncup Build Folder Path : $UserSyncupJarFolderPath"
	Write-HostWithLogandColor $dashline Gray
	
	
	$MRR_Path= $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\MRR\*"
	$MRR_Path_Temp= $BuildFolderPath+ "\Spark-JAVA" + "\Build" + "\MRR_Temp\"
	
	Write-HostWithLog "MRR Temp Build Folder Path : $MRR_Path_Temp"
	CreateFolder $MRR_Path_Temp
	Write-HostWithLog "Copying MRR folder to $MRR_Path_Temp "	
	Copy-Item -Path $MRR_Path -Destination $MRR_Path_Temp -Force -Recurse
	Write-HostWithLog "Copied MRR Folder to $MRR_Path_Temp "
	
	#MRR DBFS file system folders
	$MFS1 = "dbfs:"+ $FileSystemPath + "MRR/"
	Write-HostWithLog "MRRFile System Folder Path : $MFS1"
	$MFS2 = $MFS1 + "Outbound/"
	Write-HostWithLog "MRROutbound File System Subfolder Path : $MFS2"
	$MFS3 = $MFS1 + "User_Syncup/"
	Write-HostWithLog "MRRUser_Syncup File System Subfolder Path : $MFS3"
					
}


if ([string] $MRR_Required -eq "True") {
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "Started MRR libraries deployment" Yellow
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
TestPaths $OutboundJarFolderPath
TestPaths $UserSyncupJarFolderPath

Write-HostWithLogandColor $dashline Gray

UpdateMRRConfigJar
CreateMRRFileSystem


CopyJarToDBFS $OutboundJarFolderPath $MFS2
CopyJarToDBFS $UserSyncupJarFolderPath $MFS3


DeleteFolder $MRR_Path_Temp
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "MRR libraries deployment completed" Yellow
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
}
else{
Write-HostWithLogandColor "MRR deployment is skipped" yellow
}
