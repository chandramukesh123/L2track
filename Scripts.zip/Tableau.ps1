﻿param([string]$SetupConfigurationFile)


function Write-HostWithLog{param([string]$Statement)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
		{ New-Item $LogFile  -type file | Out-Null }
	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement

}

#This function will Write to console with foreground color and in log file
function Write-HostWithLogandColor{param([string]$Statement,[string]$Color)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
		{ New-Item $LogFile -type file | Out-Null }

	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement -ForegroundColor $Color

}

function TestPaths{param([string]$Path)
	$PathExists = Test-Path $Path
	
	If ($PathExists -eq $False) 
	{
		throw "Path $Path Not found"
	}
}

function TestPath{param([string]$FolderPath,[string]$Message)
	if(Test-Path ($FolderPath))
	{
	Write-HostWithLogandColor $Temp Gray
	Write-HostWithLogandColor "$FolderPath $Message folder Path is valid" Gray
	Write-HostWithLogandColor $TempNewLine Gray
	}
	else
	{
	Write-HostWithLogandColor $TempNewLine Red
	Write-HostWithLogandColor "$FolderPath $Message folder path is invalid" Red
	Write-HostWithLogandColor $Temp Red
	throw "Please enter correct folder path"
	exit 1;
	}
}

function CopyFiles{
	#Copy DataSource files to temp location
	$dirs = Get-ChildItem $TargetTableauFolderPath -Recurse -include *.tdsx
	
	foreach($dir in $dirs)
	{	
		Copy-item -Path $dir -Destination $SourcesDSPath -Recurse -force
		Write-HostWithLogandColor "DataSources Name: $dir" White
	}
	#Copy Workbook files to temp location
	$dirs = Get-ChildItem $TargetTableauFolderPath -Recurse -include *.twbx
	if($I_MRR_Required -eq "True")
	{
	foreach($dir in $dirs)
	{
		Copy-item -Path $dir -Destination $SourcesWBPath -Recurse -force -exclude "PERFORM+LandingDashboard.twbx"
		Write-HostWithLogandColor "Workbook Name: $dir" White
	}
	}
	else
	{
	foreach($dir in $dirs)
	{
		Copy-item -Path $dir -Destination $SourcesWBPath -Recurse -force -exclude "PERFORM+LandingDashboardwithMRR.twbx"
		Write-HostWithLogandColor "Workbook Name: $dir" White
	}	
		
	}
}

function ReadTDS{param([string]$SourcesDSPath,[string]$ExtracttdsFilePath)
	
	$tdsFiles= Get-ChildItem -Path $SourcesDSPath -Recurse -Filter '*.tdsx'
	
	foreach($tdsFile in $tdsFiles)
	{
		$getTdsFile=$SourcesDSPath+"\"+$tdsFile
		Write-HostWithLogandColor "TDS file path $tdsFile" Green
		Add-Type -assembly  System.IO.Compression.FileSystem
		$zipArchive = [System.IO.Compression.ZipFile]::OpenRead($getTdsFile)
		$envJSFiles = $zipArchive.Entries.Where({$_.name -like "*.tds"})
		$entry = $zipArchive.GetEntry($envJSFiles)
		$stream = $entry.Open()
		$destinationPath=$ExtracttdsFilePath+"\$envJSFiles"
		$fileStream = [System.IO.File]::Create($destinationPath)
		$stream.CopyTo($fileStream)
		$fileStream.Close()
		$stream.Close()
		$zipArchive.Dispose()

		[xml]$xmlElm = Get-Content -Path $destinationPath
		$DBName = $xmlElm.datasource.connection.'named-connections'.'named-connection'.connection.'dbname'
		$server = $xmlElm.datasource.connection.'named-connections'.'named-connection'.connection.'server'

		Write-HostWithLogandColor "Database Name in TDS File $DBName" magenta
		Write-HostWithLogandColor "SQL Server Name in TDS File $server" magenta
		Remove-Item -recurse $destinationPath
		updateSQL $getTdsFile $DBName $server
		}
}

function updateSQL{
param([string]$getTdsFile,[string]$DBName,[string]$server)
	
		Add-Type -assembly  System.IO.Compression.FileSystem
		$zip =  [System.IO.Compression.ZipFile]::Open($getTdsFile,"Update")
		$envJSFiles = $zip.Entries.Where({$_.name -like "*.tds"})
				
		foreach ($envJSFile in $envJSFiles)
			{
				echo "Inside For each "
				Write-Host $envJSFile
				write-Host "Updating SQL data on tableau server"
				Write-Host "==============================================="
				$envStream = $null
				$text = $null
				$result = $null
				$envStream = $envJSFile.Open()  
				$reader = New-Object IO.StreamReader($envStream)
				$text = $reader.ReadToEnd()
				$result = $text.Replace("Dev", $Environment).Replace($DBName, $Clinical_DB_Name).Replace($server, $ClinicalDBString)
				<# $result=$text.Update($environment) #>
				#write-host "File: $envJSFile is needed to be updated with content `n $result"
				$envStream.Flush()
				$envStream.Close()
				# Re-open the file this time with streamwriter
				$desiredFile = [System.IO.StreamWriter]($envJSFile).Open()
				$desiredFile.BaseStream.SetLength(0)
				# Insert the $text to the file and close
				$desiredFile.Write($result)
				$desiredFile.Flush()
				$desiredFile.Close()		
				# sleep 5				
			}
			$zip.Dispose()
	
}

function PublishDataSource{
    Write-HostWithLog "#################################################################################"
    Write-HostWithLog "#################################################################################"
    Write-HostWithLogandColor "In Publish DataSource" White
    ##Publish DataSource

    
        ForEach($item in (Get-ChildItem -Path ($SourcesDSPath + "\*") -File -Include *.tdsx))
        {

            $publishFile = """$item"""
            if (([string]$Tableau_Main_Project_Name -eq ""))
            {
                if($Clinical_SQL_User -eq "")
                {
                    tabcmd publish $publishFile -t $Tableau_Site_Name -r $Tableau_Project_Name --overwrite
                }
                else
                {
                    tabcmd publish $publishFile -t $Tableau_Site_Name -r $Tableau_Project_Name --overwrite --db-username $Clinical_SQL_User --db-password $databasePassword --save-db-password
                }

            }
            else
            {
                if($Clinical_SQL_User -eq "")
                {
                    tabcmd publish $publishFile -t $Tableau_Site_Name --parent-project-path $Tableau_Main_Project_Name -r $Tableau_Project_Name --overwrite 
                }
                else
                {
                    tabcmd publish $publishFile -t $Tableau_Site_Name --parent-project-path $Tableau_Main_Project_Name -r $Tableau_Project_Name --overwrite --db-username $Clinical_SQL_User --db-password $databasePassword --save-db-password
                }
            }
			
			$ErrorLevel = $LASTEXITCODE
			
			if ($ErrorLevel -eq 1)

		{
			Write-HostWithLogandColor "The project does not exist, the project name is incorrect, or you do not have permission to access it. Please ensure that you have entered the correct details and have the necessary permission, and try again" red
			exit 1
			Break
		}

            Write-HostWithLogandColor $dashline Gray
            Write-HostWithLogandColor "Publish DataSource $item is done successfully" Green
            Remove-Item -recurse $item
            Write-HostWithLogandColor "Removed $item is done successfully" Red
            Write-HostWithLogandColor $dashline Gray

        }
    

}


function PublishWorkbook{
		Write-HostWithLog "#################################################################################"
		Write-HostWithLog "#################################################################################"
		Write-HostWithLogandColor "In Publish Workbook" White
		##Publish DataSource
			
		ForEach($item in (Get-ChildItem -Path ($SourcesWBPath + "\*") -File -Include *.twbx))
			{
			
				$publishFile = """$item"""
				if (([string]$Tableau_Main_Project_Name -eq ""))
				{
					tabcmd publish $publishFile -t $Tableau_Site_Name -r $Tableau_Project_Name --overwrite
					
				}
				else
				{
					tabcmd publish $publishFile -t $Tableau_Site_Name --parent-project-path $Tableau_Main_Project_Name -r $Tableau_Project_Name --overwrite
				}
				
		$ErrorLevel = $LASTEXITCODE
			
			if ($ErrorLevel -eq 1)

		{
			Write-HostWithLogandColor "The project does not exist, the project name is incorrect, or you do not have permission to access it. Please ensure that you have entered the correct details and have the necessary permission, and try again" red
			exit 1
			Break
		}
				
				Write-HostWithLogandColor $dashline Gray
				Write-HostWithLogandColor "Publish Workbook $item is done successfully" Green
				Remove-Item -recurse $item
				Write-HostWithLogandColor "Removed $item " Red
				Write-HostWithLogandColor $dashline Gray
				
			}
}
#region Read Details from File

	TestPaths $SetupConfigurationFile
	[xml]$xmlConfigFile = new-object XML
	$xmlConfigFile.Load($SetupConfigurationFile)
	
	$LogFile_FolderPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/LogFile_FolderPath").getAttribute("Log_FolderPath_M")
	$LogFile=$LogFile_FolderPath + "\Log.txt"
	Write-HostWithLogandColor "Log Path $LogFile" Green

Write-HostWithLog "#################################################################################"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "## This Powershell is property of Citiustech"
Write-HostWithLog "## Do not make any changes without product team confirmation"
Write-HostWithLog "## Created by : Kajal Nerkar"
Write-HostWithLog "## "
Write-HostWithLog "## Running Tableau.ps1"
Write-HostWithLog "##"
Write-HostWithLog "##DO not close this window until deployment is successful"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "#################################################################################"	
Write-HostWithLogandColor "Started BICDataMart Installation" Gray 
Write-HostWithLogandColor $dashline Gray 
Write-HostWithLogandColor "Loading $SetupConfigurationFile..." Yellow 
	
	$Build_Folder=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Build_FolderPath").getAttribute("Build_FolderPath_M")
	write-host "$Build_Folder path for build"
	$Build_FolderPath=$Build_Folder +"\Framework"
	Write-HostWithLogandColor "$Build_FolderPath" Green
	TestPath $Build_FolderPath "Framework Build"
	$Clinical_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Tableau/Tableau_Server_Details").getAttribute("G_SQL_UserName")

	if($Clinical_SQL_User -eq $null -or $Clinical_SQL_User -eq "")
	{
		$AuthenticationMode = "Windows Authentication"	
	}
	else
	{
		$Clinical_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Tableau/Tableau_Server_Details").getAttribute("H_SQL_Password")
		$lib=$Build_FolderPath+ "\ReleaseManagement"+"\EncryptionUtility"+"\CitiusTech.CryptographyLib.dll" 	
		[Reflection.Assembly]::LoadFrom($lib)
    	$databasePassword = [CitiusTech.Biclinical.CryptographyLib.EncryptionHelper]::DecryptPassword($Clinical_SQL_Password)
		$AuthenticationMode = "SQL Authentication"
	}
	Write-HostWithLogandColor "Authentication: $AuthenticationMode" Gray
	
	$Tableau_User=$xmlConfigFile.selectSingleNode("/Configuration/Tableau/Tableau_Server_Details").getAttribute("E_Tableau_User")
	if($Tableau_User -eq $null -or $Tableau_User -eq "")
	{
		$AuthenticationMode = "Windows Authentication"	
	}
	else
	{
		$Tableau_Password=$xmlConfigFile.selectSingleNode("/Configuration/Tableau/Tableau_Server_Details").getAttribute("F_Tableau_Password")
		$lib=$Build_FolderPath+ "\ReleaseManagement"+"\EncryptionUtility"+"\CitiusTech.CryptographyLib.dll" 	
		[Reflection.Assembly]::LoadFrom($lib)
    	$Tableau_Password = [CitiusTech.Biclinical.CryptographyLib.EncryptionHelper]::DecryptPassword($Tableau_Password)
		$AuthenticationMode = "SQL Authentication"
	}
	Write-HostWithLogandColor "Authentication: $AuthenticationMode" Gray
	
	$Tableau_Server=$xmlConfigFile.selectSingleNode("/Configuration/Tableau/Tableau_Server_Details").getAttribute("A_Tableau_Server_URL")
	$Tableau_Site_Name=$xmlConfigFile.selectSingleNode("/Configuration/Tableau/Tableau_Server_Details").getAttribute("B_Tableau_Site_Name")
	$Tableau_Main_Project_Name=$xmlConfigFile.selectSingleNode("/Configuration/Tableau/Tableau_Server_Details").getAttribute("C_Tableau_Main_Project_Name")
	$Tableau_Project_Name=$xmlConfigFile.selectSingleNode("/Configuration/Tableau/Tableau_Server_Details").getAttribute("D_Tableau_Project_Name")
	$Tableau_Required=$xmlConfigFile.selectSingleNode("/Configuration/Component").getAttribute("Tableau")
	$Clinical_DB_Server=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("A_Clinical_DB_Server_M")
	$Clinical_DB_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("C_Clinical_DB_Port_M")
	$ClinicalDBString=$Clinical_DB_Server+","+$Clinical_DB_Port
	Write-HostWithLogandColor "Clinical DB Server ConnectionString: $ClinicalDBString" Gray
	$Clinical_DB_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("D_Clinical_DB_Name_M")
	Write-HostWithLogandColor "BICDataMartDBName: $Clinical_DB_Name" Gray
	$I_MRR_Required=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("I_MRR_Required")
	Write-HostWithLogandColor "BICDataMartDBName: $Clinical_DB_Name" Gray
	$Environment=$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_SMTP").getAttribute("Enviroment")
#endregion
function ConnectTableau{
	Write-HostWithLogandColor "Login to the Tableau $Tableau_Server" Green
	tabcmd login -s $Tableau_Server -t $Tableau_Site_Name -u $Tableau_User -p $Tableau_Password
	$ErrorLevel = $LASTEXITCODE
			
if ($ErrorLevel -eq 1)

 {
	Write-HostWithLogandColor "Failed to connect to Tableau server. Please check if the server details provided are correct and if the server is currently available." red
	exit 1
	Break
 }
	
	}
if([string]$Tableau_Required -eq "True")
{
    Try {
        ##login Tableau Server
        ConnectTableau
        $TargetTableauFolderPath= $Build_FolderPath + "\Tableau_Reports"
		TestPath $TargetTableauFolderPath "Tableau reports"
        $SourcesDSPath= "C:\Windows\Temp\DataSource_Temp"
        Remove-Item $SourcesDSPath -Force -Recurse -ErrorAction SilentlyContinue
        if((Test-Path $SourcesDSPath) -eq $False)
        {
            New-Item ($SourcesDSPath) -type directory -force | out-null
        }
		$ExtracttdsFilePath="C:\Windows\Temp\ExtracttdsFilePath"
		Remove-Item $ExtracttdsFilePath -Force -Recurse -ErrorAction SilentlyContinue
        if((Test-Path $ExtracttdsFilePath) -eq $False)
        {
            New-Item ($ExtracttdsFilePath) -type directory -force | out-null
        }
		$SourcesWBPath= "C:\Windows\Temp\Workbook_Temp"
        Remove-Item $SourcesWBPath -Force -Recurse -ErrorAction SilentlyContinue
        if((Test-Path $SourcesWBPath) -eq $False)
        {
            New-Item ($SourcesWBPath) -type directory -force | out-null
        }
        CopyFiles $SourcesDSPath
		ReadTDS $SourcesDSPath $ExtracttdsFilePath
        PublishDataSource $SourcesDSPath
        PublishWorkbook $SourcesWBPath
        Write-HostWithLog "#################################################################################"
        Write-HostWithLog "#################################################################################"
        Write-HostWithLogandColor $dashline Gray
        Write-HostWithLogandColor $dashline Gray
        Write-HostWithLogandColor "Publish DataSource and Workbook Successfully" Green
        Write-HostWithLogandColor $dashline Gray
        Write-HostWithLogandColor $dashline Gray
        Write-HostWithLog "#################################################################################"
        Write-HostWithLog "#################################################################################"
        tabcmd logout
    }
    Catch {
        Write-HostWithLogandColor "Error occured while publishing to Tableau: $_" Red
	    $errorMessage = $_.Exception.Message
		exit 1
		Break
        # perform any error handling actions here
    }
}
