﻿param([string]$SetupConfigurationFile,[string]$Value="NormalUpgrade",[string]$Upgrade="True")


function Write-HostWithLog{param([string]$Statement)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
		{ New-Item $LogFile  -type file | Out-Null }
	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement

}

#This function will Write to console with foreground color and in log file
function Write-HostWithLogandColor{param([string]$Statement,[string]$Color)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
		{ New-Item $LogFile -type file | Out-Null }

	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement -ForegroundColor $Color

}

function TestPath{param([string]$FolderPath,[string]$Message)
	if(Test-Path ($FolderPath))
	{
	Write-HostWithLogandColor $Temp Gray
	Write-HostWithLogandColor "$FolderPath $Message folder Path is valid" Gray
	Write-HostWithLogandColor $TempNewLine Gray
	}
	else
	{
	Write-HostWithLogandColor $TempNewLine Red
	Write-HostWithLogandColor "$FolderPath $Message folder path is invalid" Red
	Write-HostWithLogandColor $Temp Red
	throw "Please enter correct folder path"
	exit 1;
	}
}

#Try catch to be added for file read functionality
[xml]$xmlConfigFile = new-object XML
$config_file=$SetupConfigurationFile
$xmlConfigFile.Load($config_file)

#To read values from DataRepresentation.config file

	$Build_Folder=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Build_FolderPath").getAttribute("Build_FolderPath_M")
	$Build_FolderPath=$Build_Folder +"\JRE"
	Write-host "Build folder path $Build_FolderPath"
	$LogFile_FolderPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/LogFile_FolderPath").getAttribute("Log_FolderPath_M")
	$LogFile=$LogFile_FolderPath + "\Log.txt"
	Write-HostWithLogandColor "Log Path $LogFile" Green
Write-HostWithLog "#################################################################################"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "## This Powershell is property of Citiustech"
Write-HostWithLog "## Do not make any changes without product team confirmation"
Write-HostWithLog "## Created by : Amit More"
Write-HostWithLog "## "
Write-HostWithLog "## Running UtilsPowershell_CQM.ps1"
Write-HostWithLog "##JRE application components on EAP/Wildfly server"
Write-HostWithLog "##"
Write-HostWithLog "##DO not close this window until deployment is successful"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "#################################################################################"	
	$Clinical_DB_Authentication=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("A_Clinical_App_Authentication")
	
	$Clinical_DB_Server=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("A_Clinical_DB_Server_M")
	$Clinical_DB_Server=$Clinical_DB_Server.replace('\','\\')
	Write-HostWithLogandColor "Clinical DB Server Name: $Clinical_DB_Server" Gray

	$Clinical_DB_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("D_Clinical_DB_Name_M")
	Write-HostWithLogandColor "Clinical Database Name: $Clinical_DB_Name" Gray 
	
	$Clinical_DB_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("C_Clinical_DB_Port_M")
		
	$RMM_DB_Authentication=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("A_RMM_App_Authentication")
	
	$RMM_DB_Server=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("A_RMM_DB_Server_M")
	$RMM_DB_Server=$RMM_DB_Server.replace('\','\\')
	Write-HostWithLogandColor "RMMServerName: $RMM_DB_Server" Gray
	
	$RMM_DB_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("D_RMM_DB_Name_M")
	Write-HostWithLogandColor "RMMDatabaseName: $RMM_DB_Name" Gray
	
	$RMM_DB_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("C_RMM_DB_Port_M")
	$Clinical_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("B_Clinical_App_SQL_User")
	$RMM_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("B_RMM_App_SQL_User")
	
	$ClinicalDBString=$Clinical_DB_Server+":"+$Clinical_DB_Port
	$RMMDBString=$RMM_DB_Server+":"+$RMM_DB_Port

	#Is Https required
	$IsHTTPS_Required=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Web_String").getAttribute("IsHttps_Required")
	
	#UAM User Access Management in Common paramaeters
	$UAMApp_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMApp_Server_Name")
	$UAMApp_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMApp_Server_Port")
	
	if($IsHTTPS_Required -eq "True")
	{
	$UAMServerURL= "https://"+$UAMApp_Server_Name+":"+$UAMApp_Server_Port+"/uam/validateToken"
	}
	else{
	$UAMServerURL= "http://"+$UAMApp_Server_Name+":"+$UAMApp_Server_Port+"/uam/validateToken"
	}
	
	#CQM-JAVA
	$JRE_Properties_Required=$xmlConfigFile.selectSingleNode("/Configuration/JRE/JRE_Components_Required").getAttribute("B_JRE_Properties_Required")
	$JRE_War_Required=$xmlConfigFile.selectSingleNode("/Configuration/JRE/JRE_Components_Required").getAttribute("A_JRE_War_Required")
	$JRE_App_Server_Path=$xmlConfigFile.selectSingleNode("/Configuration/JRE/JRE_App_Path").getAttribute("JRE_App_Server_Path_M")
	
	TestPath $JRE_App_Server_Path "JRE EAP"
	
	$DestinationForCQMWarFiles= $JRE_App_Server_Path +"\standalone" + "\deployments"
	TestPath $DestinationForCQMWarFiles
	$DestinationForCQMPropertiesFiles= $JRE_App_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\configuration"+"\main"
	$BackupFolder= $JRE_App_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\configuration"+"\BackupFolder"
	$SourceForCQMWarFiles=$Build_FolderPath+ "\Data Representation"+"\CQM-JAVA"+"\Applications"+"\RuleEngine"+"\build"
	$SourceForCQMPropertyFiles=$Build_FolderPath+ "\Data Representation"+"\CQM-JAVA"+"\Applications"+"\RuleEngine"+"\processing-engine"+"\config"
	$SQLAuth=$Build_Folder +"\JRE"+"\ReleaseManagement"+"\Upgrades"+"\PowerShellScripts"
	
	if($Clinical_App_SQL_User -eq $null -or $Clinical_App_SQL_User -eq "")
	{
		$Clinical_App_SQL_User = ""
		$Clinical_App_SQL_Password = ""
		$WindowsAuth = "true"
	}
	else
	{
	$Clinical_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("B_Clinical_App_SQL_User")
	$Clinical_App_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("C_Clinical_App_SQL_Password")
	$WindowsAuth = "false"
	}
	
	if($RMM_App_SQL_User -eq $null -or $RMM_App_SQL_User -eq "")
	{
		$RMM_App_SQL_User = ""
		$RMM_App_SQL_Password = ""
		$WindowsAuthRMM = "true"
	}
	else
	{
	$RMM_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("B_RMM_App_SQL_User")
	$RMM_App_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("C_RMM_App_SQL_Password")
	$WindowsAuthRMM = "false"
	}
	
#CQM-JAVA
Write-HostWithLogandColor "Started JRE Installation" Gray
Write-HostWithLogandColor $dashline Gray 
Write-HostWithLogandColor "Copying of files started" Yellow

Try
{
if ([string]$JRE_War_Required -eq "True")
{
#regionBackupWarFiles

if ((Test-Path $BackupFolder) -eq $False)
{
Write-HostWithLogandColor $dashline Gray 
write-HostWithLogandColor "Create Backup Folder"Gray
New-Item ($BackupFolder) -type directory -force | out-null
}
else
{
write-HostWithLogandColor "Backup Folder already exist" Yellow
}
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$DestinationForCQMWarFiles\CQMRESTService.war")
{
write-HostWithLogandColor "Backup CQMRESTService file to $BackupFolder" Yellow
get-childitem -path $DestinationForCQMWarFiles -recurse -include "CQMRESTService.war" | Copy-Item -destination "$BackupFolder"
write-HostWithLogandColor "Backup of CQMRESTService file is completed to $BackupFolder" Yellow
}
#endregionregionBackupWarFiles
#CQM-JAVA
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "Deploying CQMRESTService War file on JRE WildFly Application server" Green 
if((Test-Path $DestinationForCQMWarFiles) -eq $False)
{
	New-Item ($DestinationForCQMWarFiles) -type directory -force | out-null
}
if ((Test-Path "$SourceForCQMWarFiles" ) -and [string]$JRE_War_Required -eq "True" )
{
get-childitem -path $SourceForCQMWarFiles -recurse -include *.war | Copy-Item -destination "$DestinationForCQMWarFiles"
}

Write-HostWithLogandColor "Deployed CQMRESTService War file on JRE WildFly Application server" Green

Write-HostWithLogandColor $dashline Gray 
}

if ([string]$JRE_Properties_Required -eq "True")
{
Write-HostWithLogandColor "Deploying Properties files on JRE WildFly Application server" Green
if (Test-Path ($DestinationForCQMPropertiesFiles))
{}
else
{New-Item ($DestinationForCQMPropertiesFiles) -type directory -force | out-null}

#region Backup Properties Files/AliasDebugEnabled

if ((Test-Path $BackupFolder) -eq $False)
{
write-HostWithLogandColor "Create Backup Folder"Gray
New-Item ($BackupFolder) -type directory -force | out-null
}
else
{
write-HostWithLogandColor "Backup Folder already exist" Yellow
}
if (Test-Path "$DestinationForCQMPropertiesFiles\*.properties")
{
write-HostWithLogandColor "Backup properties files to $BackupFolder" Yellow
robocopy $DestinationForCQMPropertiesFiles $BackupFolder
write-HostWithLogandColor "Backup of properties files is completed to $BackupFolder" Yellow
}
#endregion Backup completed

if (Test-Path "$SourceForCQMPropertyFiles\database.properties")
{Get-Content "$SourceForCQMPropertyFiles\database.properties" |  ForEach-Object { $_ -replace "<Server-Name>","$ClinicalDBString" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<Database-Password>","$Clinical_App_SQL_Password" -replace "<RMMServer-Name>","$RMMDBString" -replace "<RMMDatabase-Name>","$RMM_DB_Name" -replace "<RMMUser-Name>","$RMM_App_SQL_User" -replace "<RMMDatabase-Password>","$RMM_App_SQL_Password" -replace "<isWindowsAuthentication>","$WindowsAuth" -replace "<isWindowsAuthenticationRMM>","$WindowsAuthRMM" -replace "<Clinical_DB_Port>","$Clinical_DB_Port" -replace "<RMM_DB_Port>","$RMM_DB_Port"}| Set-Content "$DestinationForCQMPropertiesFiles\database.properties"}

if ((Test-Path "$DestinationForCQMPropertiesFiles\configuration.properties") -eq $False)
{
Write-HostWithLog "configuration.properties does not exist"
if (Test-Path "$SourceForCQMPropertyFiles\configuration.properties")
{
Write-HostWithLog "Copying configuration.properties with default values"
get-childitem -path "$SourceForCQMPropertyFiles\configuration.properties"    | Copy-Item -destination "$DestinationForCQMPropertiesFiles\configuration.properties"
Write-HostWithLog "Copied configuration.properties with default values"
}
}
if (Test-Path "$DestinationForCQMPropertiesFiles\log4j.properties" ) 
{
remove-Item "$DestinationForCQMPropertiesFiles\log4j.properties" -force
}

if ((Test-Path "$DestinationForCQMPropertiesFiles\log4j2.properties") -eq $False)
{
get-childitem -path "$SourceForCQMPropertyFiles\log4j2.properties"| Copy-Item -destination "$DestinationForCQMPropertiesFiles\log4j2.properties"
}

if (Test-Path "$SourceForCQMPropertyFiles\conceptIDConfig.properties" )
{
get-childitem -path "$SourceForCQMPropertyFiles\conceptIDConfig.properties"| Copy-Item -destination "$DestinationForCQMPropertiesFiles\conceptIDConfig.properties"
}

if (Test-Path "$SourceForCQMPropertyFiles\ruleEngineConfig.properties" )
{
get-childitem -path "$SourceForCQMPropertyFiles\ruleEngineConfig.properties"    | Copy-Item -destination "$DestinationForCQMPropertiesFiles\ruleEngineConfig.properties"
}
if (Test-Path "$SourceForCQMPropertyFiles\horizontalScalingConfig.properties" ) 
{
get-childitem -path "$SourceForCQMPropertyFiles\horizontalScalingConfig.properties"    | Copy-Item -destination "$DestinationForCQMPropertiesFiles\horizontalScalingConfig.properties"
}
if (Test-Path "$SourceForCQMPropertyFiles\module.xml" ) 
{
get-childitem -path "$SourceForCQMPropertyFiles\module.xml"    | Copy-Item -destination "$DestinationForCQMPropertiesFiles\module.xml"
}

####
$Configuration_File="$DestinationForCQMPropertiesFiles\configuration.properties"
$UAMline = Get-Content $Configuration_File | Select-String 'uamEndPointUrl=' | Select-Object -ExpandProperty Line
$Get_content = Get-Content $Configuration_File
$Get_content | ForEach-Object {$_ -replace $UAMline,"uamEndPointUrl=$UAMServerURL"} | Set-Content $Configuration_File
####
if((Test-Path $SQLAuth) -eq $True)
{
get-childitem -path $SQLAuth -recurse *.dll | Copy-Item -destination "$JRE_App_Server_Path\bin"
}
else
{
		Write-HostWithLogandColor $dashline Gray
		write-HostWithLogandColor "Path $SQLAuth Not Found " Red
		exit 1;
}

Write-HostWithLogandColor "Deployed Properties files on JRE WildFly Application server" Yellow
Write-HostWithLogandColor $dashline Gray 
Write-HostWithLogandColor "Kindly Restart JRE WildFly Application Service" Yellow
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "Deployment of JRE application on $JRE_App_Server_Path is done successfully" Green
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
}
}
Catch
{
Write-HostWithLogandColor $_.Exception.GetType( ).FullName Red
exit 1;
}