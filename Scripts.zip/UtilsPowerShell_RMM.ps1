﻿param([string]$SetupConfigurationFile,[string]$Value="NormalUpgrade",[string]$Upgrade="True")

function Write-HostWithLog{param([string]$Statement)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
		{ New-Item $LogFile  -type file | Out-Null }
	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement

}

#This function will Write to console with foreground color and in log file
function Write-HostWithLogandColor{param([string]$Statement,[string]$Color)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
		{ New-Item $LogFile -type file | Out-Null }

	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement -ForegroundColor $Color

}

function TestPath{param([string]$FolderPath,[string]$Message)
	if(Test-Path ($FolderPath))
	{
	Write-HostWithLogandColor $Temp Gray
	Write-HostWithLogandColor "$FolderPath $Message folder Path is valid" Gray
	Write-HostWithLogandColor $TempNewLine Gray
	}
	else
	{
	Write-HostWithLogandColor $TempNewLine Red
	Write-HostWithLogandColor "$FolderPath $Message folder path is invalid" Red
	Write-HostWithLogandColor $Temp Red
	throw "Please enter correct folder path"
	Exit 1;
	}
}

[xml]$xmlConfigFile = new-object XML
 
$config_file=$SetupConfigurationFile
$xmlConfigFile.Load($config_file)
	
	$LogFile_FolderPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/LogFile_FolderPath").getAttribute("Log_FolderPath_M")
	$LogFile=$LogFile_FolderPath + "\Log.txt"
	Write-HostWithLogandColor "Log Path $LogFile" Green
	
	$Build_Folder=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Build_FolderPath").getAttribute("Build_FolderPath_M")
	write-host "$Build_Folder path for build"
	$Build_FolderPath=$Build_Folder +"\RMM"
	TestPath $Build_FolderPath "RMM Build"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "## This Powershell is property of Citiustech"
Write-HostWithLog "## Do not make any changes without product team confirmation"
Write-HostWithLog "## Created by : Amit More"
Write-HostWithLog "## "
Write-HostWithLog "## Running UtilsPowershell_RMM.ps1"
Write-HostWithLog "##Deploying RMM application components on EAP/Wildfly server"
Write-HostWithLog "##"
Write-HostWithLog "##DO not close this window until deployment is successful"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "#################################################################################"
	#Server Details
	$RMM_DB_Server=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("A_RMM_DB_Server_M")
	$RMM_DB_Server=$RMM_DB_Server.replace('\','\\')
	Write-HostWithLogandColor "RMM DB Server: $RMM_DB_Server" Gray
	$RMM_DB_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("C_RMM_DB_Port_M")
	Write-HostWithLogandColor "RMM DB Port: $RMM_DB_Port" Gray
	$RMM_DB_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("D_RMM_DB_Name_M")
	Write-HostWithLogandColor "RMM DB Name: $RMM_DB_Name" Gray

	
	$Clinical_DB_Server=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("A_Clinical_DB_Server_M")
	$Clinical_DB_Server=$Clinical_DB_Server.replace('\','\\')
	Write-HostWithLogandColor "Clinical DB Server: $Clinical_DB_Server" Gray
	$Clinical_DB_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("C_Clinical_DB_Port_M")
	Write-HostWithLogandColor "Clinical DB Port: $Clinical_DB_Port" Gray
	$Clinical_SSIS_Server=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("B_Clinical_SSIS_Server_M")
	$Clinical_SSIS_Server=$Clinical_SSIS_Server.replace('\','\\')
	Write-HostWithLogandColor "Clinical SSIS Server: $Clinical_SSIS_Server" Gray
	$Clinical_SSIS_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("C_Clinical_SSIS_Port_M")
	Write-HostWithLogandColor "Clinical SSIS Port: $Clinical_SSIS_Port" Gray
	
	$Clinical_DB_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("D_Clinical_DB_Name_M")
	Write-HostWithLogandColor "Clinical DB Name: $Clinical_DB_Name" Gray
	#Web String
	$IsHttps_Required=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Web_String").getAttribute("IsHttps_Required")
	$IsSSO_Required=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Web_String").getAttribute("IsSSO_Required")
	
	#RMM-APP
	$RMM_Application_Required=$xmlConfigFile.selectSingleNode("/Configuration/RMM/RMM_Components_Required").getAttribute("RMM_Application_Required")
	$RMM_Web_War_Required =$xmlConfigFile.selectSingleNode("/Configuration/RMM/UI_Server_Details").getAttribute("A_RMM_Web_War_Required")
	$RMM_Web_Properties_Required =$xmlConfigFile.selectSingleNode("/Configuration/RMM/UI_Server_Details").getAttribute("B_RMM_Web_Properties_Required")
	$RMM_App_War_Required =$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("A_RMM_App_War_Required")
	$RMM_App_Properties_Required =$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("B_RMM_App_Properties_Required")
	$SourceForRMMWarFiles=$Build_FolderPath+ "\RMM_APP"+"\Build"
	$RMM_Web_Server_Path=$xmlConfigFile.selectSingleNode("/Configuration/RMM/UI_Server_Details").getAttribute("F_RMM_Web_Server_Path_M")	
	$RMM_APP_Server_Path=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("E_RMM_APP_Server_Path_M")
		
	$AbsolutefolderPathUIWar= $RMM_Web_Server_Path +"\standalone" + "\deployments"
	$AbsolutefolderPathServiceWar =$RMM_APP_Server_Path +"\standalone" +"\deployments"
	
	$DestinationForRMMUIPropertiesFiles= $RMM_Web_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\rmm"+"\configuration"+"\main"
	$RMMWebBackupFolder= $RMM_Web_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\rmm"+"\configuration"+"\BackupFolder_RMM_Web"
	$DestinationForRMMServicePropertiesFiles= $RMM_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\rmm"+"\configuration"+"\main"
	$RMMAppBackupFolder= $RMM_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\rmm"+"\configuration"+"\BackupFolder_RMM_App"
	
	$RMM_Web_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/RMM/UI_Server_Details").getAttribute("C_RMM_Web_Server_Name_M")
	$RMM_Web_Port=$xmlConfigFile.selectSingleNode("/Configuration/RMM/UI_Server_Details").getAttribute("D_RMM_Web_Port_M")
	$RMM_APP_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("C_RMM_APP_Server_Name_M")
	$RMM_APP_Port=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("D_RMM_APP_Port_M")
	$Private_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Private_Server_Details").getAttribute("Private_Server_Name")
	$Private_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Private_Server_Details").getAttribute("Private_Server_Port")
	$Additonal_CORS_Allowed_Origin=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Additonal_CORS_Allowed_Origin").getAttribute("URL")
	$SCHEDULER_INTERVAL=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Common").getAttribute("SCHEDULER_INTERVAL")
	$START_DELAY=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Common").getAttribute("START_DELAY")
	$SourceForRMMPropertiesFiles=$Build_FolderPath+ "\RMM_APP"+"\Services"+"\Utils"+"\properties"
	$SourceForDownloadFiles=$Build_FolderPath+ "\RMM_APP"+"\Services"+"\Utils"+"\downloads"
	$SQLAuth=$Build_FolderPath+ "\RMM_APP"+"\Services"+"\Utils"+"\bin"
	$ImagesInputPath=$Build_FolderPath+ "\RMM_APP"+"\Services"+"\Utils"+"\images"
	$ReadMeFile=$Build_FolderPath+"\ReleaseManagement"+"\Scripts"
	
	#BIC-Console
	$SourceForBICConsolePropertyFiles=$Build_FolderPath+ "\BicConsole"+"\Services"+"\Utils"+"\properties"
	$SourceForBICConsoleWarFiles=$Build_FolderPath+ "\BicConsole"+"\Build"
	$DestBICConsoleServicePropertiesFiles= $RMM_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\bicconsole"+"\configuration"+"\main"
	$BICConsoleAppBackupFolder= $RMM_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\bicconsole"+"\configuration"+"\BackupFolder_BICConsole_App"
	$DestBICConsoleUIPropertiesFiles= $RMM_Web_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\bicconsole"+"\configuration"+"\main"
	$BICConsoleWebBackupFolder= $RMM_Web_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\bicconsole"+"\configuration"+"\BackupFolder_BICConsole_Web"

	$RMM_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("B_RMM_App_SQL_User")
	$RMM_App_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("C_RMM_App_SQL_Password")
	$Clinical_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("B_Clinical_App_SQL_User")
	$Clinical_App_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("C_Clinical_App_SQL_Password")
	$Export_Folder_Path=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Rules_Folder").getAttribute("Export_Folder_Path_M")
	$Import_Folder_Path=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Rules_Folder").getAttribute("Import_Folder_Path_M")
	
	#SMTPDetails
	$SMTP_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("A_SMTP_Server_Name")
	$SMTP_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("B_SMTP_Port")
	$SMTP_User_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("C_SMTP_User_Name")
	$SMTP_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("D_SMTP_Password")
	#MICROSOFT FolderPath
	
	$MicrosoftFolder=$Build_FolderPath+ "\RMM_APP"+"\Services"+"\Utils"+"\modules"+"\system"+"\layers"+"\base"+"\com"+"\microsoft"+"\sqlserver"+"\main"
	$UploadMicrosoftFolder=$RMM_APP_Server_Path + "\modules" + "\system" + "\layers" + "\base" + "\com" + "\microsoft" +"\sqlserver" +"\main"
	#LDAP
	$LDAP_Url=$xmlConfigFile.selectSingleNode("/Configuration/RMM/LDAP").getAttribute("A_LDAP_Url")
	
	#UAM User Access Management in Common paramaeters
	$UAMApp_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMApp_Server_Name")
	$UAMApp_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMApp_Server_Port")
	$UAMWeb_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMWeb_Server_Name")
	$UAMWeb_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMWeb_Server_Port")
	$Auth_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("Auth_Server_Name")
	$Auth_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("Auth_Server_Port")
	
	#UAM RMM specific parameters
	$Auth_Web_ClientId=$xmlConfigFile.selectSingleNode("/Configuration/RMM/UAM").getAttribute("A_Auth_Web_Client_ID")
	$Auth_App_ClientId=$xmlConfigFile.selectSingleNode("/Configuration/RMM/UAM").getAttribute("B_Auth_App_Client_ID")
	$Auth_App_Client_Secret=$xmlConfigFile.selectSingleNode("/Configuration/RMM/UAM").getAttribute("C_Auth_App_Client_Secret")
	$UAMSchedulerInterval=$xmlConfigFile.selectSingleNode("/Configuration/RMM/UAM").getAttribute("D_Scheduler_Interval")
	$Admin_Console_Auth_Web_Client_ID=$xmlConfigFile.selectSingleNode("/Configuration/RMM/UAM").getAttribute("F_Admin_Console_Auth_Web_Client_ID")

	
	#JRE Server Details
	$JRE_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/JREServer").getAttribute("JRE_Server_Name")
	$JRE_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/JREServer").getAttribute("JRE_Server_Port")
	
	$UploadsFolderPathUI=$RMM_Web_Server_Path + "\Uploads"
	$DownloadFolderPathUI=$RMM_Web_Server_Path + "\Downloads"
	$TemplatesFolderPathUI=$RMM_Web_Server_Path + "\Templates"
	$UploadsFolderPathService=$RMM_APP_Server_Path + "\Uploads"
	$DownloadFolderPathService=$RMM_APP_Server_Path + "\Downloads"
	$TemplatesFolderPathService=$RMM_APP_Server_Path + "\Templates"
	$ImagesFolderPath=$RMM_APP_Server_Path + "\Images"

	if($RMM_App_SQL_User -eq $null -or $RMM_App_SQL_User -eq "")
	{
		$RMM_App_SQL_User = ""
		$RMM_App_SQL_Password = ""
		$WindowsAuth = "True"
	}
	else
	{
	$RMM_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("B_RMM_App_SQL_User")
	$RMM_App_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("C_RMM_App_SQL_Password")
	$WindowsAuth = "False"
	}
		if($Clinical_App_SQL_User -eq $null -or $Clinical_App_SQL_User -eq "")
	{
		$Clinical_App_SQL_User = ""
		$Clinical_App_SQL_Password = ""
		$ClinicalWindowsAuth = "True"
	}
	else
	{
	$Clinical_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("B_Clinical_App_SQL_User")
	$Clinical_App_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("C_Clinical_App_SQL_Password")
	$ClinicalWindowsAuth = "False"
	}
	
	if($LDAP_Url -eq $null -or $LDAP_Url -eq "")
	{
		$LDAP_Url = ""
		$LDAP_Domain = ""
		$LADAP_Group_Name = ""
	}
	else
	{
	$LDAP_Url=$xmlConfigFile.selectSingleNode("/Configuration/RMM/LDAP").getAttribute("A_LDAP_Url")
	$LDAP_Domain=$xmlConfigFile.selectSingleNode("/Configuration/RMM/LDAP").getAttribute("B_LDAP_Domain")
	$LADAP_Group_Name=$xmlConfigFile.selectSingleNode("/Configuration/RMM/LDAP").getAttribute("C_LADAP_Group_Name")
	}
	
	if($RMM_Web_Port -eq "80" -or $RMM_Web_Port -eq "443")
	{
		$UIServerURL = $RMM_Web_Server_Name
	}
	else
	{
	$UIServerURL= $RMM_Web_Server_Name+":"+$RMM_Web_Port
	}
	if($RMM_APP_Port -eq "80" -or $RMM_APP_Port -eq "443")
	{
		$ServiceServerURL = $RMM_APP_Server_Name
	}
	else
	{
	$ServiceServerURL= $RMM_APP_Server_Name+":"+$RMM_APP_Port
	}
	if($Auth_Server_Port -eq "80" -or $Auth_Server_Port -eq "443")
	{
		$Auth_ServerURL = $Auth_Server_Name
	}
	else
	{
	$Auth_ServerURL= $Auth_Server_Name+":"+$Auth_Server_Port
	}
	if($UAMApp_Server_Port -eq "80" -or $UAMApp_Server_Port -eq "443")
	{
		$UAMAppServerURL = $UAMApp_Server_Name
	}
	else
	{
	$UAMAppServerURL= $UAMApp_Server_Name+":"+$UAMApp_Server_Port
	}
	if($UAMWeb_Server_Port -eq "80" -or $UAMWeb_Server_Port -eq "443")
	{
		$UAMWebServerURL = $UAMWeb_Server_Name
	}
	else
	{
	$UAMWebServerURL= $UAMWeb_Server_Name+":"+$UAMWeb_Server_Port
	}
	if ($Private_Server_Name -eq $null -or $Private_Server_Name -eq "" -and $Private_Server_Port -eq "" -or $Private_Server_Port -eq "")
	{
	$PrivateServiceServerURL=$ServiceServerURL
	$ValidHostUI=$UIServerURL+","+$ServiceServerURL
	$ValidHostService=$ServiceServerURL+","+$UIServerURL
	}
	elseif($Private_Server_Port -eq "80" -or $Private_Server_Port -eq "443")
	{
	$PrivateServiceServerURL=$Private_Server_Name
	$ValidHostUI=$UIServerURL+","+$ServiceServerURL+","+$PrivateServiceServerURL
	$ValidHostService=$ServiceServerURL+","+$UIServerURL+","+$PrivateServiceServerURL
	}
	else
	{
	$PrivateServiceServerURL=$Private_Server_Name+":"+$Private_Server_Port
	$ValidHostUI=$UIServerURL+","+$ServiceServerURL+","+$PrivateServiceServerURL
	$ValidHostService=$ServiceServerURL+","+$UIServerURL+","+$PrivateServiceServerURL
	}
	
	if ($IsHttps_Required -eq "True")
	{
	$UIServer="https://"+$UIServerURL
	$ServiceServer="https://"+$ServiceServerURL
	$Auth_Server="https://"+$Auth_ServerURL
	$UAMAPPServer="https://"+$UAMAppServerURL
	$UAMWebServer="https://"+$UAMWebServerURL
	$PrivateServiceServer="https://"+$PrivateServiceServerURL
	$JREServerURL="https://"+$JRE_Server_Name+":"+$JRE_Server_Port
	}
	else
	{
	$UIServer="http://"+$UIServerURL
	$ServiceServer="http://"+$ServiceServerURL
	$Auth_Server="http://"+$Auth_ServerURL
	$UAMAPPServer="http://"+$UAMAppServerURL
	$UAMWebServer="http://"+$UAMWebServerURL
	$PrivateServiceServer="http://"+$PrivateServiceServerURL
	$JREServerURL="http://"+$JRE_Server_Name+":"+$JRE_Server_Port
	}
	
#####CorsAllowedOrigins####
	if ($ServiceServer -eq $UIServer)
	{
	$CorsAllowedOriginsService=$ServiceServer
	}
	else
	{
	$CorsAllowedOriginsService=$ServiceServer+","+$UIServer
	}
	
	if ($UIServer -eq $UAMWebServer)
	{
	$CorsAllowedOrigins_Web=$UIServer
	}
	else
	{
	$CorsAllowedOrigins_Web=$UIServer+","+$UAMWebServer
	}
	if ($ServiceServer -eq $UAMAPPServer)
	{
	$CorsAllowedOrigins_App=$ServiceServer
	}
	else
	{
	$CorsAllowedOrigins_App=$ServiceServer+","+$UAMAPPServer
	}
	if ($CorsAllowedOrigins_Web -eq $CorsAllowedOrigins_App)
	{
	$CorsAllowedOriginsUI=$CorsAllowedOrigins_Web
	}
	else
	{
	$CorsAllowedOriginsUI=$CorsAllowedOrigins_Web+","+$CorsAllowedOrigins_App
	}
	if ($Auth_Server_Name -eq $null -or $Auth_Server_Name -eq "")
	{
	Write-HostWithLogandColor $CorsAllowedOriginsUI magenta
	}
	else
	{
	$CorsAllowedOriginsUI=$CorsAllowedOriginsUI+","+$Auth_Server
		Write-HostWithLogandColor $CorsAllowedOriginsUI magenta
	}
	if ($Private_Server_Name -eq $null -or $Private_Server_Name -eq "")
	{
	}
	else
	{
	$CorsAllowedOriginsUI=$PrivateServiceServer+","+$CorsAllowedOriginsUI
	}
	if ($Additonal_CORS_Allowed_Origin -eq $null -or $Additonal_CORS_Allowed_Origin -eq "")
	{
	}
	else{
	$CorsAllowedOriginsUI=$CorsAllowedOriginsUI+","+$Additonal_CORS_Allowed_Origin
	}

####Valid Host URL Secion####
	if ($Private_Server_Name -eq $null -or $Private_Server_Name -eq "" -and $Private_Server_Port -eq "" -or $Private_Server_Port -eq "")
	{
	$PrivateServiceServerBICConsoleURL=$ServiceServerURL
	$ValidHostBICConsoleUI=$UIServerURL
	$ValidHostBICConsoleService=$ServiceServerURL
	}
	elseif($Private_Server_Port -eq "80" -or $Private_Server_Port -eq "443")
	{
	$PrivateServiceServerBICConsoleURL=$Private_Server_Name
	$ValidHostBICConsoleUI=$UIServerURL
	$ValidHostBICConsoleService=$PrivateServiceServerBICConsoleURL+","+$ServiceServerURL
	}
	else
	{
	$PrivateServiceServerBICConsoleURL=$Private_Server_Name+":"+$Private_Server_Port
	$ValidHostBICConsoleUI=$UIServerURL
	$ValidHostBICConsoleService=$PrivateServiceServerBICConsoleURL+","+$ServiceServerURL
	}
	
#RMM-APP
Write-HostWithLogandColor $dashline Gray 

if ([string] $RMM_Application_Required -eq "False")
{}
else{
Write-HostWithLogandColor "Started RMM Application Deployment" Yellow
Try
{
if ([string]$RMM_App_Properties_Required -eq "True")
{
TestPath $RMM_APP_Server_Path "RMM App Server EAP"
#regionBackupRMMAppProperties
if ((Test-Path $RMMAppBackupFolder) -eq $False)
{
Write-HostWithLogandColor $dashline Gray 
write-HostWithLogandColor "Create $RMMAppBackupFolder Folder on App Server"Gray
New-Item ($RMMAppBackupFolder) -type directory -force | out-null
}
else
{
write-HostWithLogandColor "$RMMAppBackupFolder Folder already exist on App Server" Yellow
}
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$DestinationForRMMServicePropertiesFiles\*.properties")
{
write-HostWithLogandColor "Backup RMM App Properties files to $RMMAppBackupFolder" Yellow
robocopy $DestinationForRMMServicePropertiesFiles $RMMAppBackupFolder
write-HostWithLogandColor "Backup of RMM App Properties file is completed to $RMMAppBackupFolder" Yellow
}
Write-HostWithLogandColor $dashline Gray 
#endregionregionBackupRMMAppProperties
Write-HostWithLogandColor "Copying properties files to the Service WildFlyFolderPath" Yellow

if (Test-Path ($DestinationForRMMServicePropertiesFiles))
{}
else
{New-Item ($DestinationForRMMServicePropertiesFiles) -type directory -force | out-null}
if (Test-Path "$SourceForRMMPropertiesFiles\database.properties")
{Get-Content "$SourceForRMMPropertiesFiles\database.properties" | ForEach-Object { $_ -replace "<db-server-name>","$RMM_DB_Server" -replace "<Database-Name>","$RMM_DB_Name" -replace "<db-port>","$RMM_DB_Port" -replace "<User-Name>","$RMM_App_SQL_User" -replace "<encrypted-database-password>","$RMM_App_SQL_Password" -replace "<isWindowsAuthentication>","$WindowsAuth" -replace "<clinical-db-server-name>","$Clinical_DB_Server" -replace "<clinical-db-port>","$Clinical_DB_Port" -replace "<clinical-db-name>","$Clinical_DB_Name" -replace "<Clinical-isWindowsAuthentication>","$ClinicalWindowsAuth" -replace"<clinical-user-name>","$Clinical_App_SQL_User" -replace"<clinical-encrypted-database-password>","$Clinical_App_SQL_Password"} | Set-Content "$DestinationForRMMServicePropertiesFiles\database.properties"}

if (Test-Path "$SourceForRMMPropertiesFiles\rmmconfig.properties")
{Get-Content "$SourceForRMMPropertiesFiles\rmmconfig.properties" | ForEach-Object { $_ -replace "<UIServerURL>","$UIServer" -replace "<ServiceServerURL>","$ServiceServer" -replace "<SmtpEncryptedHostServer>","$SMTP_Server_Name" -replace "<SmtpPort>","$SMTP_Port" -replace "<SmtpUserName>","$SMTP_User_Name" -replace "<SmtpEncryptedPasswaord>","$SMTP_Password" -replace "<ldap-encrypted-url>","$LDAP_Url" -replace "<ldap-domain>","$LDAP_Domain" -replace "<ldap-groupname>","$LADAP_Group_Name" -replace "<IsSSOEnabled>","$IsSSO_Required" -replace "<UAMServerURL>","$UAMAPPServer" -replace "<AuthWebClientId>","$Auth_Web_ClientId" -replace "<AuthAppClientId>","$Auth_App_ClientId" -replace "<AuthAppEncryptedClientSecretId>","$Auth_App_Client_Secret" -replace "<CorsAllowedOrigins>","$CorsAllowedOriginsService" -replace "<UAMWebAppServerURL>","$UAMWebServer" -replace "<PrivateServiceServerURL>","$PrivateServiceServer" -replace "<ValidHosts>","$ValidHostService" -replace "<JREServerURL>","$JREServerURL" } | Set-Content "$DestinationForRMMServicePropertiesFiles\rmmconfig.properties"} 

if (Test-Path "$SourceForRMMPropertiesFiles\common.properties")
{get-Content "$SourceForRMMPropertiesFiles\common.properties"| ForEach-Object { $_ -replace "<scheduler-interval-in-milliseconds>", "$SCHEDULER_INTERVAL" -replace "<start-delay-in-milliseconds>", "$START_DELAY" -replace "<uam-scheduler-interval-in-milliseconds>", "$UAMSchedulerInterval"} | set-content "$DestinationForRMMServicePropertiesFiles\common.properties"}

if (Test-Path "$SourceForRMMPropertiesFiles\auth.properties")
{get-childitem -path "$SourceForRMMPropertiesFiles\auth.properties"| Copy-Item -destination "$DestinationForRMMServicePropertiesFiles\auth.properties"}
 
if (Test-Path "$SourceForRMMPropertiesFiles\log4j.properties")
{get-childitem -path "$SourceForRMMPropertiesFiles\log4j.properties"| Copy-Item -destination "$DestinationForRMMServicePropertiesFiles\log4j.properties"}

if (Test-Path "$SourceForRMMPropertiesFiles\ruleslibrary.properties")
{Get-Content "$SourceForRMMPropertiesFiles\ruleslibrary.properties" | ForEach-Object{ $_ -replace "<ExportRulesFolderPath>","$Export_Folder_Path" -replace "<ImportRulesFolderPath>","$Import_Folder_Path"} | Set-Content  "$DestinationForRMMServicePropertiesFiles\ruleslibrary.properties"}

if (Test-Path "$SourceForRMMPropertiesFiles\testlibrary.properties")
{get-childitem -path "$SourceForRMMPropertiesFiles\testlibrary.properties"| Copy-Item -destination "$DestinationForRMMServicePropertiesFiles\testlibrary.properties"}

robocopy $SourceForRMMPropertiesFiles $DestinationForRMMServicePropertiesFiles *.xml *.jar /s

#BIC-Console

#regionBICConsoleAppPropertiesBackup
if ((Test-Path $BICConsoleAppBackupFolder) -eq $False)
{
Write-HostWithLogandColor $dashline Gray 
Write-HostWithLogandColor "Create $BICConsoleAppBackupFolder Folder on App Server"Gray
New-Item ($BICConsoleAppBackupFolder) -type directory -force | out-null
}
else
{
write-HostWithLogandColor "$BICConsoleAppBackupFolder Folder already exist on App Server" Yellow
}
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$DestBICConsoleServicePropertiesFiles\*.properties")
{
write-HostWithLogandColor "Backup BIC-Console App Properties files to $BICConsoleAppBackupFolder" Yellow
robocopy $DestBICConsoleServicePropertiesFiles $BICConsoleAppBackupFolder
write-HostWithLogandColor "Backup of BIC-Console App Properties file is completed to $BICConsoleAppBackupFolder" Yellow
}
Write-HostWithLogandColor $dashline Gray 
#endregionregionBICConsoleAppPropertiesBackup

if (Test-Path ($DestBICConsoleServicePropertiesFiles))
{}
else
{New-Item ($DestBICConsoleServicePropertiesFiles) -type directory -force | out-null}

if (Test-Path "$SourceForBICConsolePropertyFiles\database.properties")
{Get-Content "$SourceForBICConsolePropertyFiles\database.properties" | ForEach-Object { $_ -replace "<db-server-name>","$RMM_DB_Server" -replace "<Database-Name>","$RMM_DB_Name" -replace "<db-port>","$RMM_DB_Port" -replace "<User-Name>","$RMM_App_SQL_User" -replace "<encrypted-database-password>","$RMM_App_SQL_Password" -replace "<isWindowsAuthentication>","$WindowsAuth" -replace "<clinical-db-server-name>","$Clinical_DB_Server"  -replace "<clinical-db-port>","$Clinical_DB_Port" -replace "<Clinical-SSIS-Server>","$Clinical_SSIS_Server" -replace "<clinical-ssis-port>","$Clinical_SSIS_Port" -replace "<clinical-db-name>","$Clinical_DB_Name" -replace "<Clinical-isWindowsAuthentication>","$ClinicalWindowsAuth" -replace"<clinical-user-name>","$Clinical_App_SQL_User" -replace"<clinical-encrypted-database-password>","$Clinical_App_SQL_Password"} | Set-Content "$DestBICConsoleServicePropertiesFiles\database.properties"}

if (Test-Path "$SourceForBICConsolePropertyFiles\bicconsoleconfig.properties")
{Get-Content "$SourceForBICConsolePropertyFiles\bicconsoleconfig.properties" | ForEach-Object { $_ -replace "<ServiceServerURL>","$ServiceServer" -replace "<IsSSOEnabled>","$IsSSO_Required" -replace "<UAMServerURL>","$UAMAPPServer" -replace "<AppCorsAllowedOrigins>","$CorsAllowedOriginsService" -replace "<AppValidHosts>","$ValidHostBICConsoleService" -replace "<PrivateServiceServerURL>","$PrivateServiceServer"} | Set-Content "$DestBICConsoleServicePropertiesFiles\bicconsoleconfig.properties"}


robocopy "$SourceForBICConsolePropertyFiles" "$DestBICConsoleServicePropertiesFiles" /e /xf "database.properties" "bicconsolewebconfig.properties" "bicconsoleconfig.properties"

Write-HostWithLogandColor "Copied properties files to the WildFlyFolderPath Service Server" Green
}

if ([string]$RMM_App_War_Required -eq "True")
{
TestPath $AbsolutefolderPathServiceWar
#regionBackupRMMAppwar
if ((Test-Path $RMMAppBackupFolder) -eq $False)
{
Write-HostWithLogandColor $dashline Gray 
write-HostWithLogandColor "Create $RMMAppBackupFolder Folder on App Server"Gray
New-Item ($RMMAppBackupFolder) -type directory -force | out-null
}
else
{
write-HostWithLogandColor "$RMMAppBackupFolder Folder already exist on App Server" Yellow
}
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$AbsolutefolderPathServiceWar\*.war")
{
write-HostWithLogandColor "Backup RMM App & BIC-Console war files to $RMMAppBackupFolder" Yellow
robocopy $AbsolutefolderPathServiceWar $RMMAppBackupFolder
write-HostWithLogandColor "Backup of RMM App & BIC-Console war file is completed to $RMMAppBackupFolder" Yellow
}
Write-HostWithLogandColor $dashline Gray 
#endregionregionBackupRMMAppwar
Write-HostWithLogandColor "Started copying War deployment on service Wildfly server" Yellow
if((Test-Path $AbsolutefolderPathServiceWar) -eq $False)
{
	New-Item ($AbsolutefolderPathServiceWar) -type directory -force | out-null
}

if ((Test-Path "$SourceForRMMWarFiles" ) -and [string]$RMM_App_War_Required -eq "true" )
{
get-childitem -path $SourceForRMMWarFiles -recurse -Include "Common.war","RulesLibrary.war","TestLibrary.war","Reports.war" | Copy-Item -Destination "$AbsolutefolderPathServiceWar"
get-childitem -path $SourceForBICConsoleWarFiles -recurse -Include "BicConsole.war" | Copy-Item -Destination "$AbsolutefolderPathServiceWar"
}
Write-HostWithLogandColor "Deployment of War is done on $RMM_APP_Server_Path " Green
if (Test-Path ($UploadsFolderPathService))
{}
else
{New-Item ($UploadsFolderPathService) -type directory -force | out-null}
if (Test-Path ($DownloadFolderPathService))
{}
else
{New-Item ($DownloadFolderPathService) -type directory -force | out-null}
if (Test-Path ($TemplatesFolderPathService))
{}
else
{New-Item ($TemplatesFolderPathService) -type directory -force | out-null}

get-childitem -path $SourceForDownloadFiles -recurse -include *.xlsx ,*.png , *.ttf , *.xsl | Copy-Item -destination "$DownloadFolderPathService"

if (Test-Path "$ReadMeFile\BI-Clinical_Readme.txt")
{get-childitem -path "$ReadMeFile\BI-Clinical_Readme.txt"| Copy-Item -destination "$RMM_APP_Server_Path\BI-Clinical_Readme.txt"}

if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}
robocopy "$MicrosoftFolder" "$UploadMicrosoftFolder" /e

get-childitem -path $SQLAuth -recurse *.dll | Copy-Item -destination "$RMM_APP_Server_Path\bin"
if((Test-Path $ImagesFolderPath) -eq $False)
{
	New-Item ($ImagesFolderPath) -type directory -force | out-null
}
 robocopy $ImagesInputPath $ImagesFolderPath *.png /s
 Write-HostWithLogandColor "Kindly Restart RMM Webbapp WildFly Application Service" Yellow
}


Write-HostWithLogandColor $Dashline Gray

#Deployment of UI components on UI server

if ([string]$RMM_Web_Properties_Required -eq "True")
{
TestPath $RMM_Web_Server_Path "RMM Web Server EAP"
#regionBackupRMMWebProperties
if ((Test-Path $RMMWebBackupFolder) -eq $False)
{
Write-HostWithLogandColor $dashline Gray 
write-HostWithLogandColor "Create $RMMWebBackupFolder Folder on UI Server"Gray
New-Item ($RMMWebBackupFolder) -type directory -force | out-null
}
else
{
write-HostWithLogandColor "$RMMWebBackupFolder Folder already exist on UI Server" Yellow
}
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$DestinationForRMMUIPropertiesFiles\*.properties")
{
write-HostWithLogandColor "Backup RMM UI Properties files to $RMMWebBackupFolder" Yellow
robocopy $DestinationForRMMUIPropertiesFiles $RMMWebBackupFolder
write-HostWithLogandColor "Backup of RMM UI Properties file is completed to $RMMWebBackupFolder" Yellow
}
Write-HostWithLogandColor $dashline Gray 
#endregionregionBackupRMMWebProperties
Write-HostWithLogandColor "Copying properties files to the UI WildFlyFolderPath" Yellow

if (Test-Path ($DestinationForRMMUIPropertiesFiles))
{}
else
{New-Item ($DestinationForRMMUIPropertiesFiles) -type directory -force | out-null}
if (Test-Path "$SourceForRMMPropertiesFiles\rmmconfig.properties")
{Get-Content "$SourceForRMMPropertiesFiles\rmmconfig.properties" | ForEach-Object { $_ -replace "<UIServerURL>","$UIServer" -replace "<ServiceServerURL>","$ServiceServer" -replace "<SmtpEncryptedHostServer>","$SMTP_Server_Name" -replace "<SmtpPort>","$SMTP_Port" -replace "<SmtpUserName>","$SMTP_User_Name" -replace "<SmtpEncryptedPasswaord>","$SMTP_Password" -replace "<ldap-encrypted-url>","$LDAP_Url" -replace "<ldap-domain>","$LDAP_Domain" -replace "<ldap-groupname>","$LADAP_Group_Name" -replace "<IsSSOEnabled>","$IsSSO_Required" -replace "<UAMServerURL>","$UAMAPPServer" -replace "<AuthWebClientId>","$Auth_Web_ClientId" -replace "<AuthAppClientId>","$Auth_App_ClientId" -replace "<AuthAppEncryptedClientSecretId>","$Auth_App_Client_Secret" -replace "<CorsAllowedOrigins>","$CorsAllowedOriginsUI" -replace "<UAMWebAppServerURL>","$UAMWebServer" -replace "<PrivateServiceServerURL>","$PrivateServiceServer" -replace "<ValidHosts>","$ValidHostUI" -replace "<JREServerURL>","$JREServerURL" } | Set-Content "$DestinationForRMMUIPropertiesFiles\rmmconfig.properties"} 
if (Test-Path "$SourceForRMMPropertiesFiles\auth.properties")
{get-childitem -path "$SourceForRMMPropertiesFiles\auth.properties"| Copy-Item -destination "$DestinationForRMMUIPropertiesFiles\auth.properties"}
if (Test-Path "$ReadMeFile\BI-Clinical_Readme.txt")
{get-childitem -path "$ReadMeFile\BI-Clinical_Readme.txt"| Copy-Item -destination "$RMM_Web_Server_Path\BI-Clinical_Readme.txt"}

get-childitem -path "$SourceForRMMPropertiesFiles\module.xml"| Copy-Item -destination "$DestinationForRMMUIPropertiesFiles\module.xml"

#BIC-Console
#regionBICConsoleWebPropertiesBackup
if ((Test-Path $BICConsoleWebBackupFolder) -eq $False)
{
Write-HostWithLogandColor $dashline Gray 
Write-HostWithLogandColor "Create $BICConsoleWebBackupFolder Folder on UI Server"Gray
New-Item ($BICConsoleWebBackupFolder) -type directory -force | out-null
}
else
{
write-HostWithLogandColor "$BICConsoleWebBackupFolder Folder already exist on UI Server" Yellow
}
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$DestBICConsoleUIPropertiesFiles\*.properties")
{
write-HostWithLogandColor "Backup BIC-Console UI Properties files to $BICConsoleWebBackupFolder" Yellow
robocopy $DestBICConsoleUIPropertiesFiles $BICConsoleWebBackupFolder
write-HostWithLogandColor "Backup of BIC-Console UI Properties file is completed to $BICConsoleWebBackupFolder" Yellow
}
Write-HostWithLogandColor $dashline Gray 
#endregionregionBICConsoleWebPropertiesBackup

if (Test-Path ($DestBICConsoleUIPropertiesFiles))
{}
else
{New-Item ($DestBICConsoleUIPropertiesFiles) -type directory -force | out-null}

if (Test-Path "$SourceForBICConsolePropertyFiles\bicconsolewebconfig.properties")
{Get-Content "$SourceForBICConsolePropertyFiles\bicconsolewebconfig.properties" | ForEach-Object { $_ -replace "<UIServerURL>","$UIServer" -replace "<ServiceServerURL>","$ServiceServer" -replace "<IsSSOEnabled>","$IsSSO_Required" -replace "<UAMServerURL>","$UAMAPPServer" -replace "<UAM-keycloakServerURL>","$Auth_Server" -replace "<AuthWebClientId>","$Admin_Console_Auth_Web_Client_ID" -replace "<AuthAppClientId>","$Auth_App_ClientId" -replace "<UAMWebAppServerURL>","$UAMWebServer" -replace "<PrivateServiceServerURL>","$PrivateServiceServer" -replace "<WebValidHosts>","$ValidHostBICConsoleUI" -replace "<WebCorsAllowedOrigins>","$CorsAllowedOriginsUI"} | Set-Content "$DestBICConsoleUIPropertiesFiles\bicconsolewebconfig.properties"}

robocopy "$SourceForBICConsolePropertyFiles" "$DestBICConsoleUIPropertiesFiles" /e /xf "database.properties" "bicconsolewebconfig.properties" "bicconsoleconfig.properties" "application.properties"

Write-HostWithLogandColor "Copied properties files to the WildFlyFolderPath UI Server" Green
}

if ([string]$RMM_Web_War_Required -eq "True")
{
TestPath $AbsolutefolderPathUIWar

#regionBackupRMMWebwar
if ((Test-Path $RMMWebBackupFolder) -eq $False)
{
Write-HostWithLogandColor $dashline Gray 
write-HostWithLogandColor "Create $RMMWebBackupFolder Folder on App Server"Gray
New-Item ($RMMWebBackupFolder) -type directory -force | out-null
}
else
{
write-HostWithLogandColor "$RMMWebBackupFolder Folder already exist on App Server" Yellow
}
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$AbsolutefolderPathUIWar\*.war")
{
write-HostWithLogandColor "Backup RMM App & BIC-Console war files to $RMMWebBackupFolder" Yellow
robocopy $AbsolutefolderPathUIWar $RMMWebBackupFolder
write-HostWithLogandColor "Backup of RMM App & BIC-Console war file is completed to $RMMWebBackupFolder" Yellow
}
Write-HostWithLogandColor $dashline Gray 
#endregionregionBackupRMMWebwar
Write-HostWithLogandColor "Started copying War deployment on UI Wildfly Server" Yellow
if((Test-Path $AbsolutefolderPathUIWar) -eq $False)
{
	New-Item ($AbsolutefolderPathUIWar) -type directory -force | out-null
}
if ((Test-Path "$SourceForRMMWarFiles" ) -and [string]$RMM_Web_War_Required -eq "true" )
{
get-childitem -path $SourceForRMMWarFiles -recurse -include "RMMApp.war" | Copy-Item -destination "$AbsolutefolderPathUIWar"
}
if ((Test-Path "$SourceForBICConsoleWarFiles" ) -and [string]$RMM_Web_War_Required -eq "true" )
{
get-childitem -path $SourceForBICConsoleWarFiles -recurse -include "BicConsoleWeb.war" | Copy-Item -destination "$AbsolutefolderPathUIWar"
}
Write-HostWithLogandColor "Deployment of War is done on $RMM_Web_Server_Path Server" Green

get-childitem -path $SQLAuth -recurse *.dll | Copy-Item -destination "$RMM_Web_Server_Path\bin"

}
}

Catch
{
Write-HostWithLogandColor $_.Exception.GetType( ).FullName Red
exit 1;
}
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "Deployment of RMM application is done successfully" Green
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
}

