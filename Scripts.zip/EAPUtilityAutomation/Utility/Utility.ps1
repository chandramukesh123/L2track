param([string]$SetupConfigurationFile)


function TestEAPPath {
#test Sources EAP path
	Write-Host $dashline
	if(Test-Path $SourceEAPPath)
		{
 			Write-Host "$SourceEAPPath folder Path Found" -ForegroundColor Green
		}
	else
		{
			Write-Host "$SourceEAPPath Not folder Found" -ForegroundColor Red
		}
	Write-Host $dashline

}

function CopyPrunsrv{
Write-Host $dashline
#copy Prunsrv.exe
$Prunserv= $JBCSPath +'\sbin\prunsrv.exe'
write-host $Prunserv
	if (Test-Path $Prunserv )
	{
		Copy-Item -Path $Prunserv -Destination "$SourceEAPPath\bin"
		Write-Host "Copied Prunsrv.exe to $SourceEAPPath\bin" -ForegroundColor Green
	}
	
  else{
		write-Host "Prunsrv.exe Not Found" -ForegroundColor Red
	
	}
Write-Host $dashline
}

function ModifyServicesFile{
Write-Host $dashline
Write-Host "Modifying Service.bat file configuration"

# Modify Services.bat file
	$SourceServicesEAPPath=$SourceEAPPath +'\bin\service.bat'

	#Shortname value
	$SourceShortName = Select-String -Path $SourceServicesEAPPath -Pattern 'set SHORTNAME=' | Select-Object -First 1 -ExpandProperty Line
	$SetShortName =  "set SHORTNAME="+$Shortname
    Write-Host "Short Name is $SetShortName" -ForegroundColor Green
   
	#Display Name
	$SourceDisplayname = Select-String -Path $SourceServicesEAPPath -Pattern 'set DISPLAYNAME=' | Select-Object -First 1 -ExpandProperty Line
    $SetDisplayName = "set DISPLAYNAME="+$Displayname
	write-Host "Display Name is $SetDisplayName" -ForegroundColor Green


	#Description Changes
	$SourceDESCRIPTION = Select-String -Path $SourceServicesEAPPath -Pattern 'set DESCRIPTION=' | Select-Object -First 1 -ExpandProperty Line
    $SetSourceDESCRIPTION = "set DESCRIPTION="+$Description
	write-Host "DESCRIPTION value is $SetSourceDESCRIPTION" -ForegroundColor Green


	#Controller
	$SourceController = Select-String -Path $SourceServicesEAPPath -Pattern 'set CONTROLLER='  | Select-Object -First 1 -ExpandProperty Line
	$controllervalue = [int]$controller + [int]$Offset
	Write-Host "controller value is $controllervalue" -ForegroundColor Green
    $SetSourceController = "set CONTROLLER=localhost:"+"$controllervalue"
	write-Host "Controller value is $SetSourceController" -ForegroundColor Green
  

	#Startup_mode
	$SourceStartUpMode = Select-String -Path $SourceServicesEAPPath -Pattern 'set STARTUP_MODE=' | Select-Object -First 1 -ExpandProperty Line
	$SetSourceStartUpMode = "set STARTUP_MODE="+$Startupmode
	write-host "StartUpMode value is $SetSourceStartUpMode" -ForegroundColor Green 

    #Replacing values
	$DestinationTempFilePath = "$env:TEMP\$($SourceServicesEAPPath | Split-Path -Leaf)"
	(Get-Content -Path $SourceServicesEAPPath) -replace "\b$SourceShortName\b" , "$SetShortName" -replace "\b$SourceDisplayname\b", "$SetDisplayName" -replace  "\b$SourceDESCRIPTION\b", "$SetSourceDESCRIPTION"  -replace "\b$SourceController\b", "$SetSourceController" -replace "\b$SourceStartUpMode\b", "$SetSourceStartUpMode" | Add-Content -Path $DestinationTempFilePath

	Remove-Item -Path $SourceServicesEAPPath
	Move-Item -Path $DestinationTempFilePath -Destination $SourceServicesEAPPath
	
	write-Host "Modified Services.bat file Successfully" -ForegroundColor Green
	Write-Host $dashline 

}

function Offset {
#Add offset
$AddOffset="{jboss.socket.binding.port-offset:$Offset}"
$DollerSign="$"
$FinalOffsetValue=$DollerSign+$AddOffset
$StandaloneXMLPath = ($SourceEAPPath + '\standalone\configuration\standalone.xml') -join '\'
[xml]$root = Get-Content $StandaloneXMLPath;

$AddBindaddress="{jboss.bind.address.management:$bindaddress}"
$Finalbindaddress=$DollerSign+$AddBindaddress

$project = $root.'server'.'socket-binding-group'
$project.SetAttribute("port-offset","$FinalOffsetValue");

$bind = $root.'server'.'interfaces'.'interface'[-1].'inet-address'
$bind.SetAttribute("value","$Finalbindaddress");

$bind = $root.'server'.'interfaces'.'interface'[-2].'inet-address'  
$bind.SetAttribute("value","$Finalbindaddress");


$root.Save($StandaloneXMLPath);
Write-Host $dashline
}


function maxpostsize{

$StandaloneXMLPath = ($SourceEAPPath + '\standalone\configuration\standalone.xml') -join '\'


$FindHttpValue = 'http-listener name="default" socket-binding="http" redirect-socket="https" enable-http2="true"'
$AddHttpValue = 'http-listener name="default" socket-binding="http" max-post-size="104857600"  redirect-socket="https" enable-http2="true"'

$FindHttpsValue = 'https-listener name="https" socket-binding="https" security-realm="ApplicationRealm" enable-http2="true"'
$AddHttpsValue = 'https-listener name="https" socket-binding="https" max-post-size="104857600" security-realm="ApplicationRealm" enable-http2="true"'

$standalonetempfilepath = "$env:TEMP\$($StandaloneXMLPath | Split-Path -Leaf)"
(Get-Content -Path $StandaloneXMLPath) -replace $FindHttpValue, $AddHttpValue -replace  $FindHttpsValue, $AddHttpsValue | Add-Content -Path $standalonetempfilepath


Remove-Item -Path $StandaloneXMLPath
Move-Item -Path $standalonetempfilepath -Destination $StandaloneXMLPath

Write-Host $dashline
}


function ModifyStandaloneBat{
Write-Host $dashline
Write-Host "Modifying standalone.bat file configuration"
	#Modify standalone.bat for dpkey and deckey
	#Added DCustome line
		$standalonebat_filepath=($SourceEAPPath + '\bin\standalone.bat') -join '\'
		$standalonebatfilevalue = Get-Content $standalonebat_filepath
		$Findjbossvalue= '"-Djboss.home.dir=%JBOSS_HOME%" ^'
		$Adddcustomvalue= '     -Dcustom.log.path="%JBOSS_LOG_DIR%" -Dcustom.log.level="INFO" -Dcustom.log.size="5MB" ^'
        $DPKeyLine =" -Dpkey=`"$DPKeySecret`" ^"
		Write-Host "$DPKeyLine" -ForegroundColor Green
        $DDecKeyLine = "-Ddeckey=`"$DDecKeySecret`" ^"
		Write-Host "$DDecKeyLine" -ForegroundColor Green


        #modify DdecKey in Destination standalone.bat file
			$containsWord = $standalonebatfilevalue | %{$_ -match "-DdecKey"}
			if ($containsWord -contains $true) {
			Write-Host "Already Added 'DdecKey' in standalone.bat file" -ForegroundColor Green
			} 
			else {
			(Get-Content $standalonebat_filepath).Replace("$Findjbossvalue","$Findjbossvalue`n $DDecKeyLine") | Set-Content $standalonebat_filepath
			Write-Host "Adding 'DdecKey' in standalone.bat file" -ForegroundColor Green
			}

#DpKey
			#modify dpkey in destination standalone.bat file
			$containsWord = $standalonebatfilevalue | %{$_ -match "-DpKey"}
			if ($containsWord -contains $true) {
			Write-Host "Already Added 'Dpkey' in standalone.bat file" -ForegroundColor Green
			} 
			else {
			(Get-Content $standalonebat_filepath).Replace("$Findjbossvalue","$Findjbossvalue`n $DPKeyLine") | Set-Content $standalonebat_filepath
			Write-Host "Adding 'Dpkey' in standalone.bat file" -ForegroundColor Green
			} 
		#Dcustom
		$containsWord = $standalonebatfilevalue | %{$_ -match "-Dcustom"}
		if ($containsWord -contains $true) {
		Write-Host "Already Added 'Dcustom value' in standalone.bat file" -ForegroundColor Green
		Write-Host "EAP installation is Successfull" -ForegroundColor Green 
		} 
		else {
		(Get-Content $standalonebat_filepath).Replace("$Findjbossvalue","$Findjbossvalue`n $Adddcustomvalue") | Set-Content $standalonebat_filepath
		Write-Host "Adding 'Dcustom value' in standalone.bat file" -ForegroundColor Green
		} 

		
		}

function ModifyStandaloneConf{
		Write-Host $dashline
		Write-Host "Modifying standalone.conf.bat file configuration"
	#modify Standalone.conf.bat
    $DestinationConfPath="$SourceEAPPath\bin\standalone.conf.bat"

	#-------comment 2 lines of code in standalone.conf.bat-------

	$Findechovalue= 'echo "JAVA_OPTS already set in environment; overriding default settings with values: %JAVA_OPTS%"'
	$commentechovalue= 'rem echo "JAVA_OPTS already set in environment; overriding default settings with values: %JAVA_OPTS%"'

	$commentlinevalue = Get-Content $DestinationConfPath
	$containsWord = $commentlinevalue | %{$_ -match "rem echo"}
	if ($containsWord -contains $true) {
    Write-Host "Already Added 'rem' before 'echo' in standalone.conf.bat file" -ForegroundColor Green
    } 
    else {
    (Get-Content $DestinationConfPath).Replace("$Findechovalue", "$commentechovalue") | Set-Content $DestinationConfPath
    Write-Host "Adding 'rem' before 'echo' to Comment the line in standalone.conf.bat file" -ForegroundColor Green
	}

	$Findjavaoptsetcomment= 'goto JAVA_OPTS_SET'
	$commentgotojavaoptvalue= 'rem goto JAVA_OPTS_SET'

	$commentlinevalue1 = Get-Content $DestinationConfPath
	$containsWord = $commentlinevalue1 | %{$_ -match "rem goto"}
	if ($containsWord -contains $true) {
    Write-Host "Already Added 'rem' before 'goto JAVA_OPTS_SET' in standalone.conf.bat file" -ForegroundColor Green
	Write-Host "----- standalone.conf.bat file has been modified Successfully -----" -ForegroundColor Green
    } 
    else {
    (Get-Content $DestinationConfPath).Replace("$Findjavaoptsetcomment", "$commentgotojavaoptvalue") | Set-Content $DestinationConfPath
    Write-Host "Adding 'rem' before 'goto JAVA_OPTS_SET'Comment the line in standalone.conf.bat file" -ForegroundColor Green
    Write-Host "----- standalone.conf.bat file has been modified Successfully -----" -ForegroundColor Green
	}

Write-Host $dashline
}


function ModifyMemoryConf{
Write-Host $dashline
Write-Host "Modifying standalone.conf.bat file configuration"

	#modify Standalone.conf.bat
    $SourceConfPath = $SourceEAPPath + '\bin\standalone.conf.bat'
	$SourceConfName = Select-String -Path $SourceEAPPath\bin\standalone.conf.bat -Pattern 'set "JAVA_OPTS='  | Select-Object -First 1 -ExpandProperty Line
	Write-Host "$SourceConfName"
  
    $SetConf = "set `"JAVA_OPTS=-Xms$JVMMinSize -Xmx$JVMMaxSize -XX:MetaspaceSize=$MinMetaSpaceSize -XX:MaxMetaspaceSize=$MaxMetaSpaceSize`""
    Write-Host $SetConf -ForegroundColor Green
  
            
        
	$DestinationTempFilePath = "$env:TEMP\$($SourceConfPath | Split-Path -Leaf)"
	(Get-Content -Path $SourceConfPath) -replace $SourceConfName, $SetConf | Add-Content -Path $DestinationTempFilePath
	
	Remove-Item -Path $SourceConfPath
	Move-Item -Path $DestinationTempFilePath -Destination $SourceConfPath
    write-host "modified RAM Memory Value is $SetConf" -ForegroundColor Green
	

}

function AddTempRemoveCode{
Write-Host $dashline
Write-Host "Add temp folder remove code in standalone.bat file configuration"
	$standalonebat_filepath=($SourceEAPPath + '\bin\standalone.bat') -join '\'
	$Findpausevalue= ':END_NO_PAUSE'

$ValuetoAdd='echo ---------Start Delete tmp folder 
del  "%JBOSS_HOME%\standalone\tmp\*.*" /s /f /q
rmdir  "%JBOSS_HOME%\standalone\tmp\" /s /q
echo ---------End Delete tmp folderHardware Requirements'

    $commentlinevalue = Get-Content $standalonebat_filepath

	$containsWord = $commentlinevalue | %{$_ -match "End Delete tmp folder"}
	if ($containsWord -contains $true) {
    Write-Host "Already Added $Adddeltmpline line in standalone.bat file"
    } 
    else {
    (Get-Content $standalonebat_filepath).Replace("$Findpausevalue","$Findpausevalue`n $ValuetoAdd") | Set-Content $standalonebat_filepath
    Write-Host "Adding $ValuetoAdd line in standalone.bat file"
	}
Write-Host $dashline
}


function AddCookieSessionStandalone{
Write-Host $dashline
Write-Host "Add session-cookie in standalone.xml file configuration"
	$DestinationEAPPath=($SourceEAPPath + '\standalone\configuration\standalone.xml') -join '\'
	[xml]$root = Get-Content $DestinationEAPPath;
	$SessionCheck = Select-String -Path $DestinationEAPPath -Pattern 'session-cookie'  
	if ($SessionCheck -ne $null) 
	{
		Write-Host "<session-cookie> is already Exist" -ForegroundColor Green
	}
	else{

       
        if([string]$ISHttpsRequired -eq 'True')
		{
			$SecureValue = 'True'
		}
		else
		{																
			$SecureValue = 'False'
		}
        $project = $root.'server'.'profile'.'subsystem'[-3].'servlet-container'
		$beforeBuild = $root.CreateElement("session-cookie", $project.NamespaceURI);
		$beforeBuild.SetAttribute("http-only","true");
		$beforeBuild.SetAttribute("secure","$SecureValue");
		$beforeBuild.SetAttribute("max-age","-1");
		$beforeBuild.RemoveAttribute("xmlns");
		$project.AppendChild($beforeBuild);
		Write-Host "<session-cookie> is Added" -ForegroundColor Green

	}
	$root.Save($DestinationEAPPath);
Write-Host $dashline
}


#########SSL configuration ###########
function EnableHttps{

if([string]$ISHttpsRequired -eq 'True')
{

          
        $DestinationEAPPath="C:\Users\DevarakondaC\Desktop\jboss-eap-7.4.0.Beta\jboss-eap-7.4"
		$DestinationStandaloneXMLPath="$SourceEAPPath\standalone\configuration\standalone.xml";
		$xmlDoc = [System.Xml.XmlDocument](Get-Content $DestinationStandaloneXMLPath);

		$SeesionCheck = Select-String -Path $DestinationStandaloneXMLPath -Pattern 'security-realm name="SSLRealm"'  
		if ($SeesionCheck -ne $null) 
		{
		Write-Host "security-realm name= 'SSLRealm' is already exist in standalone.xml" -ForegroundColor Yellow
		}
		else
		{
		Write-Host "Adding security-realm and certificate path to destination standalone.xml" -ForegroundColor Gray
		$project = $xmlDoc.server.management.'security-realms'
		$newXmlSSLRealmNode = $project.AppendChild($xmlDoc.CreateElement("security-realm", $project.NamespaceURI));
		$newXmlSSLRealmNode.SetAttribute("name","SSLRealm");
		$newXmlSSLRealmNode.RemoveAttribute("xmlns","");
		$newXmlNameElement = $newXmlSSLRealmNode.AppendChild($xmlDoc.CreateElement("server-identities", $newXmlSSLRealmNode.NamespaceURI));
		$newXmlNameElement.RemoveAttribute("xmlns","");
		$newXmlSSLElement = $newXmlNameElement.AppendChild($xmlDoc.CreateElement("ssl", $newXmlSSLRealmNode.NamespaceURI));
		$newXmlSSLElement.RemoveAttribute("xmlns","");
		$newXmlkeystore =  $newXmlSSLElement.AppendChild($xmlDoc.CreateElement("keystore", $newXmlSSLRealmNode.NamespaceURI));
		$newXmlkeystore.RemoveAttribute("xmlns","");
		$newXmlkeystore.SetAttribute("path","$SSLDIRPath");
		$newXmlkeystore.SetAttribute("relative-to","jboss.server.config.dir");
		$newXmlkeystore.SetAttribute("keystore-password","$KeystorePassword");
		$newXmlkeystore.SetAttribute("key-password","$KeyPassword");
		$xmlDoc.Save($DestinationStandaloneXMLPath);
		}
		
        $DestinationStandaloneXMLPath = "$SourceEAPPath\standalone\configuration\standalone.xml";
		$xmlDoc = [System.Xml.XmlDocument](Get-Content $DestinationStandaloneXMLPath);

		$SeesionCheck = Select-String -Path $DestinationStandaloneXMLPath -Pattern 'https-listener name="default-ssl"'  
		
		if ($SeesionCheck -ne $null) 
		{
		Write-Host "https-listener name= 'default-ssl' is already exist in standalone.xml" -ForegroundColor Yellow
		}
		else
		{
		Write-Host "Adding https-listener name= 'default-ssl' in standalone.xml" -ForegroundColor Gray

		$project = $xmlDoc.server.profile.subsystem.server.'https-listener'
		$project.SetAttribute("name","default-ssl");
		$project.SetAttribute("socket-binding","https");
        $project.SetAttribute("max-post-size","104857600") 
		$project.SetAttribute("security-realm","SSLRealm");
		$project.SetAttribute("enabled-cipher-suites","$HTTPSenabledciphersuites");
		$project.SetAttribute("enabled-protocols","TLSv1.2");
		$project.RemoveAttribute("enable-http2","");
		

		$xmlDoc.Save($DestinationStandaloneXMLPath);
        }
}		
else
{
  Write-Host "Https not required"
}
  
}

function InstallServices{
Write-Host $dashline
Write-Host "Installing service"

#Install Services.bat fie
$SourceServicesEAPPath="$SourceEAPPath\bin\service.bat"
$SourceDisplayname = Select-String -Path $SourceServicesEAPPath -Pattern 'set DISPLAYNAME=' | Select-Object -First 1
$SourceDisplaytvalue=$SourceDisplayname.Line.split('=')
$SourceDisplayNameValue=$SourceDisplaytvalue[1]
Write-Host "$SourceDisplayNameValue"



if (Get-Service "$SourceDisplayNameValue" -ErrorAction SilentlyContinue)
{
write-host "$SourceDisplayNameValue service exists"

$ServiceDeleteCmd = 'SC DELETE '+ $SourceDisplayNameValue
echo "command $ServiceDeleteCmd "
$env:NOPAUSE = "true"
Start-Process -Wait "cmd.exe" "/c $ServiceDeleteCmd" -NoNewWindow
if($?) {
Write-Host "Service deleted successfully."
} 
else {
Write-Host "service deletion failed." -ForegroundColor Red
exit
}
}
$ServiceCreateCmd = $SourceEAPPath + '\bin\service.bat install'
echo "command $ServiceCreateCmd "
$env:NOPAUSE = "true"
Start-Process -Wait "cmd.exe" "/c $ServiceCreateCmd" -NoNewWindow
if($?) {
Write-Host "Service created successfully."
} 
else {
Write-Host "service creation failed." -ForegroundColor Red
exit
}
Write-Host $dashline 
}
	
#region Read Details from File
$dashline = "---------------------------------------------------------------------------"
$bindaddress = "0.0.0.0"
$HTTPSsecurityrealm = "SSLRealm"
$HTTPSenabledciphersuites = 'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA, TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384,TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA, TLS_ECDHE_RSA_WITH_RC4_128_SHA,TLS_RSA_WITH_AES_128_CBC_SHA256,TLS_RSA_WITH_AES_128_CBC_SHA, TLS_RSA_WITH_AES_256_CBC_SHA256,TLS_RSA_WITH_AES_256_CBC_SHA,SSL_RSA_WITH_RC4_128_SHA,!aNULL,!MD5,!DSS,!LOW,!MEDIUM,+HIGH,!SSLv3,!SSLv2,!TLSv1.1'
$controller = "9990"



[xml]$xmlConfigFile = new-object XML
	$xmlConfigFile.Load($SetupConfigurationFile)
	
	$EAP_Required=$xmlConfigFile.selectSingleNode("/Configuration/Component").getAttribute("EAP")
	$SourceEAPPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SourceEAPPath").getAttribute("FolderPath")
	Write-Host "Source EAP Path $SourceEAPPath " -ForegroundColor Gray
	$JBCSPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Prunsrv").getAttribute("Prunsrv")
	Write-Host "Prunsrv.exe file path $JBCSPath" -ForegroundColor Green
	$shortname=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Shortname").getAttribute("short")
	Write-Host "SHORTNAME is $shortname" -ForegroundColor Green
	$displayname=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Displayname").getAttribute("display")
	Write-Host "DISPLAYNAME is $displayname" -ForegroundColor Green
	$description=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Description").getAttribute("description")
	Write-Host "DESCRIPTION is $description" -ForegroundColor Green
	$startupmode=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Startupmode").getAttribute("startup")
	Write-Host "STARTUPMODE is $startupmode" -ForegroundColor Green
	$ISHttpsRequired=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/IsHttps").getAttribute("Required")
	$Offset=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Offset").getAttribute("Port")
	Write-Host "Offset value is $Offset" -ForegroundColor Green
	$DPKeySecret=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/DPKeySecret").getAttribute("DPKey")
	Write-Host "DpKeySecret is $DPKeySecret" -ForegroundColor Green
	$DDecKeySecret=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/DDecKeySecret").getAttribute("DDecKey")
	Write-Host "DDecKeySecret is $DDecKeySecret" -ForegroundColor Green
	$SSLDIRPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SSLDIRPath").getAttribute("SSLPath")
	Write-Host "SSLDIRPath is $SSLDIRPath" -ForegroundColor Green
	$KeystorePassword=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/KeystorePassword").getAttribute("KeystorePass")
	Write-Host "KeystorePassword is $KeystorePassword" -ForegroundColor Green
	$KeyPassword=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/KeyPassword").getAttribute("KeyPass")
	Write-Host "KeyPassword is $KeyPassword" -ForegroundColor Green
	$JVMMinSize=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/JVMMinSize").getAttribute("MinSize")
	write-Host "JVM minimum size is $JVMMinSize" -ForegroundColor Green
	$JVMMaxSize=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/JVMMaxSize").getAttribute("MaxSize")
	write-Host "JVM maximum size is $JVMMaxSize" -ForegroundColor Green
	$MinMetaSpaceSize=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MinMetaSpaceSize").getAttribute("MinSpaceSize")
	write-Host "minimum metaspace size is $MinMetaSpaceSize" -ForegroundColor Green
	$MaxMetaSpaceSize=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MaxMetaSpaceSize").getAttribute("MaxSpaceSize")
	write-Host "maximum metaspace size is $MaxMetaSpaceSize" -ForegroundColor Green
	
	
if([string]$EAP_Required -eq "True")
{
TestEAPPath	
CopyPrunsrv
ModifyServicesFile
Offset
maxpostsize
ModifyStandaloneBat
ModifyStandaloneConf
ModifyMemoryConf
AddTempRemoveCode
AddCookieSessionStandalone
EnableHttps
InstallServices
	
}