#!/bin/bash
#############################################################################################################################
#############################################################################################################################
##################################################### PROPERTY OF CITIUSTECH ######################################################################################################                        #################################################
####################################################CREATED BY : UMANG KUMAR #############################################################################################################################################################################################################################################################################################################
############################################################################################################################################################################################################################################################

# Purpose : to fetch inremental data from Git 
# Parameter required : 
#				1.) base tag --			eg :  -b=1.0
#				2.) current tag --		eg :  -c=1.8 
#				3.) build path --		eg :  -p=/d/git_poc
#Note :  directory structure of current repository should be same as of skeleton build path . 

echo -e  '\e[32m Execution started at :   '$(date)   
echo   'Welcome Devops '

for i in "$@"
do
case $i in
    -p=*|--buildpath=*)
    BUILDPATH="${i#*=}"
    ;;
    --default)
    DEFAULT=YES
    ;;
    *)
            # unknown option
    ;;
esac
done

BUILDPATH=$( echo "$BUILDPATH"     | sed "s/ //g" )

echo BUILD PATH = ${BUILDPATH}

if  [ -z "$BUILDPATH" -o "$BUILDPATH" == " " ] 
	then
		echo 'all fields BUILDPATH is mandetory for process execution'
		echo 'stopping process ... '
		exit 1;
else
	echo " Necessary fields are valid"
	echo " Continuing with the process ..."
fi


PARENTBUILDPATH="$(dirname "$BUILDPATH")"
echo "PARENT DIRECTORY : " $PARENTBUILDPATH

ABSOLUTEFILEPATH=${BUILDPATH}/ReleaseManagement/ComponentList/SDEComponentList.txt
echo "incremental filelist path : " $ABSOLUTEFILEPATH ;
if [ ! -f $ABSOLUTEFILEPATH  ] ;
	then 
		echo "no incremental file exist there might be some issue in script .Kindly debug"
		echo "stopping the process ..."
		exit 1

else
	if [ ! -s $ABSOLUTEFILEPATH ] ;
		then
			echo "No incremental data exist "
			echo "programm executed successfully . thank you"
			#exit 1
	else		
			echo "Filelist is given below"
			counter=1
		while IFS= read -r line 
			do
				# counter=1
				fileList=`echo $line | cut -d$' ' -f2`
				echo " $counter . " $fileList
				`cp $fileList $BUILDPATH/$fileList`
				counter=$((counter+1))
			done < "$ABSOLUTEFILEPATH"		
	fi			
fi		
#echo "Zipping repository directory "
#
#TARFILENAME=$PARENTBUILDPATH/${CURRENTTAG}.tar
#echo "Tar file loaction:  "$TARFILENAME
##TARFILENAME=$BUILDPATH/${CURRENTTAG}.gz
##TARFILENAME=${CURRENTTAG}.tar.gz
##	` tar  -cvf  - $BUILDPATH | gzip > $TARFILENAME `
#`tar -cvf $TARFILENAME  --exclude $BUILDPATH/[.]+//  -C $BUILDPATH . `
#
#if [ $? -gt 0 -a $? -ne 126 ];
#        then
#                echo    "archiving failed to execute, there might be issue with script .Kindly debug"
#                echo    " stopping the process ..."
#                exit 	1
#else
#		echo  	"archiving Done Successfully ..."
#		echo    "location of archive is in given directory " $PARENTBUILDPATH 
#
#fi



echo "end of code "
echo " thanks"
